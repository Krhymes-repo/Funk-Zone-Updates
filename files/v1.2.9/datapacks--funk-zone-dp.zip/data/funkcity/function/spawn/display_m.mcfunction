$spawnpokemonat ~ ~ ~ $(props) uncatchable=yes
execute as @e[type=cobblemon:pokemon,distance=..1.5,tag=!funk_pet,sort=nearest,limit=1] run data merge entity @s {Unbattleable:1b,PersistenceRequired:1b,Invulnerable:1b,Tags:["funk_pet","funk_seen"]}
