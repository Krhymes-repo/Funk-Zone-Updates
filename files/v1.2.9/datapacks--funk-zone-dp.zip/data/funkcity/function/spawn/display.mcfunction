execute if entity @e[type=cobblemon:pokemon,distance=..1.2] run return 0
function funkcity:spawn/display_m with entity @s data
execute as @e[type=cobblemon:pokemon,distance=..1.2,tag=!funk_disp] run data merge entity @s {NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Tags:["funk_disp"]}
