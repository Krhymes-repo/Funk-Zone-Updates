execute store result score #n funk.tmp if entity @e[type=cobbledollars:cobble_merchant,distance=..2.5]
execute if score #n funk.tmp matches 2.. run kill @e[type=cobbledollars:cobble_merchant,distance=..2.5,sort=furthest,limit=1]
execute as @e[type=cobbledollars:cobble_merchant,distance=..2.5,sort=nearest,limit=1] unless entity @s[distance=..0.4] run tp @s ~ ~ ~
execute if entity @e[type=cobbledollars:cobble_merchant,distance=..1.5] run return 0
function funkcity:spawn/shop_m with entity @s data
