# Commons baskets v2: the brick Funk City Line station, the Frontier Hall plate's booth and the Funk City battle
# board come down; two Corviknight baskets stand on the station platform either side of the arrival spot (32.5 1 9.5):
# west to Funk City, east to the Frontier Hall. Run once by Funk Frontier (TravelBaskets) in the overworld, positioned
# at the Commons origin - every position here is relative to it.
# --- the station, the booth, the battle board and everything on them (players and Pokemon stay)
execute positioned ~22 ~0 ~1 run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,dx=20,dy=21,dz=15]
execute positioned ~22 ~0 ~1 as @e[type=cobblemon:pokemon,tag=funk_disp,dx=20,dy=21,dz=15] run function funkcity:spawn/vanish
fill ~23 ~1 ~2 ~41 ~20 ~15 minecraft:air
# the platform where the tracks ran: chequer it like the rest
setblock ~26 ~0 ~4 minecraft:polished_andesite
setblock ~26 ~0 ~5 minecraft:smooth_stone
setblock ~27 ~0 ~4 minecraft:smooth_stone
setblock ~27 ~0 ~5 minecraft:polished_andesite
setblock ~28 ~0 ~4 minecraft:polished_andesite
setblock ~28 ~0 ~5 minecraft:smooth_stone
setblock ~29 ~0 ~4 minecraft:smooth_stone
setblock ~29 ~0 ~5 minecraft:polished_andesite
setblock ~30 ~0 ~4 minecraft:polished_andesite
setblock ~30 ~0 ~5 minecraft:smooth_stone
setblock ~31 ~0 ~4 minecraft:smooth_stone
setblock ~31 ~0 ~5 minecraft:polished_andesite
setblock ~32 ~0 ~4 minecraft:polished_andesite
setblock ~32 ~0 ~5 minecraft:smooth_stone
setblock ~33 ~0 ~4 minecraft:smooth_stone
setblock ~33 ~0 ~5 minecraft:polished_andesite
setblock ~34 ~0 ~4 minecraft:polished_andesite
setblock ~34 ~0 ~5 minecraft:smooth_stone
setblock ~35 ~0 ~4 minecraft:smooth_stone
setblock ~35 ~0 ~5 minecraft:polished_andesite
setblock ~36 ~0 ~4 minecraft:polished_andesite
setblock ~36 ~0 ~5 minecraft:smooth_stone
setblock ~37 ~0 ~4 minecraft:smooth_stone
setblock ~37 ~0 ~5 minecraft:polished_andesite
setblock ~38 ~0 ~4 minecraft:polished_andesite
setblock ~38 ~0 ~5 minecraft:smooth_stone
# --- basket to Funk City: x 26..30, z 6..10, way in on the east
fill ~26 ~0 ~6 ~30 ~0 ~10 minecraft:bamboo_mosaic
fill ~26 ~1 ~6 ~26 ~1 ~10 minecraft:bamboo_mosaic
fill ~26 ~2 ~6 ~26 ~2 ~10 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~30 ~1 ~6 ~30 ~1 ~10 minecraft:bamboo_mosaic
fill ~30 ~2 ~6 ~30 ~2 ~10 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~26 ~1 ~6 ~30 ~1 ~6 minecraft:bamboo_mosaic
fill ~26 ~2 ~6 ~30 ~2 ~6 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~26 ~1 ~10 ~30 ~1 ~10 minecraft:bamboo_mosaic
fill ~26 ~2 ~10 ~30 ~2 ~10 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~26 ~1 ~6 ~26 ~2 ~6 minecraft:stripped_bamboo_block[axis=y]
fill ~26 ~3 ~6 ~26 ~7 ~6 create:shaft[axis=y]
fill ~26 ~1 ~10 ~26 ~2 ~10 minecraft:stripped_bamboo_block[axis=y]
fill ~26 ~3 ~10 ~26 ~7 ~10 create:shaft[axis=y]
fill ~30 ~1 ~6 ~30 ~2 ~6 minecraft:stripped_bamboo_block[axis=y]
fill ~30 ~3 ~6 ~30 ~7 ~6 create:shaft[axis=y]
fill ~30 ~1 ~10 ~30 ~2 ~10 minecraft:stripped_bamboo_block[axis=y]
fill ~30 ~3 ~10 ~30 ~7 ~10 create:shaft[axis=y]
fill ~30 ~1 ~8 ~30 ~2 ~8 minecraft:air
setblock ~28 ~1 ~8 minecraft:bamboo_pressure_plate[powered=false]
fill ~26 ~8 ~6 ~30 ~8 ~10 create:gearbox[axis=y]
setblock ~28 ~9 ~8 create:gearbox[axis=y]
setblock ~28 ~9 ~7 create:shaft[axis=z]
setblock ~28 ~9 ~9 create:shaft[axis=z]
summon minecraft:marker ~28.5 ~10 ~8.5 {Tags:["funk_spawn","funk_taxi"],data:{kind:"display",props:"corviknight level=50",yaw:-90}}
summon minecraft:marker ~28.5 ~1 ~8.5 {Tags:["funk_cardoor","fcar_city"]}
summon minecraft:text_display ~31.03 ~3.05 ~8.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[-90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Funk City\\n","color":"#FFD23F","bold":true},{"text":"Corviknight Air Taxi\\n","color":"gray"},{"text":"Step on the plate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
# --- basket to Frontier Hall: x 34..38, z 6..10, way in on the west
fill ~34 ~0 ~6 ~38 ~0 ~10 minecraft:bamboo_mosaic
fill ~34 ~1 ~6 ~34 ~1 ~10 minecraft:bamboo_mosaic
fill ~34 ~2 ~6 ~34 ~2 ~10 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~38 ~1 ~6 ~38 ~1 ~10 minecraft:bamboo_mosaic
fill ~38 ~2 ~6 ~38 ~2 ~10 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~34 ~1 ~6 ~38 ~1 ~6 minecraft:bamboo_mosaic
fill ~34 ~2 ~6 ~38 ~2 ~6 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~34 ~1 ~10 ~38 ~1 ~10 minecraft:bamboo_mosaic
fill ~34 ~2 ~10 ~38 ~2 ~10 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill ~34 ~1 ~6 ~34 ~2 ~6 minecraft:stripped_bamboo_block[axis=y]
fill ~34 ~3 ~6 ~34 ~7 ~6 create:shaft[axis=y]
fill ~34 ~1 ~10 ~34 ~2 ~10 minecraft:stripped_bamboo_block[axis=y]
fill ~34 ~3 ~10 ~34 ~7 ~10 create:shaft[axis=y]
fill ~38 ~1 ~6 ~38 ~2 ~6 minecraft:stripped_bamboo_block[axis=y]
fill ~38 ~3 ~6 ~38 ~7 ~6 create:shaft[axis=y]
fill ~38 ~1 ~10 ~38 ~2 ~10 minecraft:stripped_bamboo_block[axis=y]
fill ~38 ~3 ~10 ~38 ~7 ~10 create:shaft[axis=y]
fill ~34 ~1 ~8 ~34 ~2 ~8 minecraft:air
setblock ~36 ~1 ~8 minecraft:bamboo_pressure_plate[powered=false]
fill ~34 ~8 ~6 ~38 ~8 ~10 create:gearbox[axis=y]
setblock ~36 ~9 ~8 create:gearbox[axis=y]
setblock ~36 ~9 ~7 create:shaft[axis=z]
setblock ~36 ~9 ~9 create:shaft[axis=z]
summon minecraft:marker ~36.5 ~10 ~8.5 {Tags:["funk_spawn","funk_taxi"],data:{kind:"display",props:"corviknight level=50",yaw:90}}
summon minecraft:marker ~36.5 ~1 ~8.5 {Tags:["funk_cardoor","fcar_hall"]}
summon minecraft:text_display ~33.97 ~3.05 ~8.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Frontier Hall\\n","color":"#FF4FD8","bold":true},{"text":"Corviknight Air Taxi\\n","color":"gray"},{"text":"Step on the plate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
# the board that lists who's in Funk City (Homestead.boards fills it in), south of the Funk City basket
summon minecraft:text_display ~28.5 ~1.2 ~12.6 {Tags:["funk_npc","funk_label","funk_trainboard","ftb_city"],billboard:"vertical",background:-871296751,line_width:200,brightness:{sky:15,block:15},text:'{"text":"In Funk City now:","color":"#FF4FD8","bold":true}',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
data modify storage funkcity:state commonsBasketsV2 set value 1
