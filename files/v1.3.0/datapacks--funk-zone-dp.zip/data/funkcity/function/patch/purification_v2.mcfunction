# Purification Center v2: Purification PCs turned round (facing the room). Run once in funkcity:city.
fill 72 64 52 72 65 67 minecraft:air replace shadowedhearts:purification_pc
place template funkcity:purification/center 36 63 34
data modify storage funkcity:state purificationV2 set value 1
