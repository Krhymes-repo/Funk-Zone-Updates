# the Hall's basket to the Homestead Commons goes: the Hall is reached from Funk City (and back) only
kill @e[type=minecraft:marker,tag=funk_cardoor,x=4,y=60,z=20,dx=6,dy=16,dz=6]
kill @e[type=minecraft:marker,tag=funk_taxi,x=4,y=60,z=20,dx=6,dy=16,dz=6]
kill @e[type=minecraft:text_display,tag=funk_carlabel,x=3,y=60,z=20,dx=7,dy=16,dz=6]
execute as @e[type=cobblemon:pokemon,tag=funk_disp,x=4,y=60,z=20,dx=6,dy=16,dz=6] run function funkcity:spawn/vanish
fill 5 65 21 9 76 25 minecraft:air
fill 5 64 21 9 64 25 minecraft:polished_deepslate
data modify storage funkcity:state nexusHallV1 set value 1
