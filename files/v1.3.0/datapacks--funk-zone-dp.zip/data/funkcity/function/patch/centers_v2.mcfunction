# Pokemon Centers v2: each district's Pokemon Center becomes the Cities & Structures center - Nurse Joy heals at the
# counter, the clinic clerk sells medicine from the side counter, and the district's Pokemon sits behind the desk.
# The district mart moved out to its own Poke Mart (patch/marts_v1). The plaza ring, waystone and street roamers stay.
# Runs once per world (CarpetFloors job), in funkcity:city.
# --- rock: Pewter Rest Stop (tile -80,-560, door N)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_rock] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_rock] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp33] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-72,y=60,z=-551,dx=22,dy=80,dz=21] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-72,y=60,z=-551,dx=22,dy=80,dz=21]
execute in funkcity:city run fill -75 64 -553 -46 102 -526 minecraft:air
execute in funkcity:city run fill -75 103 -553 -46 115 -526 minecraft:air
execute in funkcity:city run fill -75 64 -555 -68 115 -554 minecraft:air
execute in funkcity:city run fill -64 64 -555 -46 115 -554 minecraft:air
execute in funkcity:city run fill -75 63 -553 -46 63 -526 kantoblocks:pewter_gym_floor2
execute in funkcity:city run fill -75 63 -555 -68 63 -554 kantoblocks:pewter_gym_floor2
execute in funkcity:city run fill -64 63 -555 -46 63 -554 kantoblocks:pewter_gym_floor2
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center -71 63 -550 none
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -63 63 -555 -63 63 -550 minecraft:cobblestone
execute in funkcity:city run fill -62 63 -555 -62 63 -550 minecraft:cobblestone
execute in funkcity:city run fill -61 63 -555 -61 63 -550 minecraft:cobblestone
execute in funkcity:city run fill -60 63 -555 -60 63 -550 minecraft:cobblestone
execute in funkcity:city run fill -59 63 -555 -59 63 -550 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker -60.5 64 -534.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:180,uid:990001}}
execute in funkcity:city run summon minecraft:marker -61.5 64 -533.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"chansey level=15",r:3,uid:33}}
# --- harbor: Lapras Lifeguard Center (tile 320,-400, door E)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_harbor] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_harbor] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp116] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=329,y=60,z=-392,dx=21,dy=80,dz=22] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=329,y=60,z=-392,dx=21,dy=80,dz=22]
execute in funkcity:city run fill 325 64 -395 354 115 -388 minecraft:air
execute in funkcity:city run fill 325 64 -384 354 115 -366 minecraft:air
execute in funkcity:city run fill 325 64 -387 352 115 -385 minecraft:air
execute in funkcity:city run fill 325 63 -395 354 63 -388 kantoblocks:ss_anne_floor
execute in funkcity:city run fill 325 63 -384 354 63 -366 kantoblocks:ss_anne_floor
execute in funkcity:city run fill 325 63 -387 352 63 -385 kantoblocks:ss_anne_floor
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center 349 63 -391 clockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 349 63 -383 354 63 -383 minecraft:cobblestone
execute in funkcity:city run fill 349 63 -382 354 63 -382 minecraft:cobblestone
execute in funkcity:city run fill 349 63 -381 354 63 -381 minecraft:cobblestone
execute in funkcity:city run fill 349 63 -380 354 63 -380 minecraft:cobblestone
execute in funkcity:city run fill 349 63 -379 354 63 -379 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker 334.5 64 -380.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:270,uid:990003}}
execute in funkcity:city run summon minecraft:marker 333.5 64 -381.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"lapras level=20",r:3,uid:116}}
# --- garden: Comfey Herbal Clinic (tile 280,360, door E)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_garden] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_garden] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp378] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=289,y=60,z=368,dx=21,dy=80,dz=22] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=289,y=60,z=368,dx=21,dy=80,dz=22]
execute in funkcity:city run fill 285 64 365 314 115 372 minecraft:air
execute in funkcity:city run fill 285 64 376 314 115 394 minecraft:air
execute in funkcity:city run fill 285 64 373 312 115 375 minecraft:air
execute in funkcity:city run fill 285 63 365 314 63 372 kantoblocks:cave_1
execute in funkcity:city run fill 285 63 376 314 63 394 kantoblocks:cave_1
execute in funkcity:city run fill 285 63 373 312 63 375 kantoblocks:cave_1
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center 309 63 369 clockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 309 63 377 314 63 377 minecraft:cobblestone
execute in funkcity:city run fill 309 63 378 314 63 378 minecraft:cobblestone
execute in funkcity:city run fill 309 63 379 314 63 379 minecraft:cobblestone
execute in funkcity:city run fill 309 63 380 314 63 380 minecraft:cobblestone
execute in funkcity:city run fill 309 63 381 314 63 381 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker 294.5 64 379.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:270,uid:990005}}
execute in funkcity:city run summon minecraft:marker 293.5 64 378.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"comfey level=20",r:3,uid:378}}
# --- groove: Blissey Beat Spa (tile -360,280, door S)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_groove] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_groove] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp575] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-352,y=60,z=289,dx=22,dy=80,dz=21] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-352,y=60,z=289,dx=22,dy=80,dz=21]
execute in funkcity:city run fill -355 64 285 -326 102 312 minecraft:air
execute in funkcity:city run fill -355 103 285 -326 115 312 minecraft:air
execute in funkcity:city run fill -355 64 313 -337 115 314 minecraft:air
execute in funkcity:city run fill -333 64 313 -326 115 314 minecraft:air
execute in funkcity:city run fill -355 63 285 -326 63 312 kantoblocks:celadon_deptstore_floor2
execute in funkcity:city run fill -355 63 313 -337 63 314 kantoblocks:celadon_deptstore_floor2
execute in funkcity:city run fill -333 63 313 -326 63 314 kantoblocks:celadon_deptstore_floor2
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center -331 63 309 180
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -339 63 309 -339 63 314 minecraft:cobblestone
execute in funkcity:city run fill -340 63 309 -340 63 314 minecraft:cobblestone
execute in funkcity:city run fill -341 63 309 -341 63 314 minecraft:cobblestone
execute in funkcity:city run fill -342 63 309 -342 63 314 minecraft:cobblestone
execute in funkcity:city run fill -343 63 309 -343 63 314 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker -340.5 64 294.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:0,uid:990007}}
execute in funkcity:city run summon minecraft:marker -339.5 64 293.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"blissey level=40",r:3,uid:575}}
# --- downtown: Chansey Care Clinic (tile -320,-400, door W)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_downtown] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_downtown] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp795] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-311,y=60,z=-392,dx=21,dy=80,dz=22] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-311,y=60,z=-392,dx=21,dy=80,dz=22]
execute in funkcity:city run fill -315 64 -395 -286 115 -377 minecraft:air
execute in funkcity:city run fill -315 64 -373 -286 115 -366 minecraft:air
execute in funkcity:city run fill -313 64 -376 -286 115 -374 minecraft:air
execute in funkcity:city run fill -315 63 -395 -286 63 -377 kantoblocks:cinnabar_floor1
execute in funkcity:city run fill -315 63 -373 -286 63 -366 kantoblocks:cinnabar_floor1
execute in funkcity:city run fill -313 63 -376 -286 63 -374 kantoblocks:cinnabar_floor1
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center -310 63 -371 counterclockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -315 63 -379 -310 63 -379 minecraft:cobblestone
execute in funkcity:city run fill -315 63 -380 -310 63 -380 minecraft:cobblestone
execute in funkcity:city run fill -315 63 -381 -310 63 -381 minecraft:cobblestone
execute in funkcity:city run fill -315 63 -382 -310 63 -382 minecraft:cobblestone
execute in funkcity:city run fill -315 63 -383 -310 63 -383 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker -294.5 64 -380.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:90,uid:990009}}
execute in funkcity:city run summon minecraft:marker -293.5 64 -379.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"chansey level=20",r:3,uid:795}}
# --- fire: Ember Clinic (tile -520,40, door W)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_fire] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_fire] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp625] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-511,y=60,z=48,dx=21,dy=80,dz=22] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-511,y=60,z=48,dx=21,dy=80,dz=22]
execute in funkcity:city run fill -515 64 45 -486 115 63 minecraft:air
execute in funkcity:city run fill -515 64 67 -486 115 74 minecraft:air
execute in funkcity:city run fill -513 64 64 -486 115 66 minecraft:air
execute in funkcity:city run fill -515 63 45 -486 63 63 kantoblocks:cinnabar_mansion_floor2
execute in funkcity:city run fill -515 63 67 -486 63 74 kantoblocks:cinnabar_mansion_floor2
execute in funkcity:city run fill -513 63 64 -486 63 66 kantoblocks:cinnabar_mansion_floor2
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center -510 63 69 counterclockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -515 63 61 -510 63 61 minecraft:cobblestone
execute in funkcity:city run fill -515 63 60 -510 63 60 minecraft:cobblestone
execute in funkcity:city run fill -515 63 59 -510 63 59 minecraft:cobblestone
execute in funkcity:city run fill -515 63 58 -510 63 58 minecraft:cobblestone
execute in funkcity:city run fill -515 63 57 -510 63 57 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker -494.5 64 59.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:90,uid:990011}}
execute in funkcity:city run summon minecraft:marker -493.5 64 60.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"blissey level=50",r:4,uid:625}}
# --- power: Audino Recharge Station (tile 560,80, door E)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_power] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_power] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp219] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=569,y=60,z=88,dx=21,dy=80,dz=22] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=569,y=60,z=88,dx=21,dy=80,dz=22]
execute in funkcity:city run fill 565 64 85 594 115 92 minecraft:air
execute in funkcity:city run fill 565 64 96 594 115 114 minecraft:air
execute in funkcity:city run fill 565 64 93 592 115 95 minecraft:air
execute in funkcity:city run fill 565 63 85 594 63 92 kantoblocks:power_plant_floor_3
execute in funkcity:city run fill 565 63 96 594 63 114 kantoblocks:power_plant_floor_3
execute in funkcity:city run fill 565 63 93 592 63 95 kantoblocks:power_plant_floor_3
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center 589 63 89 clockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 589 63 97 594 63 97 minecraft:cobblestone
execute in funkcity:city run fill 589 63 98 594 63 98 minecraft:cobblestone
execute in funkcity:city run fill 589 63 99 594 63 99 minecraft:cobblestone
execute in funkcity:city run fill 589 63 100 594 63 100 minecraft:cobblestone
execute in funkcity:city run fill 589 63 101 594 63 101 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker 574.5 64 99.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:270,uid:990013}}
execute in funkcity:city run summon minecraft:marker 573.5 64 98.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"audino level=25",r:4,uid:219}}
# --- poison: Antidote Infirmary (tile 40,560, door S)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_clinic_poison] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,tag=fs_mart_poison] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=fp431] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=48,y=60,z=569,dx=22,dy=80,dz=21] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=48,y=60,z=569,dx=22,dy=80,dz=21]
execute in funkcity:city run fill 45 64 565 74 102 592 minecraft:air
execute in funkcity:city run fill 45 103 565 74 115 592 minecraft:air
execute in funkcity:city run fill 45 64 593 63 115 594 minecraft:air
execute in funkcity:city run fill 67 64 593 74 115 594 minecraft:air
execute in funkcity:city run fill 45 63 565 74 63 592 kantoblocks:lavender_floor1
execute in funkcity:city run fill 45 63 593 63 63 594 kantoblocks:lavender_floor1
execute in funkcity:city run fill 67 63 593 74 63 594 kantoblocks:lavender_floor1
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center 69 63 589 180
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 61 63 589 61 63 594 minecraft:cobblestone
execute in funkcity:city run fill 60 63 589 60 63 594 minecraft:cobblestone
execute in funkcity:city run fill 59 63 589 59 63 594 minecraft:cobblestone
execute in funkcity:city run fill 58 63 589 58 63 594 minecraft:cobblestone
execute in funkcity:city run fill 57 63 589 57 63 594 minecraft:cobblestone
execute in funkcity:city run summon minecraft:marker 59.5 64 574.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:0,uid:990015}}
execute in funkcity:city run summon minecraft:marker 60.5 64 573.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"audino level=30",r:4,uid:431}}
data modify storage funkcity:state centersV2 set value 1
