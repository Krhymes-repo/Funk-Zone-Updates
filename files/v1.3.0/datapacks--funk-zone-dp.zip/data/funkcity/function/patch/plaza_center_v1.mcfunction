# Plaza Pokemon Center v1: the Plaza's old Pokemon Center becomes the Cities & Structures center the districts got
# in Centers v2 - Nurse Joy heals at the counter and a Chansey sits behind the desk. The old Nurse stall and the plaza
# Poke Mart clerk are retired (the Ball Boutique next door still sells balls). The waystone, the walkway and the
# street roamers stay. Runs once per world (CarpetFloors job plazaCenterV1), in funkcity:city.
# --- the old clerks and anything else inside the old building (players, Pokemon, quest NPCs and waystones are kept)
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,x=13,y=60,z=-58,dx=25,dy=40,dz=18] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=13,y=60,z=-58,dx=25,dy=40,dz=18] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=13,y=60,z=-58,dx=25,dy=40,dz=18]
execute in funkcity:city as @e[type=cobbledollars:cobble_merchant,x=21,y=60,z=-39,dx=8,dy=12,dz=2] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=21,y=60,z=-39,dx=8,dy=12,dz=2] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=21,y=60,z=-39,dx=8,dy=12,dz=2]
# --- clear the old building and its porch canopy, lawn under it
execute in funkcity:city run fill 14 64 -57 37 85 -40 minecraft:air
execute in funkcity:city run fill 21 64 -39 29 69 -37 minecraft:air
execute in funkcity:city run fill 14 63 -57 37 63 -41 kantoblocks:grass_1
# --- the Cities & Structures center (trimmed front yard), door south
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/center_plaza 35 63 -40 180
execute if score #ok funk.tmp matches 0 run return 0
# --- carry the Plaza walkway (red / saffron / celadon) up to the new door
execute in funkcity:city run clone 21 63 -39 29 63 -39 21 63 -40
execute in funkcity:city run clone 21 63 -39 29 63 -39 21 63 -41
execute in funkcity:city run clone 21 63 -39 29 63 -39 21 63 -42
# --- Nurse Joy at the counter, Chansey behind the desk (same spots as the districts' centers)
execute in funkcity:city run summon minecraft:marker 25.5 64 -52.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"nurse",shop:"",name:"Nurse Joy",yaw:0,uid:990101}}
execute in funkcity:city run summon minecraft:marker 26.5 64 -53.5 {Tags:["funk_spawn"],data:{kind:"shoppet",props:"chansey level=10",r:3,uid:990102}}
data modify storage funkcity:state plazaCenterV1 set value 1
