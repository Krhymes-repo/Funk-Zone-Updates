# the island's gate goes back to the Nexus now (DuelWorld.gates): its sign says so
kill @e[type=minecraft:text_display,tag=funk_label,x=-3,y=72,z=66,dx=7,dy=5,dz=3]
summon minecraft:text_display 0.5 74.2 67.4 {Tags:["funk_npc","dw","funk_label","dw_v8"],billboard:"fixed",Rotation:[180f,0f],background:-871296751,line_width:240,brightness:{sky:15,block:15},text:'[{"text": "✦ THE NEXUS ✦\\n", "color": "#FFD84F", "bold": true}, {"text": "back to the Nexus\\n", "color": "white", "bold": false}, {"text": "walk through the gate", "color": "#FFE680", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
data modify storage funkcity:state nexusIslandV1 set value 1
