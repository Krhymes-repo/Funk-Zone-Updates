# TM Records: restock DJ Tamsin with plain Cobblemon TMs (move names now come from Funk Frontier for every TM, so shop,
# loot and reward TMs all stack). Also replaces any stock from the short-lived named version. Runs once per world.
execute as @e[type=cobbledollars:cobble_merchant,tag=fs_tm_records] at @s run function funkcity:spawn/vanish
execute if entity @e[type=minecraft:marker,tag=funk_spawn,x=-0.5,y=64,z=-60.5,distance=..1.5,nbt={data:{shop:"tm_records"}}] run data modify storage funkcity:state tmRecords4 set value 1
