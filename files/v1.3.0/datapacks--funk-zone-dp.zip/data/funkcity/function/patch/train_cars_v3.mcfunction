# Plaza train cars v3: the brick Funk City Line station comes down and two parked Funk City Line cars stand either
# side of the Plaza's south path where it was (z 35..47). Right-click a car's door to ride: the west car goes to
# Homestead Commons, the east car to the Frontier Hall (Funk Frontier TrainCars). Runs once per world (CarpetFloors
# job trainCarsV3), in funkcity:city.
execute if data storage funkcity:state {trainCarsV1:1} run function funkcity:patch/train_cars_v1_undo
# --- the station: its markers, buttons, labels, booths and board, then the building, lawn under it
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=13,y=60,z=34,dx=15,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:marker,tag=funk_train,x=13,y=60,z=34,dx=15,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:marker,tag=funk_hallplate,x=13,y=60,z=34,dx=15,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:marker,tag=funk_cardoor,x=-3,y=60,z=33,dx=24,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:text_display,tag=funk_carlabel,x=-3,y=60,z=33,dx=24,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:text_display,tag=ftb_wilds,x=-3,y=60,z=33,dx=24,dy=20,dz=16]
execute in funkcity:city run fill 14 64 34 27 75 49 minecraft:air
execute in funkcity:city run fill 14 63 35 26 63 48 kantoblocks:grass_1
# --- Homestead Commons car, x -1..3, door east at 3 66 41
execute in funkcity:city run fill -1 64 35 3 72 47 minecraft:air
execute in funkcity:city run setblock 4 64 41 minecraft:air
execute in funkcity:city run fill 1 63 35 1 63 48 create:track[shape=zo,turn=false,waterlogged=false]
execute in funkcity:city run setblock 1 64 37 create:small_bogey[axis=z,waterlogged=false]
execute in funkcity:city run setblock 1 64 45 create:small_bogey[axis=z,waterlogged=false]
execute in funkcity:city run fill -1 65 35 3 65 47 create:railway_casing
execute in funkcity:city run fill -1 66 35 -1 66 47 create:andesite_casing
execute in funkcity:city run fill 3 66 35 3 66 47 create:andesite_casing
execute in funkcity:city run fill -1 66 35 3 66 35 create:andesite_casing
execute in funkcity:city run fill -1 66 47 3 66 47 create:andesite_casing
execute in funkcity:city run fill -1 68 35 -1 68 47 create:andesite_casing
execute in funkcity:city run fill 3 68 35 3 68 47 create:andesite_casing
execute in funkcity:city run fill -1 68 35 3 68 35 create:andesite_casing
execute in funkcity:city run fill -1 68 47 3 68 47 create:andesite_casing
execute in funkcity:city run fill -1 67 35 -1 67 47 create:industrial_iron_window_pane[north=true,south=true,east=false,west=false,waterlogged=false]
execute in funkcity:city run fill 3 67 35 3 67 47 create:industrial_iron_window_pane[north=true,south=true,east=false,west=false,waterlogged=false]
execute in funkcity:city run fill 0 67 35 2 67 35 create:industrial_iron_window_pane[north=false,south=false,east=true,west=true,waterlogged=false]
execute in funkcity:city run fill 0 67 47 2 67 47 create:industrial_iron_window_pane[north=false,south=false,east=true,west=true,waterlogged=false]
execute in funkcity:city run fill -1 66 35 -1 68 35 create:railway_casing
execute in funkcity:city run fill 3 66 35 3 68 35 create:railway_casing
execute in funkcity:city run fill -1 66 39 -1 68 39 create:railway_casing
execute in funkcity:city run fill 3 66 39 3 68 39 create:railway_casing
execute in funkcity:city run fill -1 66 43 -1 68 43 create:railway_casing
execute in funkcity:city run fill 3 66 43 3 68 43 create:railway_casing
execute in funkcity:city run fill -1 66 47 -1 68 47 create:railway_casing
execute in funkcity:city run fill 3 66 47 3 68 47 create:railway_casing
execute in funkcity:city run fill 3 66 40 3 68 40 create:railway_casing
execute in funkcity:city run fill 3 66 42 3 68 42 create:railway_casing
execute in funkcity:city run setblock 3 66 41 create:train_door[facing=west,half=lower,hinge=left,open=false,visible=true]
execute in funkcity:city run setblock 3 67 41 create:train_door[facing=west,half=upper,hinge=left,open=false,visible=true]
execute in funkcity:city run setblock 4 64 41 minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
execute in funkcity:city run fill -1 69 35 3 69 47 create:waxed_oxidized_copper_shingles
execute in funkcity:city run fill 0 70 35 2 70 47 create:waxed_oxidized_copper_shingle_slab[type=bottom,waterlogged=false]
execute in funkcity:city run setblock 0 66 36 create:green_seat
execute in funkcity:city run setblock 2 66 36 create:green_seat
execute in funkcity:city run setblock 0 66 37 create:green_seat
execute in funkcity:city run setblock 2 66 37 create:green_seat
execute in funkcity:city run setblock 0 66 38 create:green_seat
execute in funkcity:city run setblock 2 66 38 create:green_seat
execute in funkcity:city run setblock 0 66 44 create:green_seat
execute in funkcity:city run setblock 2 66 44 create:green_seat
execute in funkcity:city run setblock 0 66 45 create:green_seat
execute in funkcity:city run setblock 2 66 45 create:green_seat
execute in funkcity:city run setblock 0 66 46 create:green_seat
execute in funkcity:city run setblock 2 66 46 create:green_seat
execute in funkcity:city run setblock 1 68 41 minecraft:lantern[hanging=true,waterlogged=false]
execute in funkcity:city run summon minecraft:marker 3.5 66 41.5 {Tags:["funk_cardoor","fcar_commons"]}
execute in funkcity:city run summon minecraft:text_display 4.03 68.12 41.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[-90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Homestead Commons\\n","color":"#7DFF7D","bold":true},{"text":"Funk City Line\\n","color":"gray"},{"text":"Right-click the door","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
# --- Frontier Hall car, x 15..19, door west at 15 66 41
execute in funkcity:city run fill 15 64 35 19 72 47 minecraft:air
execute in funkcity:city run setblock 14 64 41 minecraft:air
execute in funkcity:city run fill 17 63 35 17 63 48 create:track[shape=zo,turn=false,waterlogged=false]
execute in funkcity:city run setblock 17 64 37 create:small_bogey[axis=z,waterlogged=false]
execute in funkcity:city run setblock 17 64 45 create:small_bogey[axis=z,waterlogged=false]
execute in funkcity:city run fill 15 65 35 19 65 47 create:railway_casing
execute in funkcity:city run fill 15 66 35 15 66 47 create:brass_casing
execute in funkcity:city run fill 19 66 35 19 66 47 create:brass_casing
execute in funkcity:city run fill 15 66 35 19 66 35 create:brass_casing
execute in funkcity:city run fill 15 66 47 19 66 47 create:brass_casing
execute in funkcity:city run fill 15 68 35 15 68 47 create:brass_casing
execute in funkcity:city run fill 19 68 35 19 68 47 create:brass_casing
execute in funkcity:city run fill 15 68 35 19 68 35 create:brass_casing
execute in funkcity:city run fill 15 68 47 19 68 47 create:brass_casing
execute in funkcity:city run fill 15 67 35 15 67 47 create:ornate_iron_window_pane[north=true,south=true,east=false,west=false,waterlogged=false]
execute in funkcity:city run fill 19 67 35 19 67 47 create:ornate_iron_window_pane[north=true,south=true,east=false,west=false,waterlogged=false]
execute in funkcity:city run fill 16 67 35 18 67 35 create:ornate_iron_window_pane[north=false,south=false,east=true,west=true,waterlogged=false]
execute in funkcity:city run fill 16 67 47 18 67 47 create:ornate_iron_window_pane[north=false,south=false,east=true,west=true,waterlogged=false]
execute in funkcity:city run fill 15 66 35 15 68 35 create:industrial_iron_block
execute in funkcity:city run fill 19 66 35 19 68 35 create:industrial_iron_block
execute in funkcity:city run fill 15 66 39 15 68 39 create:industrial_iron_block
execute in funkcity:city run fill 19 66 39 19 68 39 create:industrial_iron_block
execute in funkcity:city run fill 15 66 43 15 68 43 create:industrial_iron_block
execute in funkcity:city run fill 19 66 43 19 68 43 create:industrial_iron_block
execute in funkcity:city run fill 15 66 47 15 68 47 create:industrial_iron_block
execute in funkcity:city run fill 19 66 47 19 68 47 create:industrial_iron_block
execute in funkcity:city run fill 15 66 40 15 68 40 create:industrial_iron_block
execute in funkcity:city run fill 15 66 42 15 68 42 create:industrial_iron_block
execute in funkcity:city run setblock 15 66 41 create:train_door[facing=east,half=lower,hinge=left,open=false,visible=true]
execute in funkcity:city run setblock 15 67 41 create:train_door[facing=east,half=upper,hinge=left,open=false,visible=true]
execute in funkcity:city run setblock 14 64 41 minecraft:dark_oak_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
execute in funkcity:city run fill 15 69 35 19 69 47 create:waxed_copper_shingles
execute in funkcity:city run fill 16 70 35 18 70 47 create:waxed_copper_shingle_slab[type=bottom,waterlogged=false]
execute in funkcity:city run setblock 16 66 36 create:magenta_seat
execute in funkcity:city run setblock 18 66 36 create:magenta_seat
execute in funkcity:city run setblock 16 66 37 create:magenta_seat
execute in funkcity:city run setblock 18 66 37 create:magenta_seat
execute in funkcity:city run setblock 16 66 38 create:magenta_seat
execute in funkcity:city run setblock 18 66 38 create:magenta_seat
execute in funkcity:city run setblock 16 66 44 create:magenta_seat
execute in funkcity:city run setblock 18 66 44 create:magenta_seat
execute in funkcity:city run setblock 16 66 45 create:magenta_seat
execute in funkcity:city run setblock 18 66 45 create:magenta_seat
execute in funkcity:city run setblock 16 66 46 create:magenta_seat
execute in funkcity:city run setblock 18 66 46 create:magenta_seat
execute in funkcity:city run setblock 17 68 41 minecraft:lantern[hanging=true,waterlogged=false]
execute in funkcity:city run summon minecraft:marker 15.5 66 41.5 {Tags:["funk_cardoor","fcar_hall"]}
execute in funkcity:city run summon minecraft:text_display 14.97 68.12 41.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Frontier Hall\\n","color":"#FF4FD8","bold":true},{"text":"Factory · Ghosts · Expeditions\\n","color":"gray"},{"text":"Right-click the door","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
execute in funkcity:city run summon minecraft:text_display 1.5 71.4 41.5 {Tags:["funk_npc","funk_label","funk_carlabel","ftb_wilds"],billboard:"vertical",background:-871296751,line_width:200,brightness:{sky:15,block:15},text:'{"text":"Out in the Wilds now:","color":"#7CFC9A","bold":true}',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
data modify storage funkcity:state trainCarsV3 set value 1
