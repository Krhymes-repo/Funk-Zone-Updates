# Safari gatehouse v3: the slab comes off the Warden's counter. Run once in funkcity:city.
fill 61 65 -20 65 65 -20 minecraft:air replace minecraft:jungle_slab
data modify storage funkcity:state safariGatehouseV3 set value 1
