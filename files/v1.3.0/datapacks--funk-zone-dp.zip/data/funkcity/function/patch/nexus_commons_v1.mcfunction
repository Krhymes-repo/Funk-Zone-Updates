# the Commons' two Corviknight baskets (to Funk City, to the Frontier Hall) go; a portal back to the Nexus stands
# behind the arrival spot (~32.5 ~1 ~9.5). Run positioned at the Commons origin: every position is relative.
execute positioned ~25 ~-1 ~5 run kill @e[type=minecraft:marker,tag=funk_cardoor,dx=15,dy=12,dz=7]
execute positioned ~25 ~-1 ~5 run kill @e[type=minecraft:marker,tag=funk_taxi,dx=15,dy=12,dz=7]
execute positioned ~25 ~-1 ~5 run kill @e[type=minecraft:text_display,tag=funk_carlabel,dx=15,dy=12,dz=7]
execute positioned ~25 ~-1 ~5 as @e[type=cobblemon:pokemon,tag=funk_disp,dx=15,dy=14,dz=7] run function funkcity:spawn/vanish
fill ~26 ~1 ~6 ~30 ~10 ~10 minecraft:air
fill ~34 ~1 ~6 ~38 ~10 ~10 minecraft:air
setblock ~26 ~0 ~6 minecraft:polished_andesite
setblock ~26 ~0 ~7 minecraft:smooth_stone
setblock ~26 ~0 ~8 minecraft:polished_andesite
setblock ~26 ~0 ~9 minecraft:smooth_stone
setblock ~26 ~0 ~10 minecraft:polished_andesite
setblock ~27 ~0 ~6 minecraft:smooth_stone
setblock ~27 ~0 ~7 minecraft:polished_andesite
setblock ~27 ~0 ~8 minecraft:smooth_stone
setblock ~27 ~0 ~9 minecraft:polished_andesite
setblock ~27 ~0 ~10 minecraft:smooth_stone
setblock ~28 ~0 ~6 minecraft:polished_andesite
setblock ~28 ~0 ~7 minecraft:smooth_stone
setblock ~28 ~0 ~8 minecraft:polished_andesite
setblock ~28 ~0 ~9 minecraft:smooth_stone
setblock ~28 ~0 ~10 minecraft:polished_andesite
setblock ~29 ~0 ~6 minecraft:smooth_stone
setblock ~29 ~0 ~7 minecraft:polished_andesite
setblock ~29 ~0 ~8 minecraft:smooth_stone
setblock ~29 ~0 ~9 minecraft:polished_andesite
setblock ~29 ~0 ~10 minecraft:smooth_stone
setblock ~30 ~0 ~6 minecraft:polished_andesite
setblock ~30 ~0 ~7 minecraft:smooth_stone
setblock ~30 ~0 ~8 minecraft:polished_andesite
setblock ~30 ~0 ~9 minecraft:smooth_stone
setblock ~30 ~0 ~10 minecraft:polished_andesite
setblock ~34 ~0 ~6 minecraft:polished_andesite
setblock ~34 ~0 ~7 minecraft:smooth_stone
setblock ~34 ~0 ~8 minecraft:polished_andesite
setblock ~34 ~0 ~9 minecraft:smooth_stone
setblock ~34 ~0 ~10 minecraft:polished_andesite
setblock ~35 ~0 ~6 minecraft:smooth_stone
setblock ~35 ~0 ~7 minecraft:polished_andesite
setblock ~35 ~0 ~8 minecraft:smooth_stone
setblock ~35 ~0 ~9 minecraft:polished_andesite
setblock ~35 ~0 ~10 minecraft:smooth_stone
setblock ~36 ~0 ~6 minecraft:polished_andesite
setblock ~36 ~0 ~7 minecraft:smooth_stone
setblock ~36 ~0 ~8 minecraft:polished_andesite
setblock ~36 ~0 ~9 minecraft:smooth_stone
setblock ~36 ~0 ~10 minecraft:polished_andesite
setblock ~37 ~0 ~6 minecraft:smooth_stone
setblock ~37 ~0 ~7 minecraft:polished_andesite
setblock ~37 ~0 ~8 minecraft:smooth_stone
setblock ~37 ~0 ~9 minecraft:polished_andesite
setblock ~37 ~0 ~10 minecraft:smooth_stone
setblock ~38 ~0 ~6 minecraft:polished_andesite
setblock ~38 ~0 ~7 minecraft:smooth_stone
setblock ~38 ~0 ~8 minecraft:polished_andesite
setblock ~38 ~0 ~9 minecraft:smooth_stone
setblock ~38 ~0 ~10 minecraft:polished_andesite
# the portal: an obsidian frame, 4 x 4 inside, the purple swirl as a picture (Funk Frontier's Nexus sends whoever
# walks into it: marker nx_exit)
fill ~30 ~0 ~5 ~35 ~5 ~5 minecraft:obsidian
fill ~31 ~1 ~5 ~34 ~4 ~5 minecraft:air
execute positioned ~29 ~-1 ~3 run kill @e[type=!minecraft:player,tag=nx_commons,dx=8,dy=10,dz=5]
summon minecraft:block_display ~31.0 ~1 ~5.45 {Tags:["funk_npc","nx_commons"],block_state:{Name:"minecraft:nether_portal",Properties:{axis:"x"}},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,0.1f]}}
summon minecraft:marker ~32.5 ~1 ~5.5 {Tags:["funk_npc","nx_commons","nx_exit"]}
summon minecraft:text_display ~33.0 ~6.6 ~6.1 {Tags:["funk_npc","funk_label","nx_commons"],billboard:"fixed",Rotation:[0f,0f],background:-871296751,line_width:240,brightness:{sky:15,block:15},text:'[{"text": "✦ THE NEXUS ✦\\n", "color": "#FFD84F", "bold": true}, {"text": "Funk City, Duel World and more\\n", "color": "white", "bold": false}, {"text": "walk through the portal", "color": "#FFE680", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]}}
data modify storage funkcity:state nexusCommonsV1 set value 1
