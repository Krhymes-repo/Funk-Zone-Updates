# Duel World gate in Funk City's Duel Hall (east wall). Run once by Funk Frontier (CarpetFloors job duelGateV2).
kill @e[type=!minecraft:player,tag=dw_citygate,x=60,y=62,z=-20,dx=9,dy=9,dz=14]
fill 67 64 -15 67 68 -11 minecraft:smooth_sandstone
fill 67 64 -14 67 67 -12 minecraft:air
fill 67 63 -14 67 63 -12 minecraft:chiseled_sandstone
fill 67 68 -14 67 68 -12 minecraft:gold_block
setblock 67 68 -13 minecraft:lapis_block
fill 66 68 -15 66 68 -11 minecraft:smooth_sandstone_stairs[facing=east,half=top]
setblock 66 64 -15 minecraft:chiseled_sandstone
setblock 66 65 -15 minecraft:sandstone_wall[up=true]
setblock 66 66 -15 minecraft:lantern[hanging=false]
setblock 66 64 -11 minecraft:chiseled_sandstone
setblock 66 65 -11 minecraft:sandstone_wall[up=true]
setblock 66 66 -11 minecraft:lantern[hanging=false]
summon minecraft:block_display 67.55 64 -14.0 {Tags:["dw_citygate","dw_cg2"],block_state:{Name:"minecraft:nether_portal",Properties:{axis:"z"}},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,0f],scale:[1f,4f,3f]}}
summon minecraft:marker 67.5 64 -12.5 {Tags:["dw_citygate","dw_cg2","dw_gate","dwg_duel"]}
summon minecraft:text_display 66.4 69.35 -12.5 {Tags:["funk_npc","funk_label","dw_citygate","dw_cg2"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"✦ DUEL WORLD ✦\\n","color":"#FFD84F","bold":true},{"text":"card shops · duelists · the Grand Arena\\n","color":"white"},{"text":"walk through the gate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
data modify storage funkcity:state duelGateV2 set value 1
