# The Purification Center on Funk City's Plaza (south-east lawn). Run once in funkcity:city (Nexus.JOBS purificationV1).
kill @e[type=!minecraft:player,tag=pu_v1,x=28,y=61,z=30,dx=50,dy=24,dz=44]
fill 40 64 34 74 79 68 minecraft:air
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:red_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:blue_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:yellow_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:green_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:pink_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:black_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:white_apricorn
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:apricorn_leaves
fill 30 64 31 39 71 74 minecraft:air replace cobblemon:apricorn_log
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:red_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:blue_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:yellow_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:green_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:pink_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:black_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:white_apricorn
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:apricorn_leaves
fill 30 64 69 74 71 74 minecraft:air replace cobblemon:apricorn_log
fill 24 63 31 39 63 68 kantoblocks:grass_1 replace kantoblocks:celadon_deptstore_floor2
fill 40 63 69 47 63 74 kantoblocks:grass_1 replace kantoblocks:celadon_deptstore_floor2
fill 24 63 31 39 63 68 kantoblocks:grass_1 replace kantoblocks:saffron_wall
fill 40 63 69 47 63 74 kantoblocks:grass_1 replace kantoblocks:saffron_wall
fill 32 63 31 36 63 72 kantoblocks:celadon_deptstore_floor2
fill 34 63 31 34 63 71 kantoblocks:saffron_wall
fill 32 63 70 50 63 74 kantoblocks:celadon_deptstore_floor2
fill 34 63 72 50 63 72 kantoblocks:saffron_wall
place template funkcity:purification/center 36 63 34
summon minecraft:text_display 37.4 70.6 42.5 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:300,brightness:{sky:15,block:15},text:'[{"text": "✦ PURIFICATION CENTER ✦\\n", "color": "#C9A0FF", "bold": true}, {"text": "open the hearts of Shadow Pokémon", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]}}
summon minecraft:text_display 41.3 67.4 39 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[-90f,0f],background:-871296751,line_width:260,brightness:{sky:15,block:15},text:'[{"text": "① Purifier Sena\\n", "color": "#C9A0FF", "bold": true}, {"text": "your Shadow Pokémon\'s next step", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
summon minecraft:text_display 48.5 69.4 35.3 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[0f,0f],background:-871296751,line_width:420,brightness:{sky:15,block:15},text:'[{"text": "How to purify a Shadow Pokémon\\n", "color": "#C9A0FF", "bold": true}, {"text": "① Bond - keep it in your party: walk and battle together\\n", "color": "white", "bold": false}, {"text": "② Scents - send it out and give it one (Scent Bar)\\n", "color": "white", "bold": false}, {"text": "③ The Chamber - set it in a Purification PC\\n", "color": "white", "bold": false}, {"text": "④ Relic Stone - when its Heart Gauge is empty", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.55f,0.55f,0.55f]}}
summon minecraft:text_display 47.5 69 50.7 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[180f,0f],background:-871296751,line_width:260,brightness:{sky:15,block:15},text:'[{"text": "② Scent Bar ▼", "color": "#FFD84F", "bold": true}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]}}
summon minecraft:text_display 54.7 69 42.5 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:260,brightness:{sky:15,block:15},text:'[{"text": "④ Relic Shrine ▼", "color": "#FFD84F", "bold": true}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]}}
summon minecraft:text_display 47.5 69.6 66.6 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[180f,0f],background:-871296751,line_width:300,brightness:{sky:15,block:15},text:'[{"text": "② SCENT BAR\\n", "color": "#FF9BD2", "bold": true}, {"text": "one Scent per Pokémon every 5 minutes", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon minecraft:text_display 54.7 69 59.5 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:260,brightness:{sky:15,block:15},text:'[{"text": "③ The Chamber ▼", "color": "#FFD84F", "bold": true}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]}}
summon minecraft:text_display 64.5 70 52.3 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[0f,0f],background:-871296751,line_width:420,brightness:{sky:15,block:15},text:'[{"text": "③ THE PURIFICATION CHAMBER\\n", "color": "#9BD7FF", "bold": true}, {"text": "a Shadow Pokémon in the middle, up to four friends round it.\\n", "color": "white", "bold": false}, {"text": "Each super effective against the next, clockwise = faster.\\n", "color": "white", "bold": false}, {"text": "It purifies as you walk.", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
summon minecraft:text_display 64.5 69 52.3 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[0f,0f],background:-871296751,line_width:260,brightness:{sky:15,block:15},text:'[{"text": "④ Relic Shrine ▼", "color": "#FFD84F", "bold": true}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]}}
summon minecraft:text_display 66.5 70.5 35.6 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[0f,0f],background:-871296751,line_width:360,brightness:{sky:15,block:15},text:'[{"text": "④ THE RELIC STONE\\n", "color": "#B6FFB0", "bold": true}, {"text": "when its Heart Gauge is empty: send it out beside the stone, then use the stone", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.55f,0.55f,0.55f]}}
summon minecraft:marker 42.5 64 46.5 {Tags:["funk_spawn","pu_v1"],data:{kind:"display",props:"espeon level=50",yaw:-90}}
summon minecraft:marker 53.5 64 46.5 {Tags:["funk_spawn","pu_v1"],data:{kind:"display",props:"umbreon level=50",yaw:90}}
summon minecraft:marker 70.5 64 45.5 {Tags:["funk_spawn","pu_v1"],data:{kind:"display",props:"celebi level=50",yaw:135}}
summon minecraft:text_display 54.4 75 42.5 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[90f,0f],background:0,line_width:400,brightness:{sky:15,block:15},text:'[{"text": "PURIFICATION CENTER", "color": "#C9A0FF", "bold": true}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.7f,1.7f,1.7f]}}
summon minecraft:text_display 64.5 75 33.4 {Tags:["funk_npc","funk_label","pu_v1"],billboard:"fixed",Rotation:[180f,0f],background:0,line_width:400,brightness:{sky:15,block:15},text:'[{"text": "PURIFICATION CENTER", "color": "#C9A0FF", "bold": true}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.7f,1.7f,1.7f]}}
kill @e[type=minecraft:item,x=28,y=61,z=30,dx=50,dy=24,dz=44]
data modify storage funkcity:state purificationV1 set value 1
