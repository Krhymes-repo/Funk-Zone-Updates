# Safari gatehouse v2: the back wall behind the Warden's counter cleaned up. Run once in funkcity:city.
fill 53 64 -25 59 69 -24 minecraft:air
setblock 64 64 -16 minecraft:air
setblock 64 64 -9 minecraft:air
data modify storage funkcity:state safariGatehouseV2 set value 1
