# Safari gatehouse v1 (Funk City's Duel Hall). Run once in funkcity:city.
kill @e[type=minecraft:text_display,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[type=minecraft:interaction,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
execute as @e[type=minecraft:marker,tag=funk_spawn,x=46,y=63,z=-26,dx=21,dy=8,dz=21] if data entity @s data{kind:"sit"} run kill @s
kill @e[tag=fs1033,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fsv1033,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fs1034,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fsv1034,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fs1035,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fsv1035,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fs1036,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fsv1036,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fs1037,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fsv1037,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
kill @e[tag=fq_kaia,x=46,y=63,z=-26,dx=21,dy=8,dz=21]
fill 47 64 -25 66 64 -6 minecraft:air replace dmm:duel_table
fill 47 64 -25 66 64 -6 minecraft:air replace kantomodels:global_yellow_chair
fill 47 64 -25 66 64 -6 minecraft:air replace kantomodels:global_red_chair
# --- the gate in the east wall: jungle wood, leaves over it, a green portal
kill @e[type=!minecraft:player,tag=dw_citygate,x=60,y=62,z=-20,dx=9,dy=9,dz=14]
fill 67 63 -15 67 68 -11 minecraft:stripped_jungle_log[axis=y]
fill 67 64 -14 67 67 -12 minecraft:air
fill 67 68 -15 67 68 -11 minecraft:jungle_planks
fill 66 68 -16 66 68 -10 minecraft:jungle_leaves[persistent=true,distance=1,waterlogged=false]
fill 67 63 -14 67 63 -12 minecraft:mossy_stone_bricks
setblock 66 64 -15 minecraft:stripped_jungle_log[axis=y]
setblock 66 65 -15 minecraft:stripped_jungle_log[axis=y]
setblock 66 64 -11 minecraft:stripped_jungle_log[axis=y]
setblock 66 65 -11 minecraft:stripped_jungle_log[axis=y]
setblock 66 66 -15 minecraft:lantern[hanging=false,waterlogged=false]
setblock 66 66 -11 minecraft:lantern[hanging=false,waterlogged=false]
summon minecraft:block_display 67.45 64 -14.0 {Tags:["funk_npc","safari_gh"],block_state:{Name:"minecraft:lime_stained_glass"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.1f,4f,3f]}}
summon minecraft:marker 67.5 64 -12.5 {Tags:["funk_npc","safari_gh","safari_entry"]}
summon minecraft:text_display 66.4 69.35 -12.5 {Tags:["funk_npc","funk_label","safari_gh"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:240,brightness:{sky:15,block:15},text:'[{"text": "✦ SAFARI ZONE ✦\\n", "color": "#7CFC9A", "bold": true}, {"text": "pay the Warden, then walk through the gate", "color": "white", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
# --- the Warden's desk, north of the gate (a counter facing the hall, a Kangaskhan behind it)
fill 61 64 -20 65 64 -20 minecraft:stripped_jungle_wood[axis=x]
summon minecraft:marker 63.5 64 -22.0 {Tags:["funk_spawn","safari_gh"],data:{kind:"display",props:"kangaskhan level=40",yaw:0}}
summon minecraft:interaction 63.5 64 -20.0 {Tags:["funk_npc","safari_gh","safari_desk"],width:5.2f,height:2.2f,response:1b}
summon minecraft:text_display 63.5 66.6 -19.4 {Tags:["funk_npc","funk_label","safari_gh"],billboard:"vertical",background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text": "Safari Warden\\n", "color": "#FFD84F", "bold": true}, {"text": "Entry 500 · 30 Safari Balls · 20 min\\n", "color": "white", "bold": false}, {"text": "right-click the desk", "color": "#FFE680", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
# --- a moss runner from the doors to the gate, bamboo in the corners
fill 47 64 -13 66 64 -12 minecraft:moss_carpet replace minecraft:air
setblock 47 64 -25 minecraft:potted_bamboo
setblock 47 64 -6 minecraft:potted_bamboo
setblock 66 64 -25 minecraft:potted_bamboo
setblock 66 64 -6 minecraft:potted_bamboo
data modify storage funkcity:state safariGatehouseV1 set value 1
