# Hall baskets v3: the To Funk City / To the Commons buttons by the Frontier Hall's entrance go; two Corviknight
# baskets stand either side of the arrival spot (0.5 65 23.5): west to Funk City, east to Homestead Commons. Run
# once by Funk Frontier (TravelBaskets) in funkcity:hall.
# --- the old buttons: their markers, labels, buttons and any posts they stood on
kill @e[type=minecraft:marker,tag=funk_hallplate,x=-10,y=60,z=18,dx=21,dy=12,dz=13]
kill @e[type=minecraft:text_display,tag=funk_label,x=-6,y=64,z=24,dx=13,dy=6,dz=7]
kill @e[type=minecraft:text_display,tag=ff_btnlabel,x=-10,y=60,z=18,dx=21,dy=12,dz=13]
kill @e[type=minecraft:text_display,tag=funk_carlabel,x=-10,y=60,z=18,dx=21,dy=20,dz=13]
kill @e[type=minecraft:marker,tag=funk_cardoor,x=-10,y=60,z=18,dx=21,dy=20,dz=13]
kill @e[type=minecraft:marker,tag=funk_taxi,x=-10,y=60,z=18,dx=21,dy=20,dz=13]
execute as @e[type=cobblemon:pokemon,tag=funk_disp,x=-10,y=60,z=18,dx=21,dy=16,dz=13] run function funkcity:spawn/vanish
fill -10 64 18 11 69 30 minecraft:air replace minecraft:crimson_button
fill -10 64 18 11 69 30 minecraft:air replace minecraft:polished_blackstone_button
fill -10 64 18 11 64 30 minecraft:air replace minecraft:purpur_pillar
fill -10 65 18 11 65 30 minecraft:air replace minecraft:purpur_pillar
# clear the baskets' room (the Hall's floor stays)
fill -8 65 21 -4 76 25 minecraft:air
fill 5 65 21 9 76 25 minecraft:air
# --- basket to Funk City: x -8..-4, z 21..25, way in on the east
fill -8 64 21 -4 64 25 minecraft:bamboo_mosaic
fill -8 65 21 -8 65 25 minecraft:bamboo_mosaic
fill -8 66 21 -8 66 25 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill -4 65 21 -4 65 25 minecraft:bamboo_mosaic
fill -4 66 21 -4 66 25 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill -8 65 21 -4 65 21 minecraft:bamboo_mosaic
fill -8 66 21 -4 66 21 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill -8 65 25 -4 65 25 minecraft:bamboo_mosaic
fill -8 66 25 -4 66 25 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill -8 65 21 -8 66 21 minecraft:stripped_bamboo_block[axis=y]
fill -8 67 21 -8 68 21 create:shaft[axis=y]
fill -8 65 25 -8 66 25 minecraft:stripped_bamboo_block[axis=y]
fill -8 67 25 -8 68 25 create:shaft[axis=y]
fill -4 65 21 -4 66 21 minecraft:stripped_bamboo_block[axis=y]
fill -4 67 21 -4 68 21 create:shaft[axis=y]
fill -4 65 25 -4 66 25 minecraft:stripped_bamboo_block[axis=y]
fill -4 67 25 -4 68 25 create:shaft[axis=y]
fill -4 65 23 -4 66 23 minecraft:air
setblock -6 65 23 minecraft:bamboo_pressure_plate[powered=false]
fill -8 69 21 -4 69 25 create:gearbox[axis=y]
setblock -6 70 23 create:gearbox[axis=y]
setblock -6 70 22 create:shaft[axis=z]
setblock -6 70 24 create:shaft[axis=z]
summon minecraft:marker -5.5 71 23.5 {Tags:["funk_spawn","funk_taxi"],data:{kind:"display",props:"corviknight level=50",yaw:-90}}
summon minecraft:marker -5.5 65 23.5 {Tags:["funk_cardoor","fcar_city"]}
summon minecraft:text_display -2.97 67.05 23.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[-90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Funk City\\n","color":"#FFD23F","bold":true},{"text":"Corviknight Air Taxi\\n","color":"gray"},{"text":"Step on the plate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
# --- basket to Homestead Commons: x 5..9, z 21..25, way in on the west
fill 5 64 21 9 64 25 minecraft:bamboo_mosaic
fill 5 65 21 5 65 25 minecraft:bamboo_mosaic
fill 5 66 21 5 66 25 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill 9 65 21 9 65 25 minecraft:bamboo_mosaic
fill 9 66 21 9 66 25 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill 5 65 21 9 65 21 minecraft:bamboo_mosaic
fill 5 66 21 9 66 21 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill 5 65 25 9 65 25 minecraft:bamboo_mosaic
fill 5 66 25 9 66 25 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
fill 5 65 21 5 66 21 minecraft:stripped_bamboo_block[axis=y]
fill 5 67 21 5 68 21 create:shaft[axis=y]
fill 5 65 25 5 66 25 minecraft:stripped_bamboo_block[axis=y]
fill 5 67 25 5 68 25 create:shaft[axis=y]
fill 9 65 21 9 66 21 minecraft:stripped_bamboo_block[axis=y]
fill 9 67 21 9 68 21 create:shaft[axis=y]
fill 9 65 25 9 66 25 minecraft:stripped_bamboo_block[axis=y]
fill 9 67 25 9 68 25 create:shaft[axis=y]
fill 5 65 23 5 66 23 minecraft:air
setblock 7 65 23 minecraft:bamboo_pressure_plate[powered=false]
fill 5 69 21 9 69 25 create:gearbox[axis=y]
setblock 7 70 23 create:gearbox[axis=y]
setblock 7 70 22 create:shaft[axis=z]
setblock 7 70 24 create:shaft[axis=z]
summon minecraft:marker 7.5 71 23.5 {Tags:["funk_spawn","funk_taxi"],data:{kind:"display",props:"corviknight level=50",yaw:90}}
summon minecraft:marker 7.5 65 23.5 {Tags:["funk_cardoor","fcar_commons"]}
summon minecraft:text_display 4.97 67.05 23.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Homestead Commons\\n","color":"#7DFF7D","bold":true},{"text":"Corviknight Air Taxi\\n","color":"gray"},{"text":"Step on the plate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
data modify storage funkcity:state hallBasketsV3 set value 1
