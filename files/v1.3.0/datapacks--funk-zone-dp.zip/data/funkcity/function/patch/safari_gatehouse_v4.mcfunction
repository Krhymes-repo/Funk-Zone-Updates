# Safari gatehouse v4: the Warden behind the counter. Run once in funkcity:city.
kill @e[type=minecraft:interaction,tag=safari_desk,x=58,y=62,z=-24,dx=10,dy=6,dz=8]
kill @e[type=minecraft:text_display,tag=safari_gh,x=60,y=65,z=-21,dx=7,dy=4,dz=3]
summon minecraft:text_display 63.5 67.4 -19.4 {Tags:["funk_npc","funk_label","safari_gh"],billboard:"vertical",background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text": "Safari Zone entry\\n", "color": "#FFD84F", "bold": true}, {"text": "500 · 30 Safari Balls · Bait & Rock · 20 min\\n", "color": "white", "bold": false}, {"text": "talk to the Warden", "color": "#FFE680", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
data modify storage funkcity:state safariGatehouseV4 set value 1
