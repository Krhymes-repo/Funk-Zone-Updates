# Cobblemon 1.8: TMCraft is gone, TM Records now sells Cobblemon's own TMs. Send DJ Tamsin home so she respawns with the
# new stock, and swap the two spinning display discs. Runs once per world, in funkcity:city; marks itself done once
# the shop's marker has been found.
execute as @e[type=cobbledollars:cobble_merchant,tag=fs_tm_records] at @s run function funkcity:spawn/vanish
setblock -2 65 -63 minecraft:dark_oak_sign[rotation=4]{is_waxed:1b,front_text:{messages:['{"text": "TM Records"}','{"text": "Move Discs"}','{"text": "Teach any move"}','{"text": "128 TMs"}'],color:"light_blue",has_glowing_text:1b}} replace
execute as @e[type=minecraft:item_display,tag=funk_spin,x=-1.5,y=65.35,z=-63.5,distance=..0.5] run data modify entity @s item set value {id:"cobblemon:technical_machine",count:1,components:{"cobblemon:tm_move":{move:"thunderbolt"}}}
execute as @e[type=minecraft:item_display,tag=funk_spin,x=-1.5,y=65.35,z=-57.5,distance=..0.5] run data modify entity @s item set value {id:"cobblemon:technical_machine",count:1,components:{"cobblemon:tm_move":{move:"earthquake"}}}
execute if entity @e[type=minecraft:marker,tag=funk_spawn,x=-0.5,y=64,z=-60.5,distance=..1.5,nbt={data:{shop:"tm_records"}}] run data modify storage funkcity:state tmRecords2 set value 1
