# Poke Marts v1: one Cities & Structures Poke Mart per district, on a pocket park or a spare building, with the
# district's mart clerk behind the counter. Runs once per world after the centers (CarpetFloors job), in funkcity:city.
# --- downtown: Downtown Earthworks Mart on the pocket park (tile -320,-360, door N)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-316,y=60,z=-356,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-316,y=60,z=-356,dx=31,dy=80,dz=31]
execute in funkcity:city run fill -315 64 -355 -286 99 -326 minecraft:air
execute in funkcity:city run fill -315 100 -355 -286 125 -326 minecraft:air
execute in funkcity:city run fill -315 63 -355 -286 63 -326 kantoblocks:cinnabar_floor1
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart -311 63 -351 none
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -302 63 -355 -302 63 -351 minecraft:birch_planks
execute in funkcity:city run fill -301 63 -355 -301 63 -351 minecraft:birch_planks
execute in funkcity:city run fill -300 63 -355 -300 63 -351 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker -295.5 64 -334.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_downtown",name:"Cashier",yaw:180,uid:990017}}
# --- groove: Psychic Groove Mart on the pocket park (tile -440,240, door E)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-436,y=60,z=244,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-436,y=60,z=244,dx=31,dy=80,dz=31]
execute in funkcity:city run fill -435 64 245 -406 99 274 minecraft:air
execute in funkcity:city run fill -435 100 245 -406 125 274 minecraft:air
execute in funkcity:city run fill -435 63 245 -406 63 274 kantoblocks:celadon_deptstore_floor2
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart -410 63 249 clockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -410 63 258 -406 63 258 minecraft:birch_planks
execute in funkcity:city run fill -410 63 259 -406 63 259 minecraft:birch_planks
execute in funkcity:city run fill -410 63 260 -406 63 260 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker -425.5 64 264.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_groove",name:"Cashier",yaw:270,uid:990018}}
# --- garden: Rainbow Gardens Mart on the pocket park (tile 400,440, door W)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=404,y=60,z=444,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=404,y=60,z=444,dx=31,dy=80,dz=31]
execute in funkcity:city run fill 405 64 445 434 99 474 minecraft:air
execute in funkcity:city run fill 405 100 445 434 125 474 minecraft:air
execute in funkcity:city run fill 405 63 445 434 63 474 kantoblocks:cave_1
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart 409 63 470 counterclockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 405 63 461 409 63 461 minecraft:birch_planks
execute in funkcity:city run fill 405 63 460 409 63 460 minecraft:birch_planks
execute in funkcity:city run fill 405 63 459 409 63 459 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker 425.5 64 455.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_garden",name:"Cashier",yaw:90,uid:990019}}
# --- poison: Toxic Fens Mart on the pocket park (tile 40,520, door S)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=44,y=60,z=524,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=44,y=60,z=524,dx=31,dy=80,dz=31]
execute in funkcity:city run fill 45 64 525 74 99 554 minecraft:air
execute in funkcity:city run fill 45 100 525 74 125 554 minecraft:air
execute in funkcity:city run fill 45 63 525 74 63 554 kantoblocks:lavender_floor1
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart 70 63 550 180
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 61 63 550 61 63 554 minecraft:birch_planks
execute in funkcity:city run fill 60 63 550 60 63 554 minecraft:birch_planks
execute in funkcity:city run fill 59 63 550 59 63 554 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker 55.5 64 534.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_poison",name:"Cashier",yaw:0,uid:990020}}
# --- rock: Boulder Heights Mart on the pocket park (tile 40,-600, door W)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=44,y=60,z=-596,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=44,y=60,z=-596,dx=31,dy=80,dz=31]
execute in funkcity:city run fill 45 64 -595 74 99 -566 minecraft:air
execute in funkcity:city run fill 45 100 -595 74 125 -566 minecraft:air
execute in funkcity:city run fill 45 63 -595 74 63 -566 kantoblocks:pewter_gym_floor2
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart 49 63 -570 counterclockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 45 63 -579 49 63 -579 minecraft:birch_planks
execute in funkcity:city run fill 45 63 -580 49 63 -580 minecraft:birch_planks
execute in funkcity:city run fill 45 63 -581 49 63 -581 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker 65.5 64 -584.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_rock",name:"Cashier",yaw:90,uid:990021}}
# --- harbor: Cascade Harbor Mart on the townsfolk house (tile 320,-360, door N)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=324,y=60,z=-356,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=324,y=60,z=-356,dx=31,dy=80,dz=31]
execute in funkcity:city run fill 325 64 -355 354 99 -326 minecraft:air
execute in funkcity:city run fill 325 100 -355 354 125 -326 minecraft:air
execute in funkcity:city run fill 325 63 -355 354 63 -326 kantoblocks:ss_anne_floor
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart 329 63 -351 none
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 338 63 -355 338 63 -351 minecraft:birch_planks
execute in funkcity:city run fill 339 63 -355 339 63 -351 minecraft:birch_planks
execute in funkcity:city run fill 340 63 -355 340 63 -351 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker 344.5 64 -334.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_harbor",name:"Cashier",yaw:180,uid:990022}}
# --- fire: Cinder Crater Mart on the Art Gallery (tile -600,0, door E)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=-596,y=60,z=4,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=-596,y=60,z=4,dx=31,dy=80,dz=31]
execute in funkcity:city as @e[tag=fq_critic] run function funkcity:spawn/vanish
execute in funkcity:city run fill -595 64 5 -566 99 34 minecraft:air
execute in funkcity:city run fill -595 100 5 -566 125 34 minecraft:air
execute in funkcity:city run fill -595 63 5 -566 63 34 kantoblocks:cinnabar_mansion_floor2
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart -570 63 9 clockwise_90
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill -570 63 18 -566 63 18 minecraft:birch_planks
execute in funkcity:city run fill -570 63 19 -566 63 19 minecraft:birch_planks
execute in funkcity:city run fill -570 63 20 -566 63 20 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker -585.5 64 24.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_fire",name:"Cashier",yaw:270,uid:990023}}
# --- power: Thunder District Mart on the Rotom Repair (tile 480,-80, door S)
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_pet,x=484,y=60,z=-76,dx=31,dy=80,dz=31] run function funkcity:spawn/vanish
execute in funkcity:city run kill @e[type=!minecraft:player,type=!cobblemon:pokemon,tag=!funk_quest,tag=!funk_waystone,x=484,y=60,z=-76,dx=31,dy=80,dz=31]
execute in funkcity:city as @e[tag=fq_sparky] run function funkcity:spawn/vanish
execute in funkcity:city run fill 485 64 -75 514 99 -46 minecraft:air
execute in funkcity:city run fill 485 100 -75 514 125 -46 minecraft:air
execute in funkcity:city run fill 485 63 -75 514 63 -46 kantoblocks:power_plant_floor_3
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:cc/mart 510 63 -50 180
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fill 501 63 -50 501 63 -46 minecraft:birch_planks
execute in funkcity:city run fill 500 63 -50 500 63 -46 minecraft:birch_planks
execute in funkcity:city run fill 499 63 -50 499 63 -46 minecraft:birch_planks
execute in funkcity:city run summon minecraft:marker 495.5 64 -65.5 {Tags:["funk_spawn"],data:{kind:"clerk",role:"cashier",shop:"mart_power",name:"Cashier",yaw:0,uid:990024}}
data modify storage funkcity:state martsV1 set value 1
