# the Plaza's west Corviknight basket flies to the Nexus now (was the Homestead Commons)
kill @e[type=minecraft:marker,tag=fcar_commons,x=0,y=63,z=40,dx=3,dy=3,dz=3]
summon minecraft:marker 1.5 64 41.5 {Tags:["funk_cardoor","fcar_nexus"]}
kill @e[type=minecraft:text_display,tag=funk_carlabel,x=3,y=65,z=40,dx=2,dy=2,dz=3]
summon minecraft:text_display 4.03 66.05 41.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[-90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text": "The Nexus\\n", "color": "#FFD84F", "bold": true}, {"text": "Corviknight Air Taxi\\n", "color": "gray", "bold": false}, {"text": "Step on the plate", "color": "#FFE680", "bold": false}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
data modify storage funkcity:state nexusPlazaV1 set value 1
