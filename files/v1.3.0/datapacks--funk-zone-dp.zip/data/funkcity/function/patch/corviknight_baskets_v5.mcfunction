# Plaza Corviknight baskets v5: a hot-air-balloon basket either side of the Plaza's south path, held up by a
# Corviknight instead of a balloon. Step on the plate in the basket to fly: west to Homestead Commons, east to the
# Frontier Hall (Funk Frontier TrainCars). Replaces the parked train cars (or earlier taxis). Runs once per world
# (CarpetFloors job basketsV5), in funkcity:city.
# --- whatever stood there before, lawn back under it
execute in funkcity:city run kill @e[type=minecraft:marker,tag=funk_cardoor,x=-3,y=60,z=33,dx=24,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:text_display,tag=funk_carlabel,x=-3,y=60,z=33,dx=24,dy=20,dz=16]
execute in funkcity:city run kill @e[type=minecraft:marker,tag=funk_taxi,x=-3,y=60,z=33,dx=24,dy=20,dz=16]
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_disp,x=-3,y=60,z=34,dx=8,dy=20,dz=14] run function funkcity:spawn/vanish
execute in funkcity:city as @e[type=cobblemon:pokemon,tag=funk_disp,x=13,y=60,z=34,dx=8,dy=20,dz=14] run function funkcity:spawn/vanish
execute in funkcity:city run fill -2 64 35 4 76 47 minecraft:air
execute in funkcity:city run fill 14 64 35 20 76 47 minecraft:air
execute in funkcity:city run fill -2 63 35 4 63 48 kantoblocks:grass_1
execute in funkcity:city run fill 14 63 35 20 63 48 kantoblocks:grass_1
# --- Homestead Commons basket, x -1..3, way in on the east side at 3 64 41
execute in funkcity:city run fill -2 63 37 4 63 45 minecraft:yellow_concrete
execute in funkcity:city run fill -1 63 38 3 63 44 minecraft:smooth_stone
execute in funkcity:city run fill -1 63 39 3 63 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill -1 64 39 -1 64 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill -1 65 39 -1 65 43 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill 3 64 39 3 64 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill 3 65 39 3 65 43 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill -1 64 39 3 64 39 minecraft:bamboo_mosaic
execute in funkcity:city run fill -1 65 39 3 65 39 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill -1 64 43 3 64 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill -1 65 43 3 65 43 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill -1 64 39 -1 65 39 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill -1 64 43 -1 65 43 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 3 64 39 3 65 39 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 3 64 43 3 65 43 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 3 64 41 3 65 41 minecraft:air
execute in funkcity:city run setblock 1 64 41 minecraft:bamboo_pressure_plate[powered=false]
execute in funkcity:city run fill -1 66 39 -1 70 39 create:shaft[axis=y]
execute in funkcity:city run fill -1 66 43 -1 70 43 create:shaft[axis=y]
execute in funkcity:city run fill 3 66 39 3 70 39 create:shaft[axis=y]
execute in funkcity:city run fill 3 66 43 3 70 43 create:shaft[axis=y]
execute in funkcity:city run fill -1 71 39 3 71 43 create:gearbox[axis=y]
execute in funkcity:city run setblock 1 72 41 create:gearbox[axis=y]
execute in funkcity:city run setblock 1 72 40 create:shaft[axis=z]
execute in funkcity:city run setblock 1 72 42 create:shaft[axis=z]
execute in funkcity:city run summon minecraft:marker 1.5 73 41.5 {Tags:["funk_spawn","funk_taxi"],data:{kind:"display",props:"corviknight level=50",yaw:-90}}
execute in funkcity:city run summon minecraft:marker 1.5 64 41.5 {Tags:["funk_cardoor","fcar_commons"]}
execute in funkcity:city run summon minecraft:text_display 4.03 66.05 41.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[-90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Homestead Commons\\n","color":"#7DFF7D","bold":true},{"text":"Corviknight Air Taxi\\n","color":"gray"},{"text":"Step on the plate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
# --- Frontier Hall basket, x 15..19, way in on the west side at 15 64 41
execute in funkcity:city run fill 14 63 37 20 63 45 minecraft:yellow_concrete
execute in funkcity:city run fill 15 63 38 19 63 44 minecraft:smooth_stone
execute in funkcity:city run fill 15 63 39 19 63 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill 15 64 39 15 64 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill 15 65 39 15 65 43 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill 19 64 39 19 64 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill 19 65 39 19 65 43 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill 15 64 39 19 64 39 minecraft:bamboo_mosaic
execute in funkcity:city run fill 15 65 39 19 65 39 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill 15 64 43 19 64 43 minecraft:bamboo_mosaic
execute in funkcity:city run fill 15 65 43 19 65 43 minecraft:bamboo_mosaic_slab[type=bottom,waterlogged=false]
execute in funkcity:city run fill 15 64 39 15 65 39 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 15 64 43 15 65 43 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 19 64 39 19 65 39 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 19 64 43 19 65 43 minecraft:stripped_bamboo_block[axis=y]
execute in funkcity:city run fill 15 64 41 15 65 41 minecraft:air
execute in funkcity:city run setblock 17 64 41 minecraft:bamboo_pressure_plate[powered=false]
execute in funkcity:city run fill 15 66 39 15 70 39 create:shaft[axis=y]
execute in funkcity:city run fill 15 66 43 15 70 43 create:shaft[axis=y]
execute in funkcity:city run fill 19 66 39 19 70 39 create:shaft[axis=y]
execute in funkcity:city run fill 19 66 43 19 70 43 create:shaft[axis=y]
execute in funkcity:city run fill 15 71 39 19 71 43 create:gearbox[axis=y]
execute in funkcity:city run setblock 17 72 41 create:gearbox[axis=y]
execute in funkcity:city run setblock 17 72 40 create:shaft[axis=z]
execute in funkcity:city run setblock 17 72 42 create:shaft[axis=z]
execute in funkcity:city run summon minecraft:marker 17.5 73 41.5 {Tags:["funk_spawn","funk_taxi"],data:{kind:"display",props:"corviknight level=50",yaw:90}}
execute in funkcity:city run summon minecraft:marker 17.5 64 41.5 {Tags:["funk_cardoor","fcar_hall"]}
execute in funkcity:city run summon minecraft:text_display 14.97 66.05 41.5 {Tags:["funk_npc","funk_label","funk_carlabel"],billboard:"fixed",Rotation:[90f,0f],background:-871296751,line_width:220,brightness:{sky:15,block:15},text:'[{"text":"Frontier Hall\\n","color":"#FF4FD8","bold":true},{"text":"Corviknight Air Taxi\\n","color":"gray"},{"text":"Step on the plate","color":"#FFE680"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
execute in funkcity:city run summon minecraft:text_display 1.5 65.0 46.5 {Tags:["funk_npc","funk_label","funk_carlabel","ftb_wilds"],billboard:"vertical",background:-871296751,line_width:200,brightness:{sky:15,block:15},text:'{"text":"Out in the Wilds now:","color":"#7CFC9A","bold":true}',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
data modify storage funkcity:state basketsV5 set value 1
