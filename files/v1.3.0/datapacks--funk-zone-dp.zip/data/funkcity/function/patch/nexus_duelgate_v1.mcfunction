# the Duel World gate in the Duel Hall is walled up: Duel World is reached from the Nexus
kill @e[type=!minecraft:player,tag=dw_citygate,x=60,y=62,z=-20,dx=9,dy=9,dz=14]
fill 67 64 -14 67 67 -12 minecraft:smooth_sandstone
fill 67 63 -14 67 63 -12 minecraft:smooth_sandstone
data modify storage funkcity:state nexusDuelGateV1 set value 1
