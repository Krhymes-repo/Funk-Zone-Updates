# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-369,y=-64,z=727,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-369,y=-64,z=727,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-369,y=-64,z=727,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-369,y=-64,z=727,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-369,y=-64,z=727,dx=18,dy=384,dz=18]
fill -364 119 732 -356 132 740 minecraft:air replace #minecraft:leaves
fill -364 119 732 -356 132 740 minecraft:air replace #minecraft:logs
fill -364 119 732 -356 132 740 minecraft:air replace #minecraft:replaceable
fill -364 119 732 -356 132 740 minecraft:air replace #minecraft:flowers
fill -364 119 732 -356 132 740 minecraft:air replace #minecraft:saplings
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:cactus
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:sugar_cane
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:bamboo
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:sweet_berry_bush
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:vine
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:dead_bush
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:snow
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:moss_carpet
fill -364 119 732 -356 132 740 minecraft:air replace minecraft:pink_petals
fill -363 118 733 -357 118 739 minecraft:grass_block
fill -365 119 731 -355 140 741 minecraft:air replace #minecraft:leaves
fill -365 119 731 -355 140 741 minecraft:air replace #minecraft:logs
fill -365 119 731 -355 140 741 minecraft:air replace #minecraft:replaceable
fill -365 119 731 -355 140 741 minecraft:air replace #minecraft:flowers
fill -365 119 731 -355 140 741 minecraft:air replace #minecraft:saplings
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:cactus
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:sugar_cane
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:bamboo
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:sweet_berry_bush
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:vine
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:dead_bush
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:snow
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:moss_carpet
fill -365 119 731 -355 140 741 minecraft:air replace minecraft:pink_petals
setblock -360 119 736 minecraft:campfire[lit=false]
setblock -358 119 736 minecraft:mossy_cobblestone_slab
setblock -362 119 736 minecraft:mossy_cobblestone_slab
setblock -360 119 738 minecraft:mossy_cobblestone_slab
setblock -360 119 734 minecraft:mossy_cobblestone_slab
setblock -363 119 735 minecraft:brown_carpet
setblock -363 119 736 minecraft:brown_carpet
setblock -363 119 737 minecraft:white_carpet
setblock -357 119 735 minecraft:spruce_fence
setblock -357 120 735 minecraft:lantern[hanging=false]
setblock -359 119 738 minecraft:chest[facing=north]
setblock -358 119 738 minecraft:barrel[facing=up]
summon minecraft:item_frame -358 120 738 {Facing:1b,Invisible:1b,Fixed:1b,Invulnerable:1b,Tags:["wf_prop"],Item:{id:"minecraft:spyglass",count:1}}
setblock -362 119 733 minecraft:spruce_fence
setblock -362 120 733 minecraft:spruce_fence
setblock -362 121 733 minecraft:light_gray_banner[rotation=0]
