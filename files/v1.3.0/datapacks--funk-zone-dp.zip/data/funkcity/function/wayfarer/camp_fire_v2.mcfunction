# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-785,y=-64,z=119,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-785,y=-64,z=119,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-785,y=-64,z=119,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-785,y=-64,z=119,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-785,y=-64,z=119,dx=18,dy=384,dz=18]
fill -780 78 124 -772 91 132 minecraft:air replace #minecraft:leaves
fill -780 78 124 -772 91 132 minecraft:air replace #minecraft:logs
fill -780 78 124 -772 91 132 minecraft:air replace #minecraft:replaceable
fill -780 78 124 -772 91 132 minecraft:air replace #minecraft:flowers
fill -780 78 124 -772 91 132 minecraft:air replace #minecraft:saplings
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:cactus
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:sugar_cane
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:bamboo
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:sweet_berry_bush
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:vine
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:dead_bush
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:snow
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:moss_carpet
fill -780 78 124 -772 91 132 minecraft:air replace minecraft:pink_petals
fill -779 77 125 -773 77 131 minecraft:grass_block
fill -781 78 123 -771 99 133 minecraft:air replace #minecraft:leaves
fill -781 78 123 -771 99 133 minecraft:air replace #minecraft:logs
fill -781 78 123 -771 99 133 minecraft:air replace #minecraft:replaceable
fill -781 78 123 -771 99 133 minecraft:air replace #minecraft:flowers
fill -781 78 123 -771 99 133 minecraft:air replace #minecraft:saplings
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:cactus
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:sugar_cane
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:bamboo
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:sweet_berry_bush
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:vine
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:dead_bush
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:snow
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:moss_carpet
fill -781 78 123 -771 99 133 minecraft:air replace minecraft:pink_petals
setblock -776 78 128 minecraft:campfire[lit=false]
setblock -774 78 128 minecraft:mossy_cobblestone_slab
setblock -778 78 128 minecraft:mossy_cobblestone_slab
setblock -776 78 130 minecraft:mossy_cobblestone_slab
setblock -776 78 126 minecraft:mossy_cobblestone_slab
setblock -779 78 127 minecraft:brown_carpet
setblock -779 78 128 minecraft:brown_carpet
setblock -779 78 129 minecraft:white_carpet
setblock -773 78 127 minecraft:spruce_fence
setblock -773 79 127 minecraft:lantern[hanging=false]
setblock -775 78 130 minecraft:chest[facing=north]
setblock -774 78 130 minecraft:barrel[facing=up]
setblock -773 78 129 minecraft:chipped_anvil
setblock -778 78 125 minecraft:spruce_fence
setblock -778 79 125 minecraft:spruce_fence
setblock -778 80 125 minecraft:light_gray_banner[rotation=0]
