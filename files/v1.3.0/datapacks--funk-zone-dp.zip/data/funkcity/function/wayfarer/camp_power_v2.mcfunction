# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=775,y=-64,z=291,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=775,y=-64,z=291,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=775,y=-64,z=291,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=775,y=-64,z=291,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=775,y=-64,z=291,dx=18,dy=384,dz=18]
fill 780 73 296 788 86 304 minecraft:air replace #minecraft:leaves
fill 780 73 296 788 86 304 minecraft:air replace #minecraft:logs
fill 780 73 296 788 86 304 minecraft:air replace #minecraft:replaceable
fill 780 73 296 788 86 304 minecraft:air replace #minecraft:flowers
fill 780 73 296 788 86 304 minecraft:air replace #minecraft:saplings
fill 780 73 296 788 86 304 minecraft:air replace minecraft:cactus
fill 780 73 296 788 86 304 minecraft:air replace minecraft:sugar_cane
fill 780 73 296 788 86 304 minecraft:air replace minecraft:bamboo
fill 780 73 296 788 86 304 minecraft:air replace minecraft:sweet_berry_bush
fill 780 73 296 788 86 304 minecraft:air replace minecraft:vine
fill 780 73 296 788 86 304 minecraft:air replace minecraft:dead_bush
fill 780 73 296 788 86 304 minecraft:air replace minecraft:snow
fill 780 73 296 788 86 304 minecraft:air replace minecraft:moss_carpet
fill 780 73 296 788 86 304 minecraft:air replace minecraft:pink_petals
fill 781 72 297 787 72 303 minecraft:grass_block
fill 779 73 295 789 94 305 minecraft:air replace #minecraft:leaves
fill 779 73 295 789 94 305 minecraft:air replace #minecraft:logs
fill 779 73 295 789 94 305 minecraft:air replace #minecraft:replaceable
fill 779 73 295 789 94 305 minecraft:air replace #minecraft:flowers
fill 779 73 295 789 94 305 minecraft:air replace #minecraft:saplings
fill 779 73 295 789 94 305 minecraft:air replace minecraft:cactus
fill 779 73 295 789 94 305 minecraft:air replace minecraft:sugar_cane
fill 779 73 295 789 94 305 minecraft:air replace minecraft:bamboo
fill 779 73 295 789 94 305 minecraft:air replace minecraft:sweet_berry_bush
fill 779 73 295 789 94 305 minecraft:air replace minecraft:vine
fill 779 73 295 789 94 305 minecraft:air replace minecraft:dead_bush
fill 779 73 295 789 94 305 minecraft:air replace minecraft:snow
fill 779 73 295 789 94 305 minecraft:air replace minecraft:moss_carpet
fill 779 73 295 789 94 305 minecraft:air replace minecraft:pink_petals
setblock 784 73 300 minecraft:campfire[lit=false]
setblock 786 73 300 minecraft:mossy_cobblestone_slab
setblock 782 73 300 minecraft:mossy_cobblestone_slab
setblock 784 73 302 minecraft:mossy_cobblestone_slab
setblock 784 73 298 minecraft:mossy_cobblestone_slab
setblock 781 73 299 minecraft:brown_carpet
setblock 781 73 300 minecraft:brown_carpet
setblock 781 73 301 minecraft:white_carpet
setblock 787 73 299 minecraft:spruce_fence
setblock 787 74 299 minecraft:lantern[hanging=false]
setblock 785 73 302 minecraft:chest[facing=north]
setblock 786 73 302 minecraft:barrel[facing=up]
setblock 787 73 301 minecraft:lightning_rod
setblock 782 73 297 minecraft:spruce_fence
setblock 782 74 297 minecraft:spruce_fence
setblock 782 75 297 minecraft:light_gray_banner[rotation=0]
