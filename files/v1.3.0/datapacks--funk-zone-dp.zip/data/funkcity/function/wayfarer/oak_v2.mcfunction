# The Struck Oak - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=852,y=-64,z=331,dx=24,dy=384,dz=25]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=852,y=-64,z=331,dx=24,dy=384,dz=25]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=852,y=-64,z=331,dx=24,dy=384,dz=25]
kill @e[type=minecraft:minecart,tag=wf_prop,x=852,y=-64,z=331,dx=24,dy=384,dz=25]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=852,y=-64,z=331,dx=24,dy=384,dz=25]
fill 856 70 336 872 83 352 minecraft:air replace #minecraft:leaves
fill 856 70 336 872 83 352 minecraft:air replace #minecraft:logs
fill 856 70 336 872 83 352 minecraft:air replace #minecraft:replaceable
fill 856 70 336 872 83 352 minecraft:air replace #minecraft:flowers
fill 856 70 336 872 83 352 minecraft:air replace #minecraft:saplings
fill 856 70 336 872 83 352 minecraft:air replace minecraft:cactus
fill 856 70 336 872 83 352 minecraft:air replace minecraft:sugar_cane
fill 856 70 336 872 83 352 minecraft:air replace minecraft:bamboo
fill 856 70 336 872 83 352 minecraft:air replace minecraft:sweet_berry_bush
fill 856 70 336 872 83 352 minecraft:air replace minecraft:vine
fill 856 70 336 872 83 352 minecraft:air replace minecraft:dead_bush
fill 856 70 336 872 83 352 minecraft:air replace minecraft:snow
fill 856 70 336 872 83 352 minecraft:air replace minecraft:moss_carpet
fill 856 70 336 872 83 352 minecraft:air replace minecraft:pink_petals
setblock 866 69 344 minecraft:glass
setblock 867 69 344 minecraft:black_concrete_powder
setblock 868 69 344 minecraft:black_concrete_powder
setblock 869 69 344 minecraft:gray_concrete_powder
setblock 870 69 345 minecraft:black_concrete_powder
setblock 871 69 345 minecraft:tinted_glass
setblock 872 70 345 minecraft:gray_concrete_powder
setblock 866 69 345 minecraft:black_concrete_powder
setblock 866 69 346 minecraft:black_concrete_powder
setblock 867 69 346 minecraft:glass
setblock 868 69 347 minecraft:glass
setblock 869 69 348 minecraft:black_concrete_powder
setblock 870 69 348 minecraft:coal_block
setblock 870 69 349 minecraft:black_concrete_powder
setblock 864 69 346 minecraft:gray_concrete_powder
setblock 864 69 347 minecraft:black_concrete_powder
setblock 865 69 348 minecraft:coal_block
setblock 865 69 349 minecraft:gray_concrete_powder
setblock 865 69 350 minecraft:black_concrete_powder
setblock 865 69 351 minecraft:gray_concrete_powder
setblock 863 69 346 minecraft:coal_block
setblock 863 69 347 minecraft:black_concrete_powder
setblock 862 69 348 minecraft:gray_concrete_powder
setblock 862 69 348 minecraft:coal_block
setblock 861 69 349 minecraft:tinted_glass
setblock 861 69 350 minecraft:glass
setblock 862 69 345 minecraft:gray_concrete_powder
setblock 861 69 346 minecraft:tinted_glass
setblock 861 69 346 minecraft:gray_concrete_powder
setblock 860 69 347 minecraft:coal_block
setblock 859 69 347 minecraft:black_concrete_powder
setblock 858 70 348 minecraft:gray_concrete_powder
setblock 862 69 344 minecraft:tinted_glass
setblock 861 69 343 minecraft:black_concrete_powder
setblock 860 69 343 minecraft:gray_concrete_powder
setblock 859 69 343 minecraft:black_concrete_powder
setblock 858 69 343 minecraft:gray_concrete_powder
setblock 857 69 343 minecraft:black_concrete_powder
setblock 856 69 343 minecraft:gray_concrete_powder
setblock 862 69 343 minecraft:tinted_glass
setblock 862 69 342 minecraft:glass
setblock 861 69 341 minecraft:gray_concrete_powder
setblock 860 69 341 minecraft:glass
setblock 859 69 340 minecraft:tinted_glass
setblock 859 69 340 minecraft:tinted_glass
setblock 858 70 339 minecraft:coal_block
setblock 857 70 338 minecraft:coal_block
setblock 856 70 338 minecraft:coal_block
setblock 863 69 342 minecraft:gray_concrete_powder
setblock 863 70 341 minecraft:glass
setblock 863 70 340 minecraft:tinted_glass
setblock 863 70 339 minecraft:glass
setblock 862 70 338 minecraft:tinted_glass
setblock 862 70 337 minecraft:gray_concrete_powder
setblock 862 71 336 minecraft:black_concrete_powder
setblock 861 71 335 minecraft:black_concrete_powder
setblock 865 70 342 minecraft:tinted_glass
setblock 865 70 341 minecraft:coal_block
setblock 866 70 340 minecraft:glass
setblock 866 70 340 minecraft:glass
setblock 867 70 339 minecraft:black_concrete_powder
setblock 867 70 338 minecraft:black_concrete_powder
setblock 868 70 337 minecraft:gray_concrete_powder
setblock 866 69 343 minecraft:tinted_glass
setblock 867 70 343 minecraft:tinted_glass
setblock 868 70 342 minecraft:gray_concrete_powder
setblock 868 70 342 minecraft:glass
setblock 869 70 341 minecraft:gray_concrete_powder
setblock 870 70 341 minecraft:glass
setblock 871 70 340 minecraft:black_concrete_powder
setblock 872 70 340 minecraft:black_concrete_powder
setblock 863 69 343 minecraft:tinted_glass
setblock 863 69 344 minecraft:coal_block
setblock 863 69 345 minecraft:tinted_glass
setblock 864 69 343 minecraft:coal_block
setblock 864 69 344 minecraft:tinted_glass
setblock 864 69 345 minecraft:coal_block
setblock 865 69 343 minecraft:tinted_glass
setblock 865 69 344 minecraft:coal_block
setblock 865 69 345 minecraft:tinted_glass
setblock 864 70 344 minecraft:stripped_dark_oak_log
setblock 864 71 344 minecraft:stripped_dark_oak_log
setblock 864 72 344 minecraft:stripped_dark_oak_log
setblock 864 73 344 minecraft:stripped_dark_oak_log
setblock 865 73 344 minecraft:stripped_oak_log
setblock 864 74 344 minecraft:stripped_dark_oak_log
setblock 865 74 344 minecraft:stripped_oak_log
setblock 864 75 344 minecraft:stripped_dark_oak_log
setblock 865 75 344 minecraft:coal_block
setblock 864 76 344 minecraft:dark_oak_log
setblock 865 76 344 minecraft:stripped_oak_log
setblock 864 77 344 minecraft:dark_oak_log
setblock 865 77 344 minecraft:stripped_oak_log
setblock 864 73 344 minecraft:coal_block
setblock 864 74 344 minecraft:magma_block
setblock 865 78 344 minecraft:stripped_dark_oak_wood
setblock 866 79 345 minecraft:dark_oak_fence
setblock 863 77 344 minecraft:stripped_dark_oak_wood
setblock 862 78 343 minecraft:stripped_dark_oak_wood
setblock 864 76 345 minecraft:stripped_dark_oak_wood
setblock 864 77 346 minecraft:stripped_dark_oak_wood
setblock 865 79 343 minecraft:dark_oak_fence
setblock 866 80 342 minecraft:dark_oak_fence
setblock 863 79 345 minecraft:dark_oak_fence
setblock 866 70 345 minecraft:dark_oak_log[axis=x]
setblock 863 70 342 minecraft:dark_oak_log[axis=z]
setblock 867 70 342 minecraft:lightning_rod
