# The Summit Register - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=169,y=-64,z=-973,dx=14,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=169,y=-64,z=-973,dx=14,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=169,y=-64,z=-973,dx=14,dy=384,dz=14]
kill @e[type=minecraft:minecart,tag=wf_prop,x=169,y=-64,z=-973,dx=14,dy=384,dz=14]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=169,y=-64,z=-973,dx=14,dy=384,dz=14]
fill 173 91 -969 179 104 -963 minecraft:air replace #minecraft:leaves
fill 173 91 -969 179 104 -963 minecraft:air replace #minecraft:logs
fill 173 91 -969 179 104 -963 minecraft:air replace #minecraft:replaceable
fill 173 91 -969 179 104 -963 minecraft:air replace #minecraft:flowers
fill 173 91 -969 179 104 -963 minecraft:air replace #minecraft:saplings
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:cactus
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:sugar_cane
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:bamboo
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:sweet_berry_bush
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:vine
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:dead_bush
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:snow
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:moss_carpet
fill 173 91 -969 179 104 -963 minecraft:air replace minecraft:pink_petals
fill 174 88 -967 174 89 -967 minecraft:stone
fill 174 88 -966 174 89 -966 minecraft:stone
fill 174 88 -965 174 89 -965 minecraft:stone
fill 174 88 -964 174 89 -964 minecraft:stone
fill 175 88 -968 175 89 -968 minecraft:stone
fill 175 88 -964 175 89 -964 minecraft:stone
fill 174 90 -968 178 90 -964 minecraft:coarse_dirt
setblock 175 91 -967 minecraft:mossy_cobblestone
setblock 175 91 -966 minecraft:cobblestone
setblock 175 91 -965 minecraft:mossy_cobblestone
setblock 176 91 -967 minecraft:cobblestone
setblock 176 91 -966 minecraft:mossy_cobblestone
setblock 176 91 -965 minecraft:cobblestone
setblock 177 91 -967 minecraft:mossy_cobblestone
setblock 177 91 -966 minecraft:cobblestone
setblock 177 91 -965 minecraft:mossy_cobblestone
setblock 176 92 -966 minecraft:cobblestone
setblock 177 92 -966 minecraft:cobblestone_wall
setblock 176 92 -965 minecraft:mossy_cobblestone_wall
setblock 176 93 -966 minecraft:cobblestone_wall
setblock 176 94 -966 minecraft:lightning_rod
setblock 176 91 -964 minecraft:chest[facing=south]
setblock 178 91 -967 minecraft:spruce_fence
setblock 178 92 -967 minecraft:spruce_fence
setblock 178 93 -967 minecraft:spruce_fence
setblock 178 94 -967 minecraft:yellow_banner[rotation=4]
summon minecraft:text_display 176.50 92.30 -964.53 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "SUMMIT REGISTER\\n", "color": "#F3E5AB", "bold": true}, {"text": "sign your name, climber", "color": "#C8BC98"}]',background:1711276032,line_width:120,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]},brightness:{sky:15,block:15}}
