# The Lantern Man - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-71,y=-64,z=985,dx=14,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-71,y=-64,z=985,dx=14,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-71,y=-64,z=985,dx=14,dy=384,dz=14]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-71,y=-64,z=985,dx=14,dy=384,dz=14]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-71,y=-64,z=985,dx=14,dy=384,dz=14]
fill -67 66 989 -61 77 995 minecraft:air replace #minecraft:leaves
fill -67 66 989 -61 77 995 minecraft:air replace #minecraft:logs
fill -67 66 989 -61 77 995 minecraft:air replace #minecraft:replaceable
fill -67 66 989 -61 77 995 minecraft:air replace #minecraft:flowers
fill -67 66 989 -61 77 995 minecraft:air replace #minecraft:saplings
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:cactus
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:sugar_cane
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:bamboo
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:sweet_berry_bush
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:vine
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:dead_bush
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:snow
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:moss_carpet
fill -67 66 989 -61 77 995 minecraft:air replace minecraft:pink_petals
fill -65 65 992 -63 65 994 minecraft:coarse_dirt
setblock -64 66 991 minecraft:spruce_fence
setblock -64 67 991 minecraft:spruce_fence
setblock -64 68 991 minecraft:spruce_fence
setblock -64 66 993 minecraft:moss_carpet
setblock -65 66 994 minecraft:lily_of_the_valley
setblock -63 66 991 minecraft:lantern[hanging=false]
setblock -65 66 991 minecraft:chest[facing=south]
summon minecraft:text_display -63.50 67.50 991.53 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "WREN ALDOUS\\n", "color": "#D8D0E8", "bold": true}, {"text": "surveyor, Wayfarer Expedition\\n", "color": "#B0A8C0"}, {"text": "\\"I followed the light.\\"", "color": "#9890A8", "italic": true}]',background:1711276032,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]},brightness:{sky:15,block:15}}
