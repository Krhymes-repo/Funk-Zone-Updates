# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-5,y=-64,z=799,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-5,y=-64,z=799,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-5,y=-64,z=799,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-5,y=-64,z=799,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-5,y=-64,z=799,dx=18,dy=384,dz=18]
fill 0 67 804 8 80 812 minecraft:air replace #minecraft:leaves
fill 0 67 804 8 80 812 minecraft:air replace #minecraft:logs
fill 0 67 804 8 80 812 minecraft:air replace #minecraft:replaceable
fill 0 67 804 8 80 812 minecraft:air replace #minecraft:flowers
fill 0 67 804 8 80 812 minecraft:air replace #minecraft:saplings
fill 0 67 804 8 80 812 minecraft:air replace minecraft:cactus
fill 0 67 804 8 80 812 minecraft:air replace minecraft:sugar_cane
fill 0 67 804 8 80 812 minecraft:air replace minecraft:bamboo
fill 0 67 804 8 80 812 minecraft:air replace minecraft:sweet_berry_bush
fill 0 67 804 8 80 812 minecraft:air replace minecraft:vine
fill 0 67 804 8 80 812 minecraft:air replace minecraft:dead_bush
fill 0 67 804 8 80 812 minecraft:air replace minecraft:snow
fill 0 67 804 8 80 812 minecraft:air replace minecraft:moss_carpet
fill 0 67 804 8 80 812 minecraft:air replace minecraft:pink_petals
fill 1 66 805 7 66 811 minecraft:grass_block
fill -1 67 803 9 88 813 minecraft:air replace #minecraft:leaves
fill -1 67 803 9 88 813 minecraft:air replace #minecraft:logs
fill -1 67 803 9 88 813 minecraft:air replace #minecraft:replaceable
fill -1 67 803 9 88 813 minecraft:air replace #minecraft:flowers
fill -1 67 803 9 88 813 minecraft:air replace #minecraft:saplings
fill -1 67 803 9 88 813 minecraft:air replace minecraft:cactus
fill -1 67 803 9 88 813 minecraft:air replace minecraft:sugar_cane
fill -1 67 803 9 88 813 minecraft:air replace minecraft:bamboo
fill -1 67 803 9 88 813 minecraft:air replace minecraft:sweet_berry_bush
fill -1 67 803 9 88 813 minecraft:air replace minecraft:vine
fill -1 67 803 9 88 813 minecraft:air replace minecraft:dead_bush
fill -1 67 803 9 88 813 minecraft:air replace minecraft:snow
fill -1 67 803 9 88 813 minecraft:air replace minecraft:moss_carpet
fill -1 67 803 9 88 813 minecraft:air replace minecraft:pink_petals
setblock 4 67 808 minecraft:campfire[lit=false]
setblock 6 67 808 minecraft:mossy_cobblestone_slab
setblock 2 67 808 minecraft:mossy_cobblestone_slab
setblock 4 67 810 minecraft:mossy_cobblestone_slab
setblock 4 67 806 minecraft:mossy_cobblestone_slab
setblock 1 67 807 minecraft:brown_carpet
setblock 1 67 808 minecraft:brown_carpet
setblock 1 67 809 minecraft:white_carpet
setblock 7 67 807 minecraft:spruce_fence
setblock 7 68 807 minecraft:lantern[hanging=false]
setblock 5 67 810 minecraft:chest[facing=north]
setblock 6 67 810 minecraft:barrel[facing=up]
setblock 6 68 810 minecraft:candle[candles=3,lit=false]
setblock 2 67 805 minecraft:spruce_fence
setblock 2 68 805 minecraft:spruce_fence
setblock 2 69 805 minecraft:light_gray_banner[rotation=0]
