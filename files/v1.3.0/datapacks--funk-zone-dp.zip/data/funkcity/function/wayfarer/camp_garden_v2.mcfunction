# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=351,y=-64,z=683,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=351,y=-64,z=683,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=351,y=-64,z=683,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=351,y=-64,z=683,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=351,y=-64,z=683,dx=18,dy=384,dz=18]
fill 356 67 688 364 80 696 minecraft:air replace #minecraft:leaves
fill 356 67 688 364 80 696 minecraft:air replace #minecraft:logs
fill 356 67 688 364 80 696 minecraft:air replace #minecraft:replaceable
fill 356 67 688 364 80 696 minecraft:air replace #minecraft:flowers
fill 356 67 688 364 80 696 minecraft:air replace #minecraft:saplings
fill 356 67 688 364 80 696 minecraft:air replace minecraft:cactus
fill 356 67 688 364 80 696 minecraft:air replace minecraft:sugar_cane
fill 356 67 688 364 80 696 minecraft:air replace minecraft:bamboo
fill 356 67 688 364 80 696 minecraft:air replace minecraft:sweet_berry_bush
fill 356 67 688 364 80 696 minecraft:air replace minecraft:vine
fill 356 67 688 364 80 696 minecraft:air replace minecraft:dead_bush
fill 356 67 688 364 80 696 minecraft:air replace minecraft:snow
fill 356 67 688 364 80 696 minecraft:air replace minecraft:moss_carpet
fill 356 67 688 364 80 696 minecraft:air replace minecraft:pink_petals
fill 357 66 689 363 66 695 minecraft:sand
fill 355 67 687 365 88 697 minecraft:air replace #minecraft:leaves
fill 355 67 687 365 88 697 minecraft:air replace #minecraft:logs
fill 355 67 687 365 88 697 minecraft:air replace #minecraft:replaceable
fill 355 67 687 365 88 697 minecraft:air replace #minecraft:flowers
fill 355 67 687 365 88 697 minecraft:air replace #minecraft:saplings
fill 355 67 687 365 88 697 minecraft:air replace minecraft:cactus
fill 355 67 687 365 88 697 minecraft:air replace minecraft:sugar_cane
fill 355 67 687 365 88 697 minecraft:air replace minecraft:bamboo
fill 355 67 687 365 88 697 minecraft:air replace minecraft:sweet_berry_bush
fill 355 67 687 365 88 697 minecraft:air replace minecraft:vine
fill 355 67 687 365 88 697 minecraft:air replace minecraft:dead_bush
fill 355 67 687 365 88 697 minecraft:air replace minecraft:snow
fill 355 67 687 365 88 697 minecraft:air replace minecraft:moss_carpet
fill 355 67 687 365 88 697 minecraft:air replace minecraft:pink_petals
setblock 360 67 692 minecraft:campfire[lit=false]
setblock 362 67 692 minecraft:mossy_cobblestone_slab
setblock 358 67 692 minecraft:mossy_cobblestone_slab
setblock 360 67 694 minecraft:mossy_cobblestone_slab
setblock 360 67 690 minecraft:mossy_cobblestone_slab
setblock 357 67 691 minecraft:brown_carpet
setblock 357 67 692 minecraft:brown_carpet
setblock 357 67 693 minecraft:white_carpet
setblock 363 67 691 minecraft:spruce_fence
setblock 363 68 691 minecraft:lantern[hanging=false]
setblock 361 67 694 minecraft:chest[facing=north]
setblock 362 67 694 minecraft:barrel[facing=up]
setblock 362 68 694 minecraft:potted_cornflower
setblock 358 67 689 minecraft:spruce_fence
setblock 358 68 689 minecraft:spruce_fence
setblock 358 69 689 minecraft:light_gray_banner[rotation=0]
