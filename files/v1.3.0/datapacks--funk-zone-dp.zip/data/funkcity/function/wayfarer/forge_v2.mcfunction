# The Cold Forge - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-878,y=-64,z=-242,dx=20,dy=384,dz=20]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-878,y=-64,z=-242,dx=20,dy=384,dz=20]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-878,y=-64,z=-242,dx=20,dy=384,dz=20]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-878,y=-64,z=-242,dx=20,dy=384,dz=20]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-878,y=-64,z=-242,dx=20,dy=384,dz=20]
fill -874 64 -238 -862 77 -226 minecraft:air replace #minecraft:leaves
fill -874 64 -238 -862 77 -226 minecraft:air replace #minecraft:logs
fill -874 64 -238 -862 77 -226 minecraft:air replace #minecraft:replaceable
fill -874 64 -238 -862 77 -226 minecraft:air replace #minecraft:flowers
fill -874 64 -238 -862 77 -226 minecraft:air replace #minecraft:saplings
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:cactus
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:sugar_cane
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:bamboo
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:sweet_berry_bush
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:vine
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:dead_bush
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:snow
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:moss_carpet
fill -874 64 -238 -862 77 -226 minecraft:air replace minecraft:pink_petals
fill -873 64 -229 -873 64 -229 minecraft:air
fill -873 64 -228 -873 64 -228 minecraft:air
fill -873 64 -227 -873 64 -227 minecraft:air
fill -872 64 -229 -872 64 -229 minecraft:air
fill -872 64 -228 -872 64 -228 minecraft:air
fill -872 64 -227 -872 64 -227 minecraft:air
fill -871 64 -229 -871 64 -229 minecraft:air
fill -871 64 -228 -871 64 -228 minecraft:air
fill -871 64 -227 -871 64 -227 minecraft:air
fill -870 64 -229 -870 64 -229 minecraft:air
fill -870 64 -228 -870 64 -228 minecraft:air
fill -870 64 -227 -870 64 -227 minecraft:air
fill -869 64 -228 -869 64 -228 minecraft:air
fill -869 64 -227 -869 64 -227 minecraft:air
fill -868 64 -228 -868 64 -228 minecraft:air
fill -868 64 -227 -868 64 -227 minecraft:air
fill -867 64 -228 -867 64 -228 minecraft:air
fill -867 64 -227 -867 64 -227 minecraft:air
fill -866 64 -227 -866 64 -227 minecraft:air
fill -865 64 -227 -865 64 -227 minecraft:air
fill -864 64 -227 -864 64 -227 minecraft:air
fill -863 64 -227 -863 64 -227 minecraft:air
fill -873 63 -237 -863 63 -227 minecraft:red_sand
fill -872 63 -236 -864 63 -228 minecraft:polished_blackstone_bricks
fill -872 64 -236 -872 67 -236 minecraft:stripped_dark_oak_log
fill -864 64 -236 -864 67 -236 minecraft:stripped_dark_oak_log
fill -872 64 -228 -872 67 -228 minecraft:stripped_dark_oak_log
fill -864 64 -228 -864 67 -228 minecraft:stripped_dark_oak_log
setblock -872 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -872 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -872 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -872 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -872 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -872 68 -229 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -236 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -232 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -871 68 -228 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -236 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -232 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -229 minecraft:dark_oak_slab[type=bottom]
setblock -870 68 -228 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -236 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -232 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -229 minecraft:dark_oak_slab[type=bottom]
setblock -869 68 -228 minecraft:dark_oak_slab[type=bottom]
setblock -868 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -868 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -868 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -868 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -868 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -868 68 -229 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -236 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -232 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -867 68 -228 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -236 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -232 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -229 minecraft:dark_oak_slab[type=bottom]
setblock -866 68 -228 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -236 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -232 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -229 minecraft:dark_oak_slab[type=bottom]
setblock -865 68 -228 minecraft:dark_oak_slab[type=bottom]
setblock -864 68 -235 minecraft:dark_oak_slab[type=bottom]
setblock -864 68 -234 minecraft:dark_oak_slab[type=bottom]
setblock -864 68 -233 minecraft:dark_oak_slab[type=bottom]
setblock -864 68 -231 minecraft:dark_oak_slab[type=bottom]
setblock -864 68 -230 minecraft:dark_oak_slab[type=bottom]
setblock -864 68 -229 minecraft:dark_oak_slab[type=bottom]
fill -870 64 -236 -866 66 -235 minecraft:bricks
fill -869 64 -235 -867 65 -235 minecraft:air
setblock -868 64 -235 minecraft:campfire[lit=false,facing=south]
fill -869 67 -236 -867 71 -235 minecraft:bricks
setblock -869 64 -234 minecraft:blast_furnace[facing=south,lit=false]
setblock -867 64 -234 minecraft:water_cauldron[level=2]
setblock -868 64 -232 minecraft:damaged_anvil[facing=east]
setblock -865 64 -231 minecraft:grindstone[face=floor,facing=west]
setblock -871 64 -231 minecraft:barrel[facing=east]
setblock -871 64 -230 minecraft:smithing_table
summon minecraft:text_display -867.50 66.80 -234.47 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "THE COLD FORGE\\n", "color": "#F0B080", "bold": true}, {"text": "light it. leave the iron.\\nreturn at first light.", "color": "#C8A088"}]',background:1711276032,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]},brightness:{sky:15,block:15}}
