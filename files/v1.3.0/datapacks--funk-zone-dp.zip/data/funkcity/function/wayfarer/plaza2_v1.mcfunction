# The Wayfarer Expedition: Old Tamsin's fire and the Wilds Discovery Board (Funk Frontier Wayfarers.java runs this once)
fill 66 64 -42 72 67 -36 minecraft:air replace #minecraft:replaceable
setblock 69 64 -39 minecraft:campfire[lit=true]
setblock 70 63 -39 minecraft:cobblestone
setblock 68 63 -39 minecraft:cobblestone
setblock 69 63 -38 minecraft:cobblestone
setblock 69 63 -40 minecraft:cobblestone
setblock 70 63 -38 minecraft:mossy_cobblestone
setblock 68 63 -40 minecraft:mossy_cobblestone
setblock 70 63 -40 minecraft:mossy_cobblestone
setblock 68 63 -38 minecraft:mossy_cobblestone
setblock 71 64 -40 minecraft:stripped_oak_log[axis=z]
setblock 71 64 -39 minecraft:stripped_oak_log[axis=z]
setblock 67 64 -39 minecraft:stripped_oak_log[axis=z]
setblock 67 64 -38 minecraft:stripped_oak_log[axis=z]
setblock 66 64 -41 minecraft:barrel[facing=up]
setblock 66 65 -41 minecraft:lantern[hanging=false]
setblock 72 64 -37 minecraft:spruce_stairs[facing=west]
fill 56 64 -33 68 70 -29 minecraft:air replace #minecraft:replaceable
fill 57 64 -31 57 69 -31 minecraft:spruce_log
fill 67 64 -31 67 69 -31 minecraft:spruce_log
fill 58 65 -31 66 68 -31 minecraft:spruce_planks
fill 58 64 -31 66 64 -31 minecraft:spruce_trapdoor[facing=north,half=top,open=false]
fill 57 70 -31 67 70 -31 minecraft:spruce_slab[type=bottom]
fill 57 69 -32 67 69 -32 minecraft:spruce_slab[type=top]
fill 57 63 -32 67 63 -33 minecraft:dirt_path
setblock 57 70 -31 minecraft:lantern[hanging=false]
setblock 67 70 -31 minecraft:lantern[hanging=false]
execute positioned 56 63 -34 run kill @e[type=minecraft:text_display,tag=wf_board,dx=14,dy=10,dz=6]
summon minecraft:text_display 62.5 68.15 -31.03 {Tags:["funk_label","wf_board","wf_board_head"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "WILDS DISCOVERY BOARD\\n", "color": "#F3E5AB", "bold": true}, {"text": "the first to find each one is named here", "color": "#C8BC98", "italic": true}]',background:1711276032,line_width:300,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.75f,0.75f,0.75f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 66.25 67.05 -31.03 {Tags:["funk_label","wf_board","wf_board_quarry"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 64.75 67.05 -31.03 {Tags:["funk_label","wf_board","wf_board_summit"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 63.25 67.05 -31.03 {Tags:["funk_label","wf_board","wf_board_wreck"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 61.75 67.05 -31.03 {Tags:["funk_label","wf_board","wf_board_lighthouse"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 60.25 67.05 -31.03 {Tags:["funk_label","wf_board","wf_board_oak"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 58.75 67.05 -31.03 {Tags:["funk_label","wf_board","wf_board_relay"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 66.25 66.1 -31.03 {Tags:["funk_label","wf_board","wf_board_greenhouse"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 64.75 66.1 -31.03 {Tags:["funk_label","wf_board","wf_board_fairy"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 63.25 66.1 -31.03 {Tags:["funk_label","wf_board","wf_board_chapel"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 61.75 66.1 -31.03 {Tags:["funk_label","wf_board","wf_board_lantern"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 60.25 66.1 -31.03 {Tags:["funk_label","wf_board","wf_board_observatory"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 58.75 66.1 -31.03 {Tags:["funk_label","wf_board","wf_board_hermit"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 65.5 65.15 -31.03 {Tags:["funk_label","wf_board","wf_board_dragon"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 64 65.15 -31.03 {Tags:["funk_label","wf_board","wf_board_forge"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 62.5 65.15 -31.03 {Tags:["funk_label","wf_board","wf_board_oldroad"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 61 65.15 -31.03 {Tags:["funk_label","wf_board","wf_board_foundations"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 59.5 65.15 -31.03 {Tags:["funk_label","wf_board","wf_board_ninth"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
data modify storage funkcity:state wayfarerPlaza2 set value 1
