# The Drowned Chapel - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=38,y=-64,z=1033,dx=21,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=38,y=-64,z=1033,dx=21,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=38,y=-64,z=1033,dx=21,dy=384,dz=14]
kill @e[type=minecraft:minecart,tag=wf_prop,x=38,y=-64,z=1033,dx=21,dy=384,dz=14]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=38,y=-64,z=1033,dx=21,dy=384,dz=14]
fill 43 59 1043 43 60 1043 minecraft:mud_bricks
setblock 43 61 1043 minecraft:stone_bricks
setblock 43 62 1043 minecraft:mossy_stone_bricks
setblock 43 63 1043 minecraft:stone_bricks
setblock 43 64 1043 minecraft:stone_bricks
setblock 43 65 1043 minecraft:mossy_stone_bricks
setblock 43 66 1043 minecraft:stone_bricks
setblock 43 67 1043 minecraft:cracked_stone_bricks
setblock 43 68 1043 minecraft:mossy_stone_bricks
fill 43 59 1042 43 60 1042 minecraft:mossy_stone_bricks
setblock 43 61 1042 minecraft:mossy_stone_bricks
setblock 43 62 1042 minecraft:cracked_stone_bricks
setblock 43 63 1042 minecraft:stone_bricks
setblock 43 64 1042 minecraft:mossy_stone_bricks
setblock 43 65 1042 minecraft:stone_bricks
setblock 43 66 1042 minecraft:stone_bricks
setblock 43 67 1042 minecraft:mossy_stone_bricks
setblock 43 68 1042 minecraft:stone_bricks
fill 43 59 1041 43 60 1041 minecraft:mud_bricks
setblock 43 61 1041 minecraft:stone_bricks
setblock 43 62 1041 minecraft:cracked_stone_bricks
setblock 43 63 1041 minecraft:mossy_stone_bricks
setblock 43 64 1041 minecraft:stone_bricks
setblock 43 65 1041 minecraft:stone_bricks
setblock 43 66 1041 minecraft:mossy_stone_bricks
setblock 43 67 1041 minecraft:air
setblock 43 68 1041 minecraft:air
fill 43 59 1040 43 60 1040 minecraft:mud_bricks
setblock 43 61 1040 minecraft:stone_bricks
setblock 43 62 1040 minecraft:mossy_stone_bricks
setblock 43 63 1040 minecraft:stone_bricks
setblock 43 64 1040 minecraft:stone_bricks
setblock 43 65 1040 minecraft:mossy_stone_bricks
setblock 43 66 1040 minecraft:stone_bricks
setblock 43 67 1040 minecraft:cracked_stone_bricks
setblock 43 68 1040 minecraft:mossy_stone_bricks
fill 43 59 1039 43 60 1039 minecraft:mossy_stone_bricks
setblock 43 61 1039 minecraft:mossy_stone_bricks
setblock 43 62 1039 minecraft:cracked_stone_bricks
setblock 43 63 1039 minecraft:stone_bricks
setblock 43 64 1039 minecraft:mossy_stone_bricks
setblock 43 65 1039 minecraft:stone_bricks
setblock 43 66 1039 minecraft:stone_bricks
setblock 43 67 1039 minecraft:mossy_stone_bricks
setblock 43 68 1039 minecraft:stone_bricks
fill 43 59 1038 43 60 1038 minecraft:mud_bricks
setblock 43 61 1038 minecraft:stone_bricks
setblock 43 62 1038 minecraft:cracked_stone_bricks
setblock 43 63 1038 minecraft:mossy_stone_bricks
setblock 43 64 1038 minecraft:stone_bricks
setblock 43 65 1038 minecraft:stone_bricks
setblock 43 66 1038 minecraft:mossy_stone_bricks
setblock 43 67 1038 minecraft:cracked_stone_bricks
setblock 43 68 1038 minecraft:stone_bricks
fill 43 59 1037 43 60 1037 minecraft:mud_bricks
setblock 43 61 1037 minecraft:stone_bricks
setblock 43 62 1037 minecraft:mossy_stone_bricks
setblock 43 63 1037 minecraft:stone_bricks
setblock 43 64 1037 minecraft:stone_bricks
setblock 43 65 1037 minecraft:mossy_stone_bricks
setblock 43 66 1037 minecraft:stone_bricks
setblock 43 67 1037 minecraft:air
setblock 43 68 1037 minecraft:air
fill 44 59 1043 44 60 1043 minecraft:mossy_stone_bricks
setblock 44 61 1043 minecraft:mossy_stone_bricks
setblock 44 62 1043 minecraft:stone_bricks
setblock 44 63 1043 minecraft:stone_bricks
setblock 44 64 1043 minecraft:mossy_stone_bricks
setblock 44 65 1043 minecraft:stone_bricks
setblock 44 66 1043 minecraft:cracked_stone_bricks
setblock 44 67 1043 minecraft:mossy_stone_bricks
setblock 44 68 1043 minecraft:stone_bricks
fill 44 59 1042 44 60 1042 minecraft:mud_bricks
setblock 44 61 1042 minecraft:water
setblock 44 62 1042 minecraft:water
setblock 44 63 1042 minecraft:air
setblock 44 64 1042 minecraft:air
setblock 44 65 1042 minecraft:air
setblock 44 66 1042 minecraft:air
setblock 44 67 1042 minecraft:air
setblock 44 68 1042 minecraft:air
fill 44 59 1041 44 60 1041 minecraft:mud_bricks
setblock 44 61 1041 minecraft:water
setblock 44 62 1041 minecraft:water
setblock 44 63 1041 minecraft:air
setblock 44 64 1041 minecraft:air
setblock 44 65 1041 minecraft:air
setblock 44 66 1041 minecraft:air
setblock 44 67 1041 minecraft:air
setblock 44 68 1041 minecraft:air
fill 44 59 1040 44 60 1040 minecraft:mossy_stone_bricks
setblock 44 61 1040 minecraft:water
setblock 44 62 1040 minecraft:water
setblock 44 63 1040 minecraft:air
setblock 44 64 1040 minecraft:air
setblock 44 65 1040 minecraft:air
setblock 44 66 1040 minecraft:air
setblock 44 67 1040 minecraft:air
setblock 44 68 1040 minecraft:air
fill 44 59 1039 44 60 1039 minecraft:mud_bricks
setblock 44 61 1039 minecraft:water
setblock 44 62 1039 minecraft:water
setblock 44 63 1039 minecraft:air
setblock 44 64 1039 minecraft:air
setblock 44 65 1039 minecraft:air
setblock 44 66 1039 minecraft:air
setblock 44 67 1039 minecraft:air
setblock 44 68 1039 minecraft:air
fill 44 59 1038 44 60 1038 minecraft:mud_bricks
setblock 44 61 1038 minecraft:water
setblock 44 62 1038 minecraft:water
setblock 44 63 1038 minecraft:air
setblock 44 64 1038 minecraft:air
setblock 44 65 1038 minecraft:air
setblock 44 66 1038 minecraft:air
setblock 44 67 1038 minecraft:air
setblock 44 68 1038 minecraft:air
fill 44 59 1037 44 60 1037 minecraft:mossy_stone_bricks
setblock 44 61 1037 minecraft:mossy_stone_bricks
setblock 44 62 1037 minecraft:stone_bricks
setblock 44 63 1037 minecraft:stone_bricks
setblock 44 64 1037 minecraft:mossy_stone_bricks
setblock 44 65 1037 minecraft:stone_bricks
setblock 44 66 1037 minecraft:cracked_stone_bricks
setblock 44 67 1037 minecraft:mossy_stone_bricks
setblock 44 68 1037 minecraft:stone_bricks
fill 45 59 1043 45 60 1043 minecraft:mud_bricks
setblock 45 61 1043 minecraft:stone_bricks
setblock 45 62 1043 minecraft:stone_bricks
setblock 45 63 1043 minecraft:mossy_stone_bricks
setblock 45 64 1043 minecraft:stone_bricks
setblock 45 65 1043 minecraft:cracked_stone_bricks
setblock 45 66 1043 minecraft:mossy_stone_bricks
setblock 45 67 1043 minecraft:air
setblock 45 68 1043 minecraft:air
fill 45 59 1042 45 60 1042 minecraft:mud_bricks
setblock 45 61 1042 minecraft:water
setblock 45 62 1042 minecraft:water
setblock 45 63 1042 minecraft:air
setblock 45 64 1042 minecraft:air
setblock 45 65 1042 minecraft:air
setblock 45 66 1042 minecraft:air
setblock 45 67 1042 minecraft:air
setblock 45 68 1042 minecraft:air
fill 45 59 1041 45 60 1041 minecraft:mossy_stone_bricks
setblock 45 61 1041 minecraft:water
setblock 45 62 1041 minecraft:water
setblock 45 63 1041 minecraft:air
setblock 45 64 1041 minecraft:air
setblock 45 65 1041 minecraft:air
setblock 45 66 1041 minecraft:air
setblock 45 67 1041 minecraft:air
setblock 45 68 1041 minecraft:air
fill 45 59 1040 45 60 1040 minecraft:mud_bricks
setblock 45 61 1040 minecraft:water
setblock 45 62 1040 minecraft:water
setblock 45 63 1040 minecraft:air
setblock 45 64 1040 minecraft:air
setblock 45 65 1040 minecraft:air
setblock 45 66 1040 minecraft:air
setblock 45 67 1040 minecraft:air
setblock 45 68 1040 minecraft:air
fill 45 59 1039 45 60 1039 minecraft:mud_bricks
setblock 45 61 1039 minecraft:water
setblock 45 62 1039 minecraft:water
setblock 45 63 1039 minecraft:air
setblock 45 64 1039 minecraft:air
setblock 45 65 1039 minecraft:air
setblock 45 66 1039 minecraft:air
setblock 45 67 1039 minecraft:air
setblock 45 68 1039 minecraft:air
fill 45 59 1038 45 60 1038 minecraft:mossy_stone_bricks
setblock 45 61 1038 minecraft:water
setblock 45 62 1038 minecraft:water
setblock 45 63 1038 minecraft:air
setblock 45 64 1038 minecraft:air
setblock 45 65 1038 minecraft:air
setblock 45 66 1038 minecraft:air
setblock 45 67 1038 minecraft:air
setblock 45 68 1038 minecraft:air
fill 45 59 1037 45 60 1037 minecraft:mud_bricks
setblock 45 61 1037 minecraft:stone_bricks
setblock 45 62 1037 minecraft:stone_bricks
setblock 45 63 1037 minecraft:mossy_stone_bricks
setblock 45 64 1037 minecraft:stone_bricks
setblock 45 65 1037 minecraft:cracked_stone_bricks
setblock 45 66 1037 minecraft:mossy_stone_bricks
setblock 45 67 1037 minecraft:stone_bricks
setblock 45 68 1037 minecraft:stone_bricks
fill 46 59 1043 46 60 1043 minecraft:mud_bricks
setblock 46 61 1043 minecraft:stone_bricks
setblock 46 62 1043 minecraft:mossy_stone_bricks
setblock 46 63 1043 minecraft:stone_bricks
setblock 46 64 1043 minecraft:cracked_stone_bricks
setblock 46 65 1043 minecraft:mossy_stone_bricks
setblock 46 66 1043 minecraft:stone_bricks
setblock 46 67 1043 minecraft:stone_bricks
setblock 46 68 1043 minecraft:mossy_stone_bricks
fill 46 59 1042 46 60 1042 minecraft:mossy_stone_bricks
setblock 46 61 1042 minecraft:water
setblock 46 62 1042 minecraft:water
setblock 46 63 1042 minecraft:air
setblock 46 64 1042 minecraft:air
setblock 46 65 1042 minecraft:air
setblock 46 66 1042 minecraft:air
setblock 46 67 1042 minecraft:air
setblock 46 68 1042 minecraft:air
fill 46 59 1041 46 60 1041 minecraft:mud_bricks
setblock 46 61 1041 minecraft:water
setblock 46 62 1041 minecraft:water
setblock 46 63 1041 minecraft:air
setblock 46 64 1041 minecraft:air
setblock 46 65 1041 minecraft:air
setblock 46 66 1041 minecraft:air
setblock 46 67 1041 minecraft:air
setblock 46 68 1041 minecraft:air
fill 46 59 1040 46 60 1040 minecraft:mud_bricks
setblock 46 61 1040 minecraft:water
setblock 46 62 1040 minecraft:water
setblock 46 63 1040 minecraft:air
setblock 46 64 1040 minecraft:air
setblock 46 65 1040 minecraft:air
setblock 46 66 1040 minecraft:air
setblock 46 67 1040 minecraft:air
setblock 46 68 1040 minecraft:air
fill 46 59 1039 46 60 1039 minecraft:mossy_stone_bricks
setblock 46 61 1039 minecraft:water
setblock 46 62 1039 minecraft:water
setblock 46 63 1039 minecraft:air
setblock 46 64 1039 minecraft:air
setblock 46 65 1039 minecraft:air
setblock 46 66 1039 minecraft:air
setblock 46 67 1039 minecraft:air
setblock 46 68 1039 minecraft:air
fill 46 59 1038 46 60 1038 minecraft:mud_bricks
setblock 46 61 1038 minecraft:water
setblock 46 62 1038 minecraft:water
setblock 46 63 1038 minecraft:air
setblock 46 64 1038 minecraft:air
setblock 46 65 1038 minecraft:air
setblock 46 66 1038 minecraft:air
setblock 46 67 1038 minecraft:air
setblock 46 68 1038 minecraft:air
fill 46 59 1037 46 60 1037 minecraft:mud_bricks
setblock 46 61 1037 minecraft:stone_bricks
setblock 46 62 1037 minecraft:mossy_stone_bricks
setblock 46 63 1037 minecraft:stone_bricks
setblock 46 64 1037 minecraft:cracked_stone_bricks
setblock 46 65 1037 minecraft:mossy_stone_bricks
setblock 46 66 1037 minecraft:stone_bricks
setblock 46 67 1037 minecraft:stone_bricks
setblock 46 68 1037 minecraft:mossy_stone_bricks
fill 47 59 1043 47 60 1043 minecraft:mossy_stone_bricks
setblock 47 61 1043 minecraft:mossy_stone_bricks
setblock 47 62 1043 minecraft:stone_bricks
setblock 47 63 1043 minecraft:cracked_stone_bricks
setblock 47 64 1043 minecraft:mossy_stone_bricks
setblock 47 65 1043 minecraft:stone_bricks
setblock 47 66 1043 minecraft:stone_bricks
setblock 47 67 1043 minecraft:mossy_stone_bricks
setblock 47 68 1043 minecraft:cracked_stone_bricks
fill 47 59 1042 47 60 1042 minecraft:mud_bricks
setblock 47 61 1042 minecraft:water
setblock 47 62 1042 minecraft:water
setblock 47 63 1042 minecraft:air
setblock 47 64 1042 minecraft:air
setblock 47 65 1042 minecraft:air
setblock 47 66 1042 minecraft:air
setblock 47 67 1042 minecraft:air
setblock 47 68 1042 minecraft:air
fill 47 59 1041 47 60 1041 minecraft:mud_bricks
setblock 47 61 1041 minecraft:water
setblock 47 62 1041 minecraft:water
setblock 47 63 1041 minecraft:air
setblock 47 64 1041 minecraft:air
setblock 47 65 1041 minecraft:air
setblock 47 66 1041 minecraft:air
setblock 47 67 1041 minecraft:air
setblock 47 68 1041 minecraft:air
fill 47 59 1040 47 60 1040 minecraft:mossy_stone_bricks
setblock 47 61 1040 minecraft:water
setblock 47 62 1040 minecraft:water
setblock 47 63 1040 minecraft:air
setblock 47 64 1040 minecraft:air
setblock 47 65 1040 minecraft:air
setblock 47 66 1040 minecraft:air
setblock 47 67 1040 minecraft:air
setblock 47 68 1040 minecraft:air
fill 47 59 1039 47 60 1039 minecraft:mud_bricks
setblock 47 61 1039 minecraft:water
setblock 47 62 1039 minecraft:water
setblock 47 63 1039 minecraft:air
setblock 47 64 1039 minecraft:air
setblock 47 65 1039 minecraft:air
setblock 47 66 1039 minecraft:air
setblock 47 67 1039 minecraft:air
setblock 47 68 1039 minecraft:air
fill 47 59 1038 47 60 1038 minecraft:mud_bricks
setblock 47 61 1038 minecraft:water
setblock 47 62 1038 minecraft:water
setblock 47 63 1038 minecraft:air
setblock 47 64 1038 minecraft:air
setblock 47 65 1038 minecraft:air
setblock 47 66 1038 minecraft:air
setblock 47 67 1038 minecraft:air
setblock 47 68 1038 minecraft:air
fill 47 59 1037 47 60 1037 minecraft:mossy_stone_bricks
setblock 47 61 1037 minecraft:mossy_stone_bricks
setblock 47 62 1037 minecraft:stone_bricks
setblock 47 63 1037 minecraft:cracked_stone_bricks
setblock 47 64 1037 minecraft:mossy_stone_bricks
setblock 47 65 1037 minecraft:stone_bricks
setblock 47 66 1037 minecraft:stone_bricks
setblock 47 67 1037 minecraft:air
setblock 47 68 1037 minecraft:air
fill 48 59 1043 48 60 1043 minecraft:mud_bricks
setblock 48 61 1043 minecraft:stone_bricks
setblock 48 62 1043 minecraft:cracked_stone_bricks
setblock 48 63 1043 minecraft:mossy_stone_bricks
setblock 48 64 1043 minecraft:stone_bricks
setblock 48 65 1043 minecraft:stone_bricks
setblock 48 66 1043 minecraft:mossy_stone_bricks
setblock 48 67 1043 minecraft:cracked_stone_bricks
setblock 48 68 1043 minecraft:stone_bricks
fill 48 59 1042 48 60 1042 minecraft:mud_bricks
setblock 48 61 1042 minecraft:water
setblock 48 62 1042 minecraft:water
setblock 48 63 1042 minecraft:air
setblock 48 64 1042 minecraft:air
setblock 48 65 1042 minecraft:air
setblock 48 66 1042 minecraft:air
setblock 48 67 1042 minecraft:air
setblock 48 68 1042 minecraft:air
fill 48 59 1041 48 60 1041 minecraft:mossy_stone_bricks
setblock 48 61 1041 minecraft:water
setblock 48 62 1041 minecraft:water
setblock 48 63 1041 minecraft:air
setblock 48 64 1041 minecraft:air
setblock 48 65 1041 minecraft:air
setblock 48 66 1041 minecraft:air
setblock 48 67 1041 minecraft:air
setblock 48 68 1041 minecraft:air
fill 48 59 1040 48 60 1040 minecraft:mud_bricks
setblock 48 61 1040 minecraft:water
setblock 48 62 1040 minecraft:water
setblock 48 63 1040 minecraft:air
setblock 48 64 1040 minecraft:air
setblock 48 65 1040 minecraft:air
setblock 48 66 1040 minecraft:air
setblock 48 67 1040 minecraft:air
setblock 48 68 1040 minecraft:air
fill 48 59 1039 48 60 1039 minecraft:mud_bricks
setblock 48 61 1039 minecraft:water
setblock 48 62 1039 minecraft:water
setblock 48 63 1039 minecraft:air
setblock 48 64 1039 minecraft:air
setblock 48 65 1039 minecraft:air
setblock 48 66 1039 minecraft:air
setblock 48 67 1039 minecraft:air
setblock 48 68 1039 minecraft:air
fill 48 59 1038 48 60 1038 minecraft:mossy_stone_bricks
setblock 48 61 1038 minecraft:water
setblock 48 62 1038 minecraft:water
setblock 48 63 1038 minecraft:air
setblock 48 64 1038 minecraft:air
setblock 48 65 1038 minecraft:air
setblock 48 66 1038 minecraft:air
setblock 48 67 1038 minecraft:air
setblock 48 68 1038 minecraft:air
fill 48 59 1037 48 60 1037 minecraft:mud_bricks
setblock 48 61 1037 minecraft:stone_bricks
setblock 48 62 1037 minecraft:cracked_stone_bricks
setblock 48 63 1037 minecraft:mossy_stone_bricks
setblock 48 64 1037 minecraft:stone_bricks
setblock 48 65 1037 minecraft:stone_bricks
setblock 48 66 1037 minecraft:mossy_stone_bricks
setblock 48 67 1037 minecraft:cracked_stone_bricks
setblock 48 68 1037 minecraft:stone_bricks
fill 49 59 1043 49 60 1043 minecraft:mud_bricks
setblock 49 61 1043 minecraft:cracked_stone_bricks
setblock 49 62 1043 minecraft:mossy_stone_bricks
setblock 49 63 1043 minecraft:stone_bricks
setblock 49 64 1043 minecraft:stone_bricks
setblock 49 65 1043 minecraft:mossy_stone_bricks
setblock 49 66 1043 minecraft:cracked_stone_bricks
setblock 49 67 1043 minecraft:air
setblock 49 68 1043 minecraft:air
fill 49 59 1042 49 60 1042 minecraft:mossy_stone_bricks
setblock 49 61 1042 minecraft:water
setblock 49 62 1042 minecraft:water
setblock 49 63 1042 minecraft:air
setblock 49 64 1042 minecraft:air
setblock 49 65 1042 minecraft:air
setblock 49 66 1042 minecraft:air
setblock 49 67 1042 minecraft:air
setblock 49 68 1042 minecraft:air
fill 49 59 1041 49 60 1041 minecraft:mud_bricks
setblock 49 61 1041 minecraft:water
setblock 49 62 1041 minecraft:water
setblock 49 63 1041 minecraft:air
setblock 49 64 1041 minecraft:air
setblock 49 65 1041 minecraft:air
setblock 49 66 1041 minecraft:air
setblock 49 67 1041 minecraft:air
setblock 49 68 1041 minecraft:air
fill 49 59 1040 49 60 1040 minecraft:mud_bricks
setblock 49 61 1040 minecraft:water
setblock 49 62 1040 minecraft:water
setblock 49 63 1040 minecraft:air
setblock 49 64 1040 minecraft:air
setblock 49 65 1040 minecraft:air
setblock 49 66 1040 minecraft:air
setblock 49 67 1040 minecraft:air
setblock 49 68 1040 minecraft:air
fill 49 59 1039 49 60 1039 minecraft:mossy_stone_bricks
setblock 49 61 1039 minecraft:water
setblock 49 62 1039 minecraft:water
setblock 49 63 1039 minecraft:air
setblock 49 64 1039 minecraft:air
setblock 49 65 1039 minecraft:air
setblock 49 66 1039 minecraft:air
setblock 49 67 1039 minecraft:air
setblock 49 68 1039 minecraft:air
fill 49 59 1038 49 60 1038 minecraft:mud_bricks
setblock 49 61 1038 minecraft:water
setblock 49 62 1038 minecraft:water
setblock 49 63 1038 minecraft:air
setblock 49 64 1038 minecraft:air
setblock 49 65 1038 minecraft:air
setblock 49 66 1038 minecraft:air
setblock 49 67 1038 minecraft:air
setblock 49 68 1038 minecraft:air
fill 49 59 1037 49 60 1037 minecraft:mud_bricks
setblock 49 61 1037 minecraft:cracked_stone_bricks
setblock 49 62 1037 minecraft:mossy_stone_bricks
setblock 49 63 1037 minecraft:stone_bricks
setblock 49 64 1037 minecraft:stone_bricks
setblock 49 65 1037 minecraft:mossy_stone_bricks
setblock 49 66 1037 minecraft:cracked_stone_bricks
setblock 49 67 1037 minecraft:stone_bricks
setblock 49 68 1037 minecraft:mossy_stone_bricks
fill 50 59 1043 50 60 1043 minecraft:mossy_stone_bricks
setblock 50 61 1043 minecraft:mossy_stone_bricks
setblock 50 62 1043 minecraft:stone_bricks
setblock 50 63 1043 minecraft:stone_bricks
setblock 50 64 1043 minecraft:mossy_stone_bricks
setblock 50 65 1043 minecraft:cracked_stone_bricks
setblock 50 66 1043 minecraft:stone_bricks
setblock 50 67 1043 minecraft:mossy_stone_bricks
setblock 50 68 1043 minecraft:stone_bricks
fill 50 59 1042 50 60 1042 minecraft:mud_bricks
setblock 50 61 1042 minecraft:water
setblock 50 62 1042 minecraft:water
setblock 50 63 1042 minecraft:air
setblock 50 64 1042 minecraft:air
setblock 50 65 1042 minecraft:air
setblock 50 66 1042 minecraft:air
setblock 50 67 1042 minecraft:air
setblock 50 68 1042 minecraft:air
fill 50 59 1041 50 60 1041 minecraft:mud_bricks
setblock 50 61 1041 minecraft:water
setblock 50 62 1041 minecraft:water
setblock 50 63 1041 minecraft:air
setblock 50 64 1041 minecraft:air
setblock 50 65 1041 minecraft:air
setblock 50 66 1041 minecraft:air
setblock 50 67 1041 minecraft:air
setblock 50 68 1041 minecraft:air
fill 50 59 1040 50 60 1040 minecraft:mossy_stone_bricks
setblock 50 61 1040 minecraft:water
setblock 50 62 1040 minecraft:water
setblock 50 63 1040 minecraft:air
setblock 50 64 1040 minecraft:air
setblock 50 65 1040 minecraft:air
setblock 50 66 1040 minecraft:air
setblock 50 67 1040 minecraft:air
setblock 50 68 1040 minecraft:air
fill 50 59 1039 50 60 1039 minecraft:mud_bricks
setblock 50 61 1039 minecraft:water
setblock 50 62 1039 minecraft:water
setblock 50 63 1039 minecraft:air
setblock 50 64 1039 minecraft:air
setblock 50 65 1039 minecraft:air
setblock 50 66 1039 minecraft:air
setblock 50 67 1039 minecraft:air
setblock 50 68 1039 minecraft:air
fill 50 59 1038 50 60 1038 minecraft:mud_bricks
setblock 50 61 1038 minecraft:water
setblock 50 62 1038 minecraft:water
setblock 50 63 1038 minecraft:air
setblock 50 64 1038 minecraft:air
setblock 50 65 1038 minecraft:air
setblock 50 66 1038 minecraft:air
setblock 50 67 1038 minecraft:air
setblock 50 68 1038 minecraft:air
fill 50 59 1037 50 60 1037 minecraft:mossy_stone_bricks
setblock 50 61 1037 minecraft:mossy_stone_bricks
setblock 50 62 1037 minecraft:stone_bricks
setblock 50 63 1037 minecraft:stone_bricks
setblock 50 64 1037 minecraft:air
setblock 50 65 1037 minecraft:air
setblock 50 66 1037 minecraft:air
setblock 50 67 1037 minecraft:air
setblock 50 68 1037 minecraft:air
fill 51 59 1043 51 60 1043 minecraft:mud_bricks
setblock 51 61 1043 minecraft:stone_bricks
setblock 51 62 1043 minecraft:stone_bricks
setblock 51 63 1043 minecraft:mossy_stone_bricks
setblock 51 64 1043 minecraft:cracked_stone_bricks
setblock 51 65 1043 minecraft:stone_bricks
setblock 51 66 1043 minecraft:mossy_stone_bricks
setblock 51 67 1043 minecraft:stone_bricks
setblock 51 68 1043 minecraft:stone_bricks
fill 51 59 1042 51 60 1042 minecraft:mud_bricks
setblock 51 61 1042 minecraft:water
setblock 51 62 1042 minecraft:water
setblock 51 63 1042 minecraft:air
setblock 51 64 1042 minecraft:air
setblock 51 65 1042 minecraft:air
setblock 51 66 1042 minecraft:air
setblock 51 67 1042 minecraft:air
setblock 51 68 1042 minecraft:air
fill 51 59 1041 51 60 1041 minecraft:mossy_stone_bricks
setblock 51 61 1041 minecraft:water
setblock 51 62 1041 minecraft:water
setblock 51 63 1041 minecraft:air
setblock 51 64 1041 minecraft:air
setblock 51 65 1041 minecraft:air
setblock 51 66 1041 minecraft:air
setblock 51 67 1041 minecraft:air
setblock 51 68 1041 minecraft:air
fill 51 59 1040 51 60 1040 minecraft:mud_bricks
setblock 51 61 1040 minecraft:water
setblock 51 62 1040 minecraft:water
setblock 51 63 1040 minecraft:air
setblock 51 64 1040 minecraft:air
setblock 51 65 1040 minecraft:air
setblock 51 66 1040 minecraft:air
setblock 51 67 1040 minecraft:air
setblock 51 68 1040 minecraft:air
fill 51 59 1039 51 60 1039 minecraft:mud_bricks
setblock 51 61 1039 minecraft:water
setblock 51 62 1039 minecraft:water
setblock 51 63 1039 minecraft:air
setblock 51 64 1039 minecraft:air
setblock 51 65 1039 minecraft:air
setblock 51 66 1039 minecraft:air
setblock 51 67 1039 minecraft:air
setblock 51 68 1039 minecraft:air
fill 51 59 1038 51 60 1038 minecraft:mossy_stone_bricks
setblock 51 61 1038 minecraft:water
setblock 51 62 1038 minecraft:water
setblock 51 63 1038 minecraft:air
setblock 51 64 1038 minecraft:air
setblock 51 65 1038 minecraft:air
setblock 51 66 1038 minecraft:air
setblock 51 67 1038 minecraft:air
setblock 51 68 1038 minecraft:air
fill 51 59 1037 51 60 1037 minecraft:mud_bricks
setblock 51 61 1037 minecraft:stone_bricks
setblock 51 62 1037 minecraft:stone_bricks
setblock 51 63 1037 minecraft:mossy_stone_bricks
setblock 51 64 1037 minecraft:air
setblock 51 65 1037 minecraft:air
setblock 51 66 1037 minecraft:air
setblock 51 67 1037 minecraft:air
setblock 51 68 1037 minecraft:air
fill 52 59 1043 52 60 1043 minecraft:mud_bricks
setblock 52 61 1043 minecraft:stone_bricks
setblock 52 62 1043 minecraft:mossy_stone_bricks
setblock 52 63 1043 minecraft:cracked_stone_bricks
setblock 52 64 1043 minecraft:stone_bricks
setblock 52 65 1043 minecraft:mossy_stone_bricks
setblock 52 66 1043 minecraft:stone_bricks
setblock 52 67 1043 minecraft:stone_bricks
setblock 52 68 1043 minecraft:mossy_stone_bricks
fill 52 59 1042 52 60 1042 minecraft:mossy_stone_bricks
setblock 52 61 1042 minecraft:water
setblock 52 62 1042 minecraft:water
setblock 52 63 1042 minecraft:air
setblock 52 64 1042 minecraft:air
setblock 52 65 1042 minecraft:air
setblock 52 66 1042 minecraft:air
setblock 52 67 1042 minecraft:air
setblock 52 68 1042 minecraft:air
fill 52 59 1041 52 60 1041 minecraft:mud_bricks
setblock 52 61 1041 minecraft:water
setblock 52 62 1041 minecraft:water
setblock 52 63 1041 minecraft:air
setblock 52 64 1041 minecraft:air
setblock 52 65 1041 minecraft:air
setblock 52 66 1041 minecraft:air
setblock 52 67 1041 minecraft:air
setblock 52 68 1041 minecraft:air
fill 52 59 1040 52 60 1040 minecraft:mud_bricks
setblock 52 61 1040 minecraft:water
setblock 52 62 1040 minecraft:water
setblock 52 63 1040 minecraft:air
setblock 52 64 1040 minecraft:air
setblock 52 65 1040 minecraft:air
setblock 52 66 1040 minecraft:air
setblock 52 67 1040 minecraft:air
setblock 52 68 1040 minecraft:air
fill 52 59 1039 52 60 1039 minecraft:mossy_stone_bricks
setblock 52 61 1039 minecraft:water
setblock 52 62 1039 minecraft:water
setblock 52 63 1039 minecraft:air
setblock 52 64 1039 minecraft:air
setblock 52 65 1039 minecraft:air
setblock 52 66 1039 minecraft:air
setblock 52 67 1039 minecraft:air
setblock 52 68 1039 minecraft:air
fill 52 59 1038 52 60 1038 minecraft:mud_bricks
setblock 52 61 1038 minecraft:water
setblock 52 62 1038 minecraft:water
setblock 52 63 1038 minecraft:air
setblock 52 64 1038 minecraft:air
setblock 52 65 1038 minecraft:air
setblock 52 66 1038 minecraft:air
setblock 52 67 1038 minecraft:air
setblock 52 68 1038 minecraft:air
fill 52 59 1037 52 60 1037 minecraft:mud_bricks
setblock 52 61 1037 minecraft:stone_bricks
setblock 52 62 1037 minecraft:mossy_stone_bricks
setblock 52 63 1037 minecraft:cracked_stone_bricks
setblock 52 64 1037 minecraft:air
setblock 52 65 1037 minecraft:air
setblock 52 66 1037 minecraft:air
setblock 52 67 1037 minecraft:air
setblock 52 68 1037 minecraft:air
fill 53 59 1043 53 60 1043 minecraft:mossy_stone_bricks
setblock 53 61 1043 minecraft:mossy_stone_bricks
setblock 53 62 1043 minecraft:cracked_stone_bricks
setblock 53 63 1043 minecraft:stone_bricks
setblock 53 64 1043 minecraft:mossy_stone_bricks
setblock 53 65 1043 minecraft:stone_bricks
setblock 53 66 1043 minecraft:stone_bricks
setblock 53 67 1043 minecraft:air
setblock 53 68 1043 minecraft:air
fill 53 59 1042 53 60 1042 minecraft:mud_bricks
setblock 53 61 1042 minecraft:water
setblock 53 62 1042 minecraft:water
setblock 53 63 1042 minecraft:air
setblock 53 64 1042 minecraft:air
setblock 53 65 1042 minecraft:air
setblock 53 66 1042 minecraft:air
setblock 53 67 1042 minecraft:air
setblock 53 68 1042 minecraft:air
fill 53 59 1041 53 60 1041 minecraft:mud_bricks
setblock 53 61 1041 minecraft:water
setblock 53 62 1041 minecraft:water
setblock 53 63 1041 minecraft:air
setblock 53 64 1041 minecraft:air
setblock 53 65 1041 minecraft:air
setblock 53 66 1041 minecraft:air
setblock 53 67 1041 minecraft:air
setblock 53 68 1041 minecraft:air
fill 53 59 1040 53 60 1040 minecraft:mossy_stone_bricks
setblock 53 61 1040 minecraft:water
setblock 53 62 1040 minecraft:water
setblock 53 63 1040 minecraft:air
setblock 53 64 1040 minecraft:air
setblock 53 65 1040 minecraft:air
setblock 53 66 1040 minecraft:air
setblock 53 67 1040 minecraft:air
setblock 53 68 1040 minecraft:air
fill 53 59 1039 53 60 1039 minecraft:mud_bricks
setblock 53 61 1039 minecraft:water
setblock 53 62 1039 minecraft:water
setblock 53 63 1039 minecraft:air
setblock 53 64 1039 minecraft:air
setblock 53 65 1039 minecraft:air
setblock 53 66 1039 minecraft:air
setblock 53 67 1039 minecraft:air
setblock 53 68 1039 minecraft:air
fill 53 59 1038 53 60 1038 minecraft:mud_bricks
setblock 53 61 1038 minecraft:water
setblock 53 62 1038 minecraft:water
setblock 53 63 1038 minecraft:air
setblock 53 64 1038 minecraft:air
setblock 53 65 1038 minecraft:air
setblock 53 66 1038 minecraft:air
setblock 53 67 1038 minecraft:air
setblock 53 68 1038 minecraft:air
fill 53 59 1037 53 60 1037 minecraft:mossy_stone_bricks
setblock 53 61 1037 minecraft:mossy_stone_bricks
setblock 53 62 1037 minecraft:cracked_stone_bricks
setblock 53 63 1037 minecraft:stone_bricks
setblock 53 64 1037 minecraft:mossy_stone_bricks
setblock 53 65 1037 minecraft:stone_bricks
setblock 53 66 1037 minecraft:stone_bricks
setblock 53 67 1037 minecraft:mossy_stone_bricks
setblock 53 68 1037 minecraft:stone_bricks
fill 54 59 1043 54 60 1043 minecraft:mud_bricks
setblock 54 61 1043 minecraft:cracked_stone_bricks
setblock 54 62 1043 minecraft:stone_bricks
setblock 54 63 1043 minecraft:mossy_stone_bricks
setblock 54 64 1043 minecraft:stone_bricks
setblock 54 65 1043 minecraft:stone_bricks
setblock 54 66 1043 minecraft:mossy_stone_bricks
setblock 54 67 1043 minecraft:stone_bricks
setblock 54 68 1043 minecraft:stone_bricks
fill 54 59 1042 54 60 1042 minecraft:mud_bricks
setblock 54 61 1042 minecraft:water
setblock 54 62 1042 minecraft:water
setblock 54 63 1042 minecraft:air
setblock 54 64 1042 minecraft:air
setblock 54 65 1042 minecraft:air
setblock 54 66 1042 minecraft:air
setblock 54 67 1042 minecraft:air
setblock 54 68 1042 minecraft:air
fill 54 59 1041 54 60 1041 minecraft:mossy_stone_bricks
setblock 54 61 1041 minecraft:water
setblock 54 62 1041 minecraft:water
setblock 54 63 1041 minecraft:air
setblock 54 64 1041 minecraft:air
setblock 54 65 1041 minecraft:air
setblock 54 66 1041 minecraft:air
setblock 54 67 1041 minecraft:air
setblock 54 68 1041 minecraft:air
fill 54 59 1040 54 60 1040 minecraft:mud_bricks
setblock 54 61 1040 minecraft:water
setblock 54 62 1040 minecraft:water
setblock 54 63 1040 minecraft:air
setblock 54 64 1040 minecraft:air
setblock 54 65 1040 minecraft:air
setblock 54 66 1040 minecraft:air
setblock 54 67 1040 minecraft:air
setblock 54 68 1040 minecraft:air
fill 54 59 1039 54 60 1039 minecraft:mud_bricks
setblock 54 61 1039 minecraft:water
setblock 54 62 1039 minecraft:water
setblock 54 63 1039 minecraft:air
setblock 54 64 1039 minecraft:air
setblock 54 65 1039 minecraft:air
setblock 54 66 1039 minecraft:air
setblock 54 67 1039 minecraft:air
setblock 54 68 1039 minecraft:air
fill 54 59 1038 54 60 1038 minecraft:mossy_stone_bricks
setblock 54 61 1038 minecraft:water
setblock 54 62 1038 minecraft:water
setblock 54 63 1038 minecraft:air
setblock 54 64 1038 minecraft:air
setblock 54 65 1038 minecraft:air
setblock 54 66 1038 minecraft:air
setblock 54 67 1038 minecraft:air
setblock 54 68 1038 minecraft:air
fill 54 59 1037 54 60 1037 minecraft:mud_bricks
setblock 54 61 1037 minecraft:cracked_stone_bricks
setblock 54 62 1037 minecraft:stone_bricks
setblock 54 63 1037 minecraft:mossy_stone_bricks
setblock 54 64 1037 minecraft:stone_bricks
setblock 54 65 1037 minecraft:stone_bricks
setblock 54 66 1037 minecraft:mossy_stone_bricks
setblock 54 67 1037 minecraft:stone_bricks
setblock 54 68 1037 minecraft:stone_bricks
fill 55 59 1043 55 60 1043 minecraft:mud_bricks
setblock 55 61 1043 minecraft:stone_bricks
setblock 55 62 1043 minecraft:mossy_stone_bricks
setblock 55 63 1043 minecraft:stone_bricks
setblock 55 64 1043 minecraft:stone_bricks
setblock 55 65 1043 minecraft:mossy_stone_bricks
setblock 55 66 1043 minecraft:stone_bricks
setblock 55 67 1043 minecraft:stone_bricks
setblock 55 68 1043 minecraft:mossy_stone_bricks
fill 55 59 1042 55 60 1042 minecraft:mossy_stone_bricks
setblock 55 61 1042 minecraft:mossy_stone_bricks
setblock 55 62 1042 minecraft:stone_bricks
setblock 55 63 1042 minecraft:stone_bricks
setblock 55 64 1042 minecraft:mossy_stone_bricks
setblock 55 65 1042 minecraft:cracked_stone_bricks
setblock 55 66 1042 minecraft:stone_bricks
setblock 55 67 1042 minecraft:mossy_stone_bricks
setblock 55 68 1042 minecraft:stone_bricks
fill 55 59 1041 55 60 1041 minecraft:mud_bricks
setblock 55 61 1041 minecraft:stone_bricks
setblock 55 62 1041 minecraft:stone_bricks
setblock 55 63 1041 minecraft:mossy_stone_bricks
setblock 55 64 1041 minecraft:stone_bricks
setblock 55 65 1041 minecraft:cracked_stone_bricks
setblock 55 66 1041 minecraft:mossy_stone_bricks
setblock 55 67 1041 minecraft:air
setblock 55 68 1041 minecraft:air
fill 55 59 1040 55 60 1040 minecraft:mud_bricks
setblock 55 61 1040 minecraft:stone_bricks
setblock 55 62 1040 minecraft:mossy_stone_bricks
setblock 55 63 1040 minecraft:stone_bricks
setblock 55 64 1040 minecraft:stone_bricks
setblock 55 65 1040 minecraft:mossy_stone_bricks
setblock 55 66 1040 minecraft:stone_bricks
setblock 55 67 1040 minecraft:stone_bricks
setblock 55 68 1040 minecraft:mossy_stone_bricks
fill 55 59 1039 55 60 1039 minecraft:mossy_stone_bricks
setblock 55 61 1039 minecraft:mossy_stone_bricks
setblock 55 62 1039 minecraft:stone_bricks
setblock 55 63 1039 minecraft:stone_bricks
setblock 55 64 1039 minecraft:mossy_stone_bricks
setblock 55 65 1039 minecraft:cracked_stone_bricks
setblock 55 66 1039 minecraft:stone_bricks
setblock 55 67 1039 minecraft:mossy_stone_bricks
setblock 55 68 1039 minecraft:stone_bricks
fill 55 59 1038 55 60 1038 minecraft:mud_bricks
setblock 55 61 1038 minecraft:stone_bricks
setblock 55 62 1038 minecraft:stone_bricks
setblock 55 63 1038 minecraft:mossy_stone_bricks
setblock 55 64 1038 minecraft:stone_bricks
setblock 55 65 1038 minecraft:cracked_stone_bricks
setblock 55 66 1038 minecraft:mossy_stone_bricks
setblock 55 67 1038 minecraft:stone_bricks
setblock 55 68 1038 minecraft:stone_bricks
fill 55 59 1037 55 60 1037 minecraft:mud_bricks
setblock 55 61 1037 minecraft:stone_bricks
setblock 55 62 1037 minecraft:mossy_stone_bricks
setblock 55 63 1037 minecraft:stone_bricks
setblock 55 64 1037 minecraft:stone_bricks
setblock 55 65 1037 minecraft:mossy_stone_bricks
setblock 55 66 1037 minecraft:stone_bricks
setblock 55 67 1037 minecraft:air
setblock 55 68 1037 minecraft:air
setblock 46 64 1043 minecraft:air
setblock 46 65 1043 minecraft:air
setblock 46 64 1037 minecraft:air
setblock 46 65 1037 minecraft:air
setblock 49 64 1043 minecraft:air
setblock 49 65 1043 minecraft:air
setblock 49 64 1037 minecraft:air
setblock 49 65 1037 minecraft:air
setblock 52 64 1043 minecraft:air
setblock 52 65 1043 minecraft:air
setblock 52 64 1037 minecraft:air
setblock 52 65 1037 minecraft:air
setblock 43 62 1040 minecraft:air
setblock 43 63 1040 minecraft:air
setblock 43 64 1040 minecraft:air
setblock 43 66 1043 minecraft:spruce_slab[type=bottom]
setblock 43 67 1042 minecraft:spruce_slab[type=bottom]
setblock 43 68 1041 minecraft:spruce_slab[type=bottom]
setblock 43 68 1039 minecraft:spruce_slab[type=bottom]
setblock 43 67 1038 minecraft:spruce_slab[type=bottom]
setblock 43 66 1037 minecraft:spruce_slab[type=bottom]
setblock 44 66 1043 minecraft:spruce_slab[type=bottom]
setblock 44 67 1042 minecraft:spruce_slab[type=bottom]
setblock 44 69 1040 minecraft:dark_oak_planks
setblock 44 68 1039 minecraft:spruce_slab[type=bottom]
setblock 44 67 1038 minecraft:spruce_slab[type=bottom]
setblock 45 66 1043 minecraft:spruce_slab[type=bottom]
setblock 45 68 1041 minecraft:spruce_slab[type=bottom]
setblock 45 69 1040 minecraft:dark_oak_planks
setblock 45 68 1039 minecraft:spruce_slab[type=bottom]
setblock 45 66 1037 minecraft:spruce_slab[type=bottom]
setblock 46 67 1042 minecraft:spruce_slab[type=bottom]
setblock 46 68 1041 minecraft:spruce_slab[type=bottom]
setblock 46 69 1040 minecraft:dark_oak_planks
setblock 46 67 1038 minecraft:spruce_slab[type=bottom]
setblock 46 66 1037 minecraft:spruce_slab[type=bottom]
setblock 47 66 1043 minecraft:spruce_slab[type=bottom]
setblock 47 67 1042 minecraft:spruce_slab[type=bottom]
setblock 47 68 1041 minecraft:spruce_slab[type=bottom]
setblock 47 68 1039 minecraft:spruce_slab[type=bottom]
setblock 47 67 1038 minecraft:spruce_slab[type=bottom]
setblock 47 66 1037 minecraft:spruce_slab[type=bottom]
setblock 48 66 1043 minecraft:spruce_slab[type=bottom]
setblock 48 67 1042 minecraft:spruce_slab[type=bottom]
setblock 48 69 1040 minecraft:dark_oak_planks
setblock 48 68 1039 minecraft:spruce_slab[type=bottom]
setblock 48 67 1038 minecraft:spruce_slab[type=bottom]
setblock 49 66 1043 minecraft:spruce_slab[type=bottom]
setblock 49 68 1041 minecraft:spruce_slab[type=bottom]
setblock 49 69 1040 minecraft:dark_oak_planks
setblock 49 68 1039 minecraft:spruce_slab[type=bottom]
setblock 49 66 1037 minecraft:spruce_slab[type=bottom]
fill 43 69 1039 43 72 1039 minecraft:stone_brick_wall
fill 45 69 1039 45 72 1039 minecraft:stone_brick_wall
fill 43 69 1041 43 72 1041 minecraft:stone_brick_wall
fill 45 69 1041 45 72 1041 minecraft:stone_brick_wall
fill 43 73 1039 45 73 1041 minecraft:deepslate_tile_slab[type=bottom]
fill 43 68 1039 45 68 1041 minecraft:stone_bricks
setblock 44 72 1040 minecraft:bell[attachment=ceiling,facing=north]
fill 44 61 1038 44 68 1038 minecraft:ladder[facing=east,waterlogged=false]
setblock 53 61 1040 minecraft:chiseled_stone_bricks
setblock 53 62 1040 minecraft:chiseled_stone_bricks
setblock 53 63 1040 minecraft:candle[candles=4,lit=false]
fill 47 56 1038 51 60 1042 minecraft:deepslate_bricks
fill 48 57 1039 50 59 1041 minecraft:air
setblock 49 60 1040 minecraft:air
setblock 49 61 1040 minecraft:iron_trapdoor[half=top,open=false,waterlogged=true]
setblock 50 57 1041 minecraft:chest[facing=north]
setblock 48 57 1039 minecraft:skeleton_skull[rotation=6]
setblock 49 59 1041 minecraft:soul_lantern[hanging=true]
setblock 48 57 1040 minecraft:ladder[facing=east]
setblock 48 58 1040 minecraft:ladder[facing=east]
setblock 48 59 1040 minecraft:ladder[facing=east]
summon minecraft:text_display 42.97 65.30 1040.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[90f,0f],text:'[{"text": "ST. ALDOUS-BY-THE-WATER\\n", "color": "#B8D4C0", "bold": true}, {"text": "the bell rings for the drowned", "color": "#97A89C"}]',background:1711276032,line_width:120,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]},brightness:{sky:15,block:15}}
