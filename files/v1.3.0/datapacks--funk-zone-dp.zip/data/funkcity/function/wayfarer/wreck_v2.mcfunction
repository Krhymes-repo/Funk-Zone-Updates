# The Wreck of the Gull - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=215,y=-64,z=-821,dx=29,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=215,y=-64,z=-821,dx=29,dy=384,dz=14]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=215,y=-64,z=-821,dx=29,dy=384,dz=14]
kill @e[type=minecraft:minecart,tag=wf_prop,x=215,y=-64,z=-821,dx=29,dy=384,dz=14]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=215,y=-64,z=-821,dx=29,dy=384,dz=14]
setblock 220 51 -815 minecraft:dark_oak_planks
setblock 220 51 -814 minecraft:dark_oak_planks
setblock 220 51 -813 minecraft:dark_oak_planks
setblock 220 52 -815 minecraft:dark_oak_planks
setblock 220 53 -815 minecraft:dark_oak_planks
setblock 220 54 -815 minecraft:stripped_dark_oak_log[axis=x]
setblock 220 52 -813 minecraft:dark_oak_planks
setblock 220 53 -813 minecraft:dark_oak_planks
setblock 220 54 -813 minecraft:stripped_dark_oak_log[axis=x]
fill 220 52 -814 220 55 -814 minecraft:water
setblock 221 51 -815 minecraft:dark_oak_planks
setblock 221 51 -814 minecraft:dark_oak_planks
setblock 221 51 -813 minecraft:dark_oak_planks
setblock 221 52 -815 minecraft:dark_oak_planks
setblock 221 53 -815 minecraft:dark_oak_planks
setblock 221 54 -815 minecraft:stripped_dark_oak_log[axis=x]
setblock 221 52 -813 minecraft:dark_oak_planks
setblock 221 53 -813 minecraft:dark_oak_planks
setblock 221 54 -813 minecraft:stripped_dark_oak_log[axis=x]
fill 221 52 -814 221 55 -814 minecraft:water
setblock 221 54 -814 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 222 51 -816 minecraft:dark_oak_planks
setblock 222 51 -815 minecraft:dark_oak_planks
setblock 222 51 -814 minecraft:dark_oak_planks
setblock 222 51 -813 minecraft:dark_oak_planks
setblock 222 51 -812 minecraft:dark_oak_planks
setblock 222 52 -816 minecraft:dark_oak_planks
setblock 222 53 -816 minecraft:dark_oak_planks
setblock 222 54 -816 minecraft:stripped_dark_oak_log[axis=x]
setblock 222 52 -812 minecraft:dark_oak_planks
setblock 222 53 -812 minecraft:dark_oak_planks
setblock 222 54 -812 minecraft:stripped_dark_oak_log[axis=x]
fill 222 52 -815 222 55 -815 minecraft:water
fill 222 52 -814 222 55 -814 minecraft:water
fill 222 52 -813 222 55 -813 minecraft:water
setblock 222 54 -815 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 222 54 -814 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 222 54 -813 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 223 51 -816 minecraft:dark_oak_planks
setblock 223 51 -815 minecraft:dark_oak_planks
setblock 223 51 -814 minecraft:dark_oak_planks
setblock 223 51 -813 minecraft:dark_oak_planks
setblock 223 51 -812 minecraft:dark_oak_planks
setblock 223 52 -816 minecraft:dark_oak_planks
setblock 223 53 -816 minecraft:dark_oak_planks
setblock 223 54 -816 minecraft:stripped_dark_oak_log[axis=x]
setblock 223 52 -812 minecraft:dark_oak_planks
setblock 223 53 -812 minecraft:dark_oak_planks
setblock 223 54 -812 minecraft:stripped_dark_oak_log[axis=x]
fill 223 52 -815 223 55 -815 minecraft:water
fill 223 52 -814 223 55 -814 minecraft:water
fill 223 52 -813 223 55 -813 minecraft:water
setblock 223 54 -815 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 223 54 -814 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 223 54 -813 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 224 51 -817 minecraft:dark_oak_planks
setblock 224 51 -816 minecraft:dark_oak_planks
setblock 224 51 -815 minecraft:dark_oak_planks
setblock 224 51 -814 minecraft:dark_oak_planks
setblock 224 51 -813 minecraft:dark_oak_planks
setblock 224 51 -812 minecraft:dark_oak_planks
setblock 224 51 -811 minecraft:dark_oak_planks
setblock 224 52 -817 minecraft:dark_oak_planks
setblock 224 53 -817 minecraft:dark_oak_planks
setblock 224 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 224 52 -811 minecraft:dark_oak_planks
setblock 224 53 -811 minecraft:dark_oak_planks
setblock 224 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 224 52 -816 224 55 -816 minecraft:water
fill 224 52 -815 224 55 -815 minecraft:water
fill 224 52 -814 224 55 -814 minecraft:water
fill 224 52 -813 224 55 -813 minecraft:water
fill 224 52 -812 224 55 -812 minecraft:water
setblock 224 54 -816 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 224 54 -815 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 224 54 -814 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 224 54 -812 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 225 51 -817 minecraft:dark_oak_planks
setblock 225 51 -816 minecraft:dark_oak_planks
setblock 225 51 -815 minecraft:dark_oak_planks
setblock 225 51 -814 minecraft:dark_oak_planks
setblock 225 51 -813 minecraft:dark_oak_planks
setblock 225 51 -812 minecraft:dark_oak_planks
setblock 225 51 -811 minecraft:dark_oak_planks
setblock 225 52 -817 minecraft:dark_oak_planks
setblock 225 53 -817 minecraft:dark_oak_planks
setblock 225 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 225 52 -811 minecraft:dark_oak_planks
setblock 225 53 -811 minecraft:dark_oak_planks
setblock 225 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 225 52 -816 225 55 -816 minecraft:water
fill 225 52 -815 225 55 -815 minecraft:water
fill 225 52 -814 225 55 -814 minecraft:water
fill 225 52 -813 225 55 -813 minecraft:water
fill 225 52 -812 225 55 -812 minecraft:water
setblock 225 54 -816 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 225 54 -815 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 225 54 -813 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 225 54 -812 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 226 51 -817 minecraft:dark_oak_planks
setblock 226 51 -816 minecraft:dark_oak_planks
setblock 226 51 -815 minecraft:dark_oak_planks
setblock 226 51 -814 minecraft:dark_oak_planks
setblock 226 51 -813 minecraft:dark_oak_planks
setblock 226 51 -812 minecraft:dark_oak_planks
setblock 226 51 -811 minecraft:dark_oak_planks
setblock 226 52 -817 minecraft:dark_oak_planks
setblock 226 53 -817 minecraft:dark_oak_planks
setblock 226 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 226 52 -811 minecraft:dark_oak_planks
setblock 226 53 -811 minecraft:dark_oak_planks
setblock 226 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 226 52 -816 226 55 -816 minecraft:water
fill 226 52 -815 226 55 -815 minecraft:water
fill 226 52 -814 226 55 -814 minecraft:water
fill 226 52 -813 226 55 -813 minecraft:water
fill 226 52 -812 226 55 -812 minecraft:water
setblock 226 54 -816 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 226 54 -814 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 226 54 -813 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 226 54 -812 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 227 51 -817 minecraft:dark_oak_planks
setblock 227 51 -816 minecraft:dark_oak_planks
setblock 227 51 -815 minecraft:dark_oak_planks
setblock 227 51 -814 minecraft:dark_oak_planks
setblock 227 51 -813 minecraft:dark_oak_planks
setblock 227 51 -812 minecraft:dark_oak_planks
setblock 227 51 -811 minecraft:dark_oak_planks
setblock 227 52 -817 minecraft:dark_oak_planks
setblock 227 53 -817 minecraft:dark_oak_planks
setblock 227 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 227 52 -811 minecraft:dark_oak_planks
setblock 227 53 -811 minecraft:dark_oak_planks
setblock 227 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 227 52 -816 227 55 -816 minecraft:water
fill 227 52 -815 227 55 -815 minecraft:water
fill 227 52 -814 227 55 -814 minecraft:water
fill 227 52 -813 227 55 -813 minecraft:water
fill 227 52 -812 227 55 -812 minecraft:water
setblock 227 54 -815 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 227 54 -814 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 227 54 -813 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 227 54 -812 minecraft:spruce_slab[type=top,waterlogged=true]
setblock 228 51 -817 minecraft:dark_oak_planks
setblock 228 51 -816 minecraft:dark_oak_planks
setblock 228 51 -815 minecraft:dark_oak_planks
setblock 228 51 -814 minecraft:dark_oak_planks
setblock 228 51 -813 minecraft:dark_oak_planks
setblock 228 51 -812 minecraft:dark_oak_planks
setblock 228 51 -811 minecraft:dark_oak_planks
setblock 228 52 -817 minecraft:dark_oak_planks
setblock 228 53 -817 minecraft:dark_oak_planks
setblock 228 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 228 52 -811 minecraft:dark_oak_planks
setblock 228 53 -811 minecraft:dark_oak_planks
setblock 228 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 228 52 -816 228 55 -816 minecraft:water
fill 228 52 -815 228 55 -815 minecraft:water
fill 228 52 -814 228 55 -814 minecraft:water
fill 228 52 -813 228 55 -813 minecraft:water
fill 228 52 -812 228 55 -812 minecraft:water
setblock 229 51 -817 minecraft:dark_oak_planks
setblock 229 51 -816 minecraft:dark_oak_planks
setblock 229 51 -815 minecraft:dark_oak_planks
setblock 229 51 -814 minecraft:dark_oak_planks
setblock 229 51 -813 minecraft:dark_oak_planks
setblock 229 51 -812 minecraft:dark_oak_planks
setblock 229 51 -811 minecraft:dark_oak_planks
setblock 229 52 -817 minecraft:dark_oak_planks
setblock 229 53 -817 minecraft:dark_oak_planks
setblock 229 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 229 52 -811 minecraft:dark_oak_planks
setblock 229 53 -811 minecraft:dark_oak_planks
setblock 229 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 229 52 -816 229 55 -816 minecraft:water
fill 229 52 -815 229 55 -815 minecraft:water
fill 229 52 -814 229 55 -814 minecraft:water
fill 229 52 -813 229 55 -813 minecraft:water
fill 229 52 -812 229 55 -812 minecraft:water
setblock 230 51 -817 minecraft:dark_oak_planks
setblock 230 51 -816 minecraft:dark_oak_planks
setblock 230 51 -815 minecraft:dark_oak_planks
setblock 230 51 -814 minecraft:dark_oak_planks
setblock 230 51 -813 minecraft:dark_oak_planks
setblock 230 51 -812 minecraft:dark_oak_planks
setblock 230 51 -811 minecraft:dark_oak_planks
setblock 230 52 -817 minecraft:dark_oak_planks
setblock 230 53 -817 minecraft:dark_oak_planks
setblock 230 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 230 52 -811 minecraft:dark_oak_planks
setblock 230 53 -811 minecraft:dark_oak_planks
setblock 230 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 230 52 -816 230 55 -816 minecraft:water
fill 230 52 -815 230 55 -815 minecraft:water
fill 230 52 -814 230 55 -814 minecraft:water
fill 230 52 -813 230 55 -813 minecraft:water
fill 230 52 -812 230 55 -812 minecraft:water
setblock 231 51 -817 minecraft:dark_oak_planks
setblock 231 51 -816 minecraft:dark_oak_planks
setblock 231 51 -815 minecraft:dark_oak_planks
setblock 231 51 -814 minecraft:dark_oak_planks
setblock 231 51 -813 minecraft:dark_oak_planks
setblock 231 51 -812 minecraft:dark_oak_planks
setblock 231 51 -811 minecraft:dark_oak_planks
setblock 231 52 -817 minecraft:dark_oak_planks
setblock 231 53 -817 minecraft:dark_oak_planks
setblock 231 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 231 52 -811 minecraft:dark_oak_planks
setblock 231 53 -811 minecraft:dark_oak_planks
setblock 231 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 231 52 -816 231 55 -816 minecraft:water
fill 231 52 -815 231 55 -815 minecraft:water
fill 231 52 -814 231 55 -814 minecraft:water
fill 231 52 -813 231 55 -813 minecraft:water
fill 231 52 -812 231 55 -812 minecraft:water
setblock 232 51 -817 minecraft:dark_oak_planks
setblock 232 51 -816 minecraft:dark_oak_planks
setblock 232 51 -815 minecraft:dark_oak_planks
setblock 232 51 -814 minecraft:dark_oak_planks
setblock 232 51 -813 minecraft:dark_oak_planks
setblock 232 51 -812 minecraft:dark_oak_planks
setblock 232 51 -811 minecraft:dark_oak_planks
setblock 232 52 -817 minecraft:dark_oak_planks
setblock 232 53 -817 minecraft:dark_oak_planks
setblock 232 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 232 52 -811 minecraft:dark_oak_planks
setblock 232 53 -811 minecraft:dark_oak_planks
setblock 232 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 232 52 -816 232 55 -816 minecraft:water
fill 232 52 -815 232 55 -815 minecraft:water
fill 232 52 -814 232 55 -814 minecraft:water
fill 232 52 -813 232 55 -813 minecraft:water
fill 232 52 -812 232 55 -812 minecraft:water
setblock 233 51 -817 minecraft:dark_oak_planks
setblock 233 51 -816 minecraft:dark_oak_planks
setblock 233 51 -815 minecraft:dark_oak_planks
setblock 233 51 -814 minecraft:dark_oak_planks
setblock 233 51 -813 minecraft:dark_oak_planks
setblock 233 51 -812 minecraft:dark_oak_planks
setblock 233 51 -811 minecraft:dark_oak_planks
setblock 233 52 -817 minecraft:dark_oak_planks
setblock 233 53 -817 minecraft:dark_oak_planks
setblock 233 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 233 52 -811 minecraft:dark_oak_planks
setblock 233 53 -811 minecraft:dark_oak_planks
setblock 233 54 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 233 52 -816 233 55 -816 minecraft:water
fill 233 52 -815 233 55 -815 minecraft:water
fill 233 52 -814 233 55 -814 minecraft:water
fill 233 52 -813 233 55 -813 minecraft:water
fill 233 52 -812 233 55 -812 minecraft:water
setblock 234 51 -817 minecraft:dark_oak_planks
setblock 234 51 -816 minecraft:dark_oak_planks
setblock 234 51 -815 minecraft:dark_oak_planks
setblock 234 51 -814 minecraft:dark_oak_planks
setblock 234 51 -813 minecraft:dark_oak_planks
setblock 234 51 -812 minecraft:dark_oak_planks
setblock 234 51 -811 minecraft:dark_oak_planks
setblock 234 52 -817 minecraft:dark_oak_planks
setblock 234 53 -817 minecraft:dark_oak_planks
setblock 234 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 234 52 -811 minecraft:dark_oak_planks
setblock 234 53 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 234 52 -816 234 55 -816 minecraft:water
fill 234 52 -815 234 55 -815 minecraft:water
fill 234 52 -814 234 55 -814 minecraft:water
fill 234 52 -813 234 55 -813 minecraft:water
fill 234 52 -812 234 55 -812 minecraft:water
setblock 235 51 -817 minecraft:dark_oak_planks
setblock 235 51 -816 minecraft:dark_oak_planks
setblock 235 51 -815 minecraft:dark_oak_planks
setblock 235 51 -814 minecraft:dark_oak_planks
setblock 235 51 -813 minecraft:dark_oak_planks
setblock 235 51 -812 minecraft:dark_oak_planks
setblock 235 51 -811 minecraft:dark_oak_planks
setblock 235 52 -817 minecraft:dark_oak_planks
setblock 235 53 -817 minecraft:dark_oak_planks
setblock 235 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 235 52 -811 minecraft:dark_oak_planks
setblock 235 53 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 235 52 -816 235 55 -816 minecraft:water
fill 235 52 -815 235 55 -815 minecraft:water
fill 235 52 -814 235 55 -814 minecraft:water
fill 235 52 -813 235 55 -813 minecraft:water
fill 235 52 -812 235 55 -812 minecraft:water
setblock 236 51 -817 minecraft:dark_oak_planks
setblock 236 51 -816 minecraft:dark_oak_planks
setblock 236 51 -815 minecraft:dark_oak_planks
setblock 236 51 -814 minecraft:dark_oak_planks
setblock 236 51 -813 minecraft:dark_oak_planks
setblock 236 51 -812 minecraft:dark_oak_planks
setblock 236 51 -811 minecraft:dark_oak_planks
setblock 236 52 -817 minecraft:dark_oak_planks
setblock 236 53 -817 minecraft:dark_oak_planks
setblock 236 54 -817 minecraft:stripped_dark_oak_log[axis=x]
setblock 236 52 -811 minecraft:dark_oak_planks
setblock 236 53 -811 minecraft:stripped_dark_oak_log[axis=x]
fill 236 52 -816 236 55 -816 minecraft:water
fill 236 52 -815 236 55 -815 minecraft:water
fill 236 52 -814 236 55 -814 minecraft:water
fill 236 52 -813 236 55 -813 minecraft:water
fill 236 52 -812 236 55 -812 minecraft:water
setblock 237 51 -816 minecraft:dark_oak_planks
setblock 237 51 -815 minecraft:dark_oak_planks
setblock 237 51 -814 minecraft:dark_oak_planks
setblock 237 51 -813 minecraft:dark_oak_planks
setblock 237 51 -812 minecraft:dark_oak_planks
setblock 237 52 -816 minecraft:dark_oak_planks
setblock 237 53 -816 minecraft:dark_oak_planks
setblock 237 54 -816 minecraft:stripped_dark_oak_log[axis=x]
setblock 237 52 -812 minecraft:dark_oak_planks
setblock 237 53 -812 minecraft:dark_oak_planks
setblock 237 54 -812 minecraft:stripped_dark_oak_log[axis=x]
fill 237 52 -815 237 55 -815 minecraft:water
fill 237 52 -814 237 55 -814 minecraft:water
fill 237 52 -813 237 55 -813 minecraft:water
setblock 238 51 -816 minecraft:dark_oak_planks
setblock 238 51 -815 minecraft:dark_oak_planks
setblock 238 51 -814 minecraft:dark_oak_planks
setblock 238 51 -813 minecraft:dark_oak_planks
setblock 238 51 -812 minecraft:dark_oak_planks
setblock 238 52 -816 minecraft:dark_oak_planks
setblock 238 53 -816 minecraft:dark_oak_planks
setblock 238 54 -816 minecraft:stripped_dark_oak_log[axis=x]
setblock 238 52 -812 minecraft:dark_oak_planks
setblock 238 53 -812 minecraft:dark_oak_planks
setblock 238 54 -812 minecraft:stripped_dark_oak_log[axis=x]
fill 238 52 -815 238 55 -815 minecraft:water
fill 238 52 -814 238 55 -814 minecraft:water
fill 238 52 -813 238 55 -813 minecraft:water
setblock 239 51 -815 minecraft:dark_oak_planks
setblock 239 51 -814 minecraft:dark_oak_planks
setblock 239 51 -813 minecraft:dark_oak_planks
setblock 239 52 -815 minecraft:dark_oak_planks
setblock 239 53 -815 minecraft:dark_oak_planks
setblock 239 54 -815 minecraft:stripped_dark_oak_log[axis=x]
setblock 239 52 -813 minecraft:dark_oak_planks
setblock 239 53 -813 minecraft:dark_oak_planks
setblock 239 54 -813 minecraft:stripped_dark_oak_log[axis=x]
fill 239 52 -814 239 55 -814 minecraft:water
setblock 240 51 -815 minecraft:dark_oak_planks
setblock 240 51 -814 minecraft:dark_oak_planks
setblock 240 51 -813 minecraft:dark_oak_planks
setblock 240 52 -815 minecraft:dark_oak_planks
setblock 240 53 -815 minecraft:dark_oak_planks
setblock 240 54 -815 minecraft:stripped_dark_oak_log[axis=x]
setblock 240 52 -813 minecraft:dark_oak_planks
setblock 240 53 -813 minecraft:dark_oak_planks
setblock 240 54 -813 minecraft:stripped_dark_oak_log[axis=x]
fill 240 52 -814 240 55 -814 minecraft:water
fill 220 52 -814 220 56 -814 minecraft:dark_oak_log
fill 240 52 -814 240 55 -814 minecraft:dark_oak_log
fill 229 52 -814 229 58 -814 minecraft:stripped_spruce_log
setblock 230 54 -812 minecraft:spruce_log[axis=x]
setblock 231 54 -812 minecraft:spruce_log[axis=x]
setblock 232 55 -812 minecraft:spruce_log[axis=x]
setblock 233 55 -812 minecraft:spruce_log[axis=x]
setblock 234 55 -812 minecraft:spruce_log[axis=x]
setblock 235 56 -812 minecraft:spruce_log[axis=x]
fill 227 56 -815 228 57 -815 minecraft:white_wool
setblock 223 52 -814 minecraft:chest[facing=east,waterlogged=true]
setblock 223 52 -815 minecraft:barrel[facing=up]
setblock 224 52 -813 minecraft:barrel[facing=east]
setblock 222 53 -814 minecraft:sea_lantern
setblock 232 52 -815 minecraft:sea_pickle[pickles=3,waterlogged=true]
summon minecraft:text_display 219.48 54.20 -813.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[90f,0f],text:'[{"text": "THE GULL\\n", "color": "#E8E2D0", "bold": true}, {"text": "Cascade Harbor", "color": "#A9C8D8"}]',background:1711276032,line_width:120,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]},brightness:{sky:15,block:15}}
