# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-97,y=-64,z=-829,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-97,y=-64,z=-829,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-97,y=-64,z=-829,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-97,y=-64,z=-829,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-97,y=-64,z=-829,dx=18,dy=384,dz=18]
fill -92 64 -824 -84 77 -816 minecraft:air replace #minecraft:leaves
fill -92 64 -824 -84 77 -816 minecraft:air replace #minecraft:logs
fill -92 64 -824 -84 77 -816 minecraft:air replace #minecraft:replaceable
fill -92 64 -824 -84 77 -816 minecraft:air replace #minecraft:flowers
fill -92 64 -824 -84 77 -816 minecraft:air replace #minecraft:saplings
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:cactus
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:sugar_cane
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:bamboo
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:sweet_berry_bush
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:vine
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:dead_bush
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:snow
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:moss_carpet
fill -92 64 -824 -84 77 -816 minecraft:air replace minecraft:pink_petals
fill -91 63 -823 -85 63 -817 minecraft:sand
fill -93 64 -825 -83 85 -815 minecraft:air replace #minecraft:leaves
fill -93 64 -825 -83 85 -815 minecraft:air replace #minecraft:logs
fill -93 64 -825 -83 85 -815 minecraft:air replace #minecraft:replaceable
fill -93 64 -825 -83 85 -815 minecraft:air replace #minecraft:flowers
fill -93 64 -825 -83 85 -815 minecraft:air replace #minecraft:saplings
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:cactus
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:sugar_cane
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:bamboo
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:sweet_berry_bush
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:vine
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:dead_bush
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:snow
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:moss_carpet
fill -93 64 -825 -83 85 -815 minecraft:air replace minecraft:pink_petals
setblock -88 64 -820 minecraft:campfire[lit=false]
setblock -86 64 -820 minecraft:mossy_cobblestone_slab
setblock -90 64 -820 minecraft:mossy_cobblestone_slab
setblock -88 64 -818 minecraft:mossy_cobblestone_slab
setblock -88 64 -822 minecraft:mossy_cobblestone_slab
setblock -91 64 -821 minecraft:brown_carpet
setblock -91 64 -820 minecraft:brown_carpet
setblock -91 64 -819 minecraft:white_carpet
setblock -85 64 -821 minecraft:spruce_fence
setblock -85 65 -821 minecraft:lantern[hanging=false]
setblock -87 64 -822 minecraft:chest[facing=south]
setblock -86 64 -822 minecraft:barrel[facing=up]
summon minecraft:item_frame -86 65 -822 {Facing:1b,Invisible:1b,Fixed:1b,Invulnerable:1b,Tags:["wf_prop"],Item:{id:"minecraft:iron_pickaxe",count:1}}
setblock -90 64 -817 minecraft:spruce_fence
setblock -90 65 -817 minecraft:spruce_fence
setblock -90 66 -817 minecraft:light_gray_banner[rotation=0]
