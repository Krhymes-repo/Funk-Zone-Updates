# The Wayfarer Expedition: take down an older Tamsin fire + Discovery Board
execute positioned ~10 ~0 ~38 run kill @e[type=minecraft:text_display,tag=wf_board,dx=14,dy=10,dz=6]
execute positioned ~11 ~-2 ~18 run kill @e[tag=fq_wf_tamsin,dx=12,dy=8,dz=12]
execute positioned ~11 ~-2 ~18 run kill @e[type=minecraft:text_display,tag=funk_lvl,dx=12,dy=8,dz=12]
fill ~14 ~1 ~21 ~20 ~3 ~27 minecraft:air
fill ~16 ~0 ~23 ~18 ~0 ~25 minecraft:grass_block
fill ~11 ~1 ~40 ~21 ~7 ~42 minecraft:air
fill ~11 ~0 ~39 ~21 ~0 ~43 minecraft:grass_block replace minecraft:dirt_path
fill ~16 ~0 ~33 ~16 ~0 ~49 minecraft:grass_block replace minecraft:dirt_path
