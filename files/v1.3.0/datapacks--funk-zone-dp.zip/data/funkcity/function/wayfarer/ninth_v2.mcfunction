# The Ninth Gate - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=975,y=-64,z=-161,dx=24,dy=384,dz=24]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=975,y=-64,z=-161,dx=24,dy=384,dz=24]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=975,y=-64,z=-161,dx=24,dy=384,dz=24]
kill @e[type=minecraft:minecart,tag=wf_prop,x=975,y=-64,z=-161,dx=24,dy=384,dz=24]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=975,y=-64,z=-161,dx=24,dy=384,dz=24]
fill 979 66 -157 995 87 -141 minecraft:air replace #minecraft:leaves
fill 979 66 -157 995 87 -141 minecraft:air replace #minecraft:logs
fill 979 66 -157 995 87 -141 minecraft:air replace #minecraft:replaceable
fill 979 66 -157 995 87 -141 minecraft:air replace #minecraft:flowers
fill 979 66 -157 995 87 -141 minecraft:air replace #minecraft:saplings
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:cactus
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:sugar_cane
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:bamboo
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:sweet_berry_bush
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:vine
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:dead_bush
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:snow
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:moss_carpet
fill 979 66 -157 995 87 -141 minecraft:air replace minecraft:pink_petals
fill 980 63 -149 980 64 -149 minecraft:sandstone
fill 980 63 -148 980 64 -148 minecraft:sandstone
fill 980 63 -147 980 64 -147 minecraft:sandstone
fill 980 63 -146 980 64 -146 minecraft:sandstone
fill 980 63 -145 980 64 -145 minecraft:sandstone
fill 980 63 -144 980 64 -144 minecraft:sandstone
fill 980 63 -143 980 64 -143 minecraft:sandstone
fill 980 63 -142 980 64 -142 minecraft:sandstone
fill 981 63 -149 981 64 -149 minecraft:sandstone
fill 981 63 -148 981 64 -148 minecraft:sandstone
fill 981 63 -147 981 64 -147 minecraft:sandstone
fill 981 63 -146 981 64 -146 minecraft:sandstone
fill 981 63 -145 981 64 -145 minecraft:sandstone
fill 981 63 -144 981 64 -144 minecraft:sandstone
fill 981 63 -143 981 64 -143 minecraft:sandstone
fill 981 63 -142 981 64 -142 minecraft:sandstone
fill 982 63 -155 982 64 -155 minecraft:sandstone
fill 982 63 -154 982 64 -154 minecraft:sandstone
fill 982 63 -153 982 64 -153 minecraft:sandstone
fill 982 63 -152 982 64 -152 minecraft:sandstone
fill 982 63 -151 982 64 -151 minecraft:sandstone
fill 982 63 -150 982 64 -150 minecraft:sandstone
fill 982 63 -149 982 64 -149 minecraft:sandstone
fill 982 63 -148 982 64 -148 minecraft:sandstone
fill 982 63 -147 982 64 -147 minecraft:sandstone
fill 982 63 -146 982 64 -146 minecraft:sandstone
fill 982 63 -145 982 64 -145 minecraft:sandstone
fill 982 63 -144 982 64 -144 minecraft:sandstone
fill 982 63 -143 982 64 -143 minecraft:sandstone
fill 982 63 -142 982 64 -142 minecraft:sandstone
fill 983 63 -156 983 64 -156 minecraft:sandstone
fill 983 63 -155 983 64 -155 minecraft:sandstone
fill 983 63 -154 983 64 -154 minecraft:sandstone
fill 983 63 -153 983 64 -153 minecraft:sandstone
fill 983 63 -152 983 64 -152 minecraft:sandstone
fill 983 63 -151 983 64 -151 minecraft:sandstone
fill 983 63 -150 983 64 -150 minecraft:sandstone
fill 983 63 -149 983 64 -149 minecraft:sandstone
fill 983 63 -147 983 64 -147 minecraft:sandstone
fill 983 63 -146 983 64 -146 minecraft:sandstone
fill 983 63 -145 983 64 -145 minecraft:sandstone
fill 983 63 -144 983 64 -144 minecraft:sandstone
fill 983 63 -143 983 64 -143 minecraft:sandstone
fill 983 63 -142 983 64 -142 minecraft:sandstone
fill 984 63 -156 984 64 -156 minecraft:sandstone
fill 984 63 -155 984 64 -155 minecraft:sandstone
fill 984 63 -154 984 64 -154 minecraft:sandstone
fill 984 63 -153 984 64 -153 minecraft:sandstone
fill 984 63 -152 984 64 -152 minecraft:sandstone
fill 984 63 -151 984 64 -151 minecraft:sandstone
fill 984 63 -150 984 64 -150 minecraft:sandstone
fill 984 63 -149 984 64 -149 minecraft:sandstone
fill 984 63 -143 984 64 -143 minecraft:sandstone
fill 984 63 -142 984 64 -142 minecraft:sandstone
fill 985 63 -156 985 64 -156 minecraft:sandstone
fill 985 63 -155 985 64 -155 minecraft:sandstone
fill 985 63 -154 985 64 -154 minecraft:sandstone
fill 985 63 -153 985 64 -153 minecraft:sandstone
fill 985 63 -152 985 64 -152 minecraft:sandstone
fill 985 63 -151 985 64 -151 minecraft:sandstone
fill 985 63 -150 985 64 -150 minecraft:sandstone
fill 985 63 -149 985 64 -149 minecraft:sandstone
fill 985 63 -148 985 64 -148 minecraft:sandstone
fill 985 63 -147 985 64 -147 minecraft:sandstone
fill 986 63 -156 986 64 -156 minecraft:sandstone
fill 986 63 -155 986 64 -155 minecraft:sandstone
fill 986 63 -154 986 64 -154 minecraft:sandstone
fill 986 63 -153 986 64 -153 minecraft:sandstone
fill 986 63 -152 986 64 -152 minecraft:sandstone
fill 986 63 -151 986 64 -151 minecraft:sandstone
fill 986 63 -150 986 64 -150 minecraft:sandstone
fill 986 63 -149 986 64 -149 minecraft:sandstone
fill 986 63 -148 986 64 -148 minecraft:sandstone
fill 986 63 -147 986 64 -147 minecraft:sandstone
fill 986 63 -146 986 64 -146 minecraft:sandstone
fill 987 63 -156 987 64 -156 minecraft:sandstone
fill 987 63 -155 987 64 -155 minecraft:sandstone
fill 987 63 -154 987 64 -154 minecraft:sandstone
fill 987 63 -153 987 64 -153 minecraft:sandstone
fill 987 63 -152 987 64 -152 minecraft:sandstone
fill 987 63 -151 987 64 -151 minecraft:sandstone
fill 987 63 -150 987 64 -150 minecraft:sandstone
fill 987 63 -149 987 64 -149 minecraft:sandstone
fill 987 63 -148 987 64 -148 minecraft:sandstone
fill 987 63 -147 987 64 -147 minecraft:sandstone
fill 987 63 -146 987 64 -146 minecraft:sandstone
fill 988 63 -156 988 64 -156 minecraft:sandstone
fill 988 63 -155 988 64 -155 minecraft:sandstone
fill 988 63 -154 988 64 -154 minecraft:sandstone
fill 988 63 -153 988 64 -153 minecraft:sandstone
fill 988 63 -152 988 64 -152 minecraft:sandstone
fill 988 63 -151 988 64 -151 minecraft:sandstone
fill 988 63 -150 988 64 -150 minecraft:sandstone
fill 988 63 -149 988 64 -149 minecraft:sandstone
fill 988 63 -148 988 64 -148 minecraft:sandstone
fill 988 63 -147 988 64 -147 minecraft:sandstone
fill 988 63 -146 988 64 -146 minecraft:sandstone
fill 989 63 -156 989 64 -156 minecraft:sandstone
fill 989 63 -155 989 64 -155 minecraft:sandstone
fill 989 63 -154 989 64 -154 minecraft:sandstone
fill 989 63 -153 989 64 -153 minecraft:sandstone
fill 989 63 -152 989 64 -152 minecraft:sandstone
fill 989 63 -151 989 64 -151 minecraft:sandstone
fill 989 63 -150 989 64 -150 minecraft:sandstone
fill 989 63 -149 989 64 -149 minecraft:sandstone
fill 989 63 -148 989 64 -148 minecraft:sandstone
fill 989 63 -147 989 64 -147 minecraft:sandstone
fill 989 63 -146 989 64 -146 minecraft:sandstone
fill 990 63 -156 990 64 -156 minecraft:sandstone
fill 990 63 -155 990 64 -155 minecraft:sandstone
fill 990 63 -154 990 64 -154 minecraft:sandstone
fill 990 63 -153 990 64 -153 minecraft:sandstone
fill 990 63 -152 990 64 -152 minecraft:sandstone
fill 990 63 -151 990 64 -151 minecraft:sandstone
fill 990 63 -150 990 64 -150 minecraft:sandstone
fill 990 63 -149 990 64 -149 minecraft:sandstone
fill 990 63 -148 990 64 -148 minecraft:sandstone
fill 990 63 -147 990 64 -147 minecraft:sandstone
fill 991 63 -156 991 64 -156 minecraft:sandstone
fill 991 63 -155 991 64 -155 minecraft:sandstone
fill 991 63 -154 991 64 -154 minecraft:sandstone
fill 991 63 -153 991 64 -153 minecraft:sandstone
fill 991 63 -152 991 64 -152 minecraft:sandstone
fill 991 63 -151 991 64 -151 minecraft:sandstone
fill 991 63 -150 991 64 -150 minecraft:sandstone
fill 991 63 -149 991 64 -149 minecraft:sandstone
fill 991 63 -148 991 64 -148 minecraft:sandstone
fill 991 63 -147 991 64 -147 minecraft:sandstone
fill 992 63 -156 992 64 -156 minecraft:sandstone
fill 992 63 -155 992 64 -155 minecraft:sandstone
fill 992 63 -154 992 64 -154 minecraft:sandstone
fill 992 63 -153 992 64 -153 minecraft:sandstone
fill 992 63 -152 992 64 -152 minecraft:sandstone
fill 992 63 -151 992 64 -151 minecraft:sandstone
fill 992 63 -150 992 64 -150 minecraft:sandstone
fill 992 63 -149 992 64 -149 minecraft:sandstone
fill 992 63 -148 992 64 -148 minecraft:sandstone
fill 993 63 -156 993 64 -156 minecraft:sandstone
fill 993 63 -155 993 64 -155 minecraft:sandstone
fill 993 63 -154 993 64 -154 minecraft:sandstone
fill 993 63 -153 993 64 -153 minecraft:sandstone
fill 993 63 -152 993 64 -152 minecraft:sandstone
fill 993 63 -151 993 64 -151 minecraft:sandstone
fill 993 63 -150 993 64 -150 minecraft:sandstone
fill 993 63 -149 993 64 -149 minecraft:sandstone
fill 993 63 -148 993 64 -148 minecraft:sandstone
fill 994 63 -156 994 64 -156 minecraft:sandstone
fill 994 63 -155 994 64 -155 minecraft:sandstone
fill 994 63 -154 994 64 -154 minecraft:sandstone
fill 994 63 -153 994 64 -153 minecraft:sandstone
fill 994 63 -152 994 64 -152 minecraft:sandstone
fill 994 63 -151 994 64 -151 minecraft:sandstone
fill 980 65 -156 994 65 -142 minecraft:sand
setblock 982 65 -151 minecraft:stone_bricks
setblock 982 65 -150 minecraft:stone_bricks
setblock 982 65 -149 minecraft:cracked_stone_bricks
setblock 982 65 -148 minecraft:cracked_stone_bricks
setblock 982 65 -147 minecraft:cracked_stone_bricks
setblock 983 65 -152 minecraft:cracked_stone_bricks
setblock 983 65 -151 minecraft:cracked_stone_bricks
setblock 983 65 -150 minecraft:stone_bricks
setblock 983 65 -149 minecraft:mossy_stone_bricks
setblock 983 65 -148 minecraft:stone_bricks
setblock 983 65 -147 minecraft:stone_bricks
setblock 983 65 -146 minecraft:stone_bricks
setblock 984 65 -153 minecraft:cracked_stone_bricks
setblock 984 65 -152 minecraft:stone_bricks
setblock 984 65 -151 minecraft:cracked_stone_bricks
setblock 984 65 -150 minecraft:mossy_stone_bricks
setblock 984 65 -149 minecraft:stone_bricks
setblock 984 65 -148 minecraft:cracked_stone_bricks
setblock 984 65 -147 minecraft:cracked_stone_bricks
setblock 984 65 -146 minecraft:stone_bricks
setblock 984 65 -145 minecraft:cracked_stone_bricks
setblock 985 65 -154 minecraft:mossy_stone_bricks
setblock 985 65 -153 minecraft:stone_bricks
setblock 985 65 -152 minecraft:stone_bricks
setblock 985 65 -151 minecraft:stone_bricks
setblock 985 65 -150 minecraft:mossy_stone_bricks
setblock 985 65 -149 minecraft:stone_bricks
setblock 985 65 -148 minecraft:stone_bricks
setblock 985 65 -147 minecraft:mossy_stone_bricks
setblock 985 65 -146 minecraft:stone_bricks
setblock 985 65 -145 minecraft:stone_bricks
setblock 985 65 -144 minecraft:cracked_stone_bricks
setblock 986 65 -154 minecraft:mossy_stone_bricks
setblock 986 65 -153 minecraft:stone_bricks
setblock 986 65 -152 minecraft:stone_bricks
setblock 986 65 -151 minecraft:cracked_stone_bricks
setblock 986 65 -150 minecraft:stone_bricks
setblock 986 65 -149 minecraft:stone_bricks
setblock 986 65 -148 minecraft:mossy_stone_bricks
setblock 986 65 -147 minecraft:cracked_stone_bricks
setblock 986 65 -146 minecraft:cracked_stone_bricks
setblock 986 65 -145 minecraft:cracked_stone_bricks
setblock 986 65 -144 minecraft:stone_bricks
setblock 987 65 -154 minecraft:cracked_stone_bricks
setblock 987 65 -153 minecraft:cracked_stone_bricks
setblock 987 65 -152 minecraft:stone_bricks
setblock 987 65 -151 minecraft:stone_bricks
setblock 987 65 -150 minecraft:stone_bricks
setblock 987 65 -149 minecraft:cracked_stone_bricks
setblock 987 65 -148 minecraft:stone_bricks
setblock 987 65 -147 minecraft:stone_bricks
setblock 987 65 -146 minecraft:stone_bricks
setblock 987 65 -145 minecraft:stone_bricks
setblock 987 65 -144 minecraft:stone_bricks
setblock 988 65 -154 minecraft:cracked_stone_bricks
setblock 988 65 -153 minecraft:mossy_stone_bricks
setblock 988 65 -152 minecraft:stone_bricks
setblock 988 65 -151 minecraft:stone_bricks
setblock 988 65 -150 minecraft:mossy_stone_bricks
setblock 988 65 -149 minecraft:cracked_stone_bricks
setblock 988 65 -148 minecraft:stone_bricks
setblock 988 65 -147 minecraft:cracked_stone_bricks
setblock 988 65 -146 minecraft:stone_bricks
setblock 988 65 -145 minecraft:cracked_stone_bricks
setblock 988 65 -144 minecraft:stone_bricks
setblock 989 65 -154 minecraft:mossy_stone_bricks
setblock 989 65 -153 minecraft:stone_bricks
setblock 989 65 -152 minecraft:cracked_stone_bricks
setblock 989 65 -151 minecraft:mossy_stone_bricks
setblock 989 65 -150 minecraft:stone_bricks
setblock 989 65 -149 minecraft:stone_bricks
setblock 989 65 -148 minecraft:cracked_stone_bricks
setblock 989 65 -147 minecraft:cracked_stone_bricks
setblock 989 65 -146 minecraft:stone_bricks
setblock 989 65 -145 minecraft:stone_bricks
setblock 989 65 -144 minecraft:stone_bricks
setblock 990 65 -153 minecraft:stone_bricks
setblock 990 65 -152 minecraft:cracked_stone_bricks
setblock 990 65 -151 minecraft:mossy_stone_bricks
setblock 990 65 -150 minecraft:cracked_stone_bricks
setblock 990 65 -149 minecraft:cracked_stone_bricks
setblock 990 65 -148 minecraft:stone_bricks
setblock 990 65 -147 minecraft:cracked_stone_bricks
setblock 990 65 -146 minecraft:cracked_stone_bricks
setblock 990 65 -145 minecraft:mossy_stone_bricks
setblock 991 65 -152 minecraft:stone_bricks
setblock 991 65 -151 minecraft:cracked_stone_bricks
setblock 991 65 -150 minecraft:mossy_stone_bricks
setblock 991 65 -149 minecraft:stone_bricks
setblock 991 65 -148 minecraft:mossy_stone_bricks
setblock 991 65 -147 minecraft:cracked_stone_bricks
setblock 991 65 -146 minecraft:stone_bricks
setblock 992 65 -151 minecraft:mossy_stone_bricks
setblock 992 65 -150 minecraft:stone_bricks
setblock 992 65 -149 minecraft:stone_bricks
setblock 992 65 -148 minecraft:mossy_stone_bricks
setblock 992 65 -147 minecraft:cracked_stone_bricks
setblock 984 66 -149 minecraft:cracked_stone_bricks
setblock 984 66 -150 minecraft:stone_brick_wall
setblock 984 66 -148 minecraft:stone_brick_wall
setblock 984 67 -149 minecraft:cracked_stone_bricks
setblock 984 67 -150 minecraft:stone_brick_wall
setblock 984 67 -148 minecraft:stone_brick_wall
setblock 984 68 -149 minecraft:cracked_stone_bricks
setblock 984 68 -150 minecraft:stone_brick_wall
setblock 984 68 -148 minecraft:stone_brick_wall
setblock 984 69 -149 minecraft:cracked_stone_bricks
setblock 984 69 -150 minecraft:stone_brick_wall
setblock 984 69 -148 minecraft:stone_brick_wall
setblock 984 70 -149 minecraft:cracked_stone_bricks
setblock 984 70 -150 minecraft:stone_brick_wall
setblock 984 70 -148 minecraft:stone_brick_wall
setblock 984 71 -149 minecraft:cracked_stone_bricks
setblock 984 71 -150 minecraft:stone_brick_wall
setblock 984 71 -148 minecraft:stone_brick_wall
setblock 984 72 -149 minecraft:cracked_stone_bricks
setblock 984 72 -150 minecraft:stone_brick_wall
setblock 984 72 -148 minecraft:stone_brick_wall
setblock 984 73 -149 minecraft:mossy_stone_bricks
setblock 984 73 -150 minecraft:stone_brick_wall
setblock 984 73 -148 minecraft:stone_brick_wall
setblock 984 74 -149 minecraft:stone_bricks
setblock 984 74 -150 minecraft:stone_bricks
setblock 984 74 -148 minecraft:stone_bricks
setblock 984 75 -149 minecraft:stone_bricks
setblock 984 75 -150 minecraft:stone_bricks
setblock 984 75 -148 minecraft:stone_bricks
setblock 990 66 -149 minecraft:stone_bricks
setblock 990 66 -150 minecraft:stone_brick_wall
setblock 990 66 -148 minecraft:stone_brick_wall
setblock 990 67 -149 minecraft:cracked_stone_bricks
setblock 990 67 -150 minecraft:stone_brick_wall
setblock 990 67 -148 minecraft:stone_brick_wall
setblock 990 68 -149 minecraft:mossy_stone_bricks
setblock 990 68 -150 minecraft:stone_brick_wall
setblock 990 68 -148 minecraft:stone_brick_wall
setblock 990 69 -149 minecraft:cracked_stone_bricks
setblock 990 69 -150 minecraft:stone_brick_wall
setblock 990 69 -148 minecraft:stone_brick_wall
setblock 990 70 -149 minecraft:cracked_stone_bricks
setblock 990 70 -150 minecraft:stone_brick_wall
setblock 990 70 -148 minecraft:stone_brick_wall
setblock 990 71 -149 minecraft:stone_bricks
setblock 990 71 -150 minecraft:stone_brick_wall
setblock 990 71 -148 minecraft:stone_brick_wall
setblock 990 72 -149 minecraft:cracked_stone_bricks
setblock 990 72 -150 minecraft:stone_brick_wall
setblock 990 72 -148 minecraft:stone_brick_wall
setblock 990 73 -149 minecraft:mossy_stone_bricks
setblock 990 73 -150 minecraft:stone_brick_wall
setblock 990 73 -148 minecraft:stone_brick_wall
setblock 990 74 -149 minecraft:stone_bricks
setblock 990 74 -150 minecraft:stone_bricks
setblock 990 74 -148 minecraft:stone_bricks
setblock 990 75 -149 minecraft:mossy_stone_bricks
setblock 990 75 -150 minecraft:stone_bricks
setblock 990 75 -148 minecraft:stone_bricks
setblock 983 76 -149 minecraft:stone_bricks
setblock 984 76 -149 minecraft:stone_bricks
setblock 985 76 -149 minecraft:stone_bricks
setblock 986 76 -149 minecraft:stone_bricks
setblock 987 76 -149 minecraft:chiseled_stone_bricks
setblock 989 76 -149 minecraft:stone_bricks
setblock 990 76 -149 minecraft:stone_bricks
setblock 991 76 -149 minecraft:stone_bricks
setblock 987 77 -149 minecraft:chiseled_stone_bricks
setblock 992 66 -146 minecraft:stone_bricks
setblock 993 66 -146 minecraft:stone_brick_stairs[facing=west]
summon minecraft:text_display 987.50 75.00 -147.97 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "IX\\n", "color": "#E6D3A3", "bold": true}, {"text": "the road that was not built", "color": "#B8A888", "italic": true}]',background:1711276032,line_width:160,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 987.50 75.00 -149.03 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "IX\\n", "color": "#E6D3A3", "bold": true}, {"text": "the road that was not built", "color": "#B8A888", "italic": true}]',background:1711276032,line_width:160,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
setblock 985 66 -147 minecraft:heavy_weighted_pressure_plate
setblock 987 66 -147 minecraft:heavy_weighted_pressure_plate
setblock 989 66 -147 minecraft:heavy_weighted_pressure_plate
setblock 985 66 -151 minecraft:heavy_weighted_pressure_plate
setblock 987 66 -151 minecraft:heavy_weighted_pressure_plate
setblock 989 66 -151 minecraft:heavy_weighted_pressure_plate
setblock 986 65 -149 minecraft:chiseled_stone_bricks
setblock 987 65 -149 minecraft:chiseled_stone_bricks
setblock 988 65 -149 minecraft:chiseled_stone_bricks
fill 986 54 -149 988 64 -149 minecraft:air
fill 985 54 -150 989 64 -150 minecraft:stone_bricks
fill 985 54 -148 989 64 -148 minecraft:stone_bricks
fill 985 54 -149 985 64 -149 minecraft:stone_bricks
fill 989 54 -149 989 64 -149 minecraft:stone_bricks
fill 986 57 -149 986 64 -149 minecraft:ladder[facing=east]
fill 981 52 -154 993 58 -144 minecraft:stone_bricks
fill 982 54 -153 992 57 -145 minecraft:air
fill 982 53 -153 992 53 -145 minecraft:smooth_sandstone
fill 986 54 -149 986 56 -149 minecraft:ladder[facing=east]
fill 985 54 -150 989 57 -148 minecraft:air replace minecraft:stone_bricks
fill 985 54 -149 985 57 -149 minecraft:chiseled_stone_bricks
fill 986 54 -149 986 57 -149 minecraft:ladder[facing=east]
setblock 987 54 -149 minecraft:stone_pressure_plate
setblock 990 54 -147 minecraft:campfire[lit=false]
setblock 991 54 -151 minecraft:brown_carpet
setblock 991 54 -152 minecraft:brown_carpet
setblock 990 54 -152 minecraft:white_carpet
setblock 983 54 -146 minecraft:barrel[facing=up]
setblock 984 54 -146 minecraft:barrel[facing=north]
setblock 983 55 -146 minecraft:lantern[hanging=false]
setblock 983 54 -152 minecraft:chest[facing=south]
setblock 984 54 -152 minecraft:lectern[facing=south]
setblock 988 57 -146 minecraft:lantern[hanging=true]
setblock 985 57 -152 minecraft:lantern[hanging=true]
setblock 993 54 -153 minecraft:smooth_sandstone
setblock 993 55 -153 minecraft:smooth_sandstone
setblock 993 56 -153 minecraft:smooth_sandstone
setblock 993 57 -153 minecraft:smooth_sandstone
setblock 993 54 -152 minecraft:smooth_sandstone
setblock 993 55 -152 minecraft:smooth_sandstone
setblock 993 56 -152 minecraft:smooth_sandstone
setblock 993 57 -152 minecraft:smooth_sandstone
setblock 993 54 -151 minecraft:smooth_sandstone
setblock 993 55 -151 minecraft:smooth_sandstone
setblock 993 56 -151 minecraft:smooth_sandstone
setblock 993 57 -151 minecraft:smooth_sandstone
setblock 993 54 -150 minecraft:smooth_sandstone
setblock 993 55 -150 minecraft:smooth_sandstone
setblock 993 56 -150 minecraft:smooth_sandstone
setblock 993 57 -150 minecraft:smooth_sandstone
setblock 993 54 -149 minecraft:smooth_sandstone
setblock 993 55 -149 minecraft:smooth_sandstone
setblock 993 56 -149 minecraft:smooth_sandstone
setblock 993 57 -149 minecraft:smooth_sandstone
setblock 993 54 -148 minecraft:smooth_sandstone
setblock 993 55 -148 minecraft:smooth_sandstone
setblock 993 56 -148 minecraft:smooth_sandstone
setblock 993 57 -148 minecraft:smooth_sandstone
setblock 993 54 -147 minecraft:smooth_sandstone
setblock 993 55 -147 minecraft:smooth_sandstone
setblock 993 56 -147 minecraft:smooth_sandstone
setblock 993 57 -147 minecraft:smooth_sandstone
setblock 993 54 -146 minecraft:smooth_sandstone
setblock 993 55 -146 minecraft:smooth_sandstone
setblock 993 56 -146 minecraft:smooth_sandstone
setblock 993 57 -146 minecraft:smooth_sandstone
setblock 993 54 -145 minecraft:smooth_sandstone
setblock 993 55 -145 minecraft:smooth_sandstone
setblock 993 56 -145 minecraft:smooth_sandstone
setblock 993 57 -145 minecraft:smooth_sandstone
setblock 993 55 -150 minecraft:light_blue_terracotta
setblock 993 55 -149 minecraft:light_blue_terracotta
setblock 993 55 -148 minecraft:light_blue_terracotta
setblock 993 56 -150 minecraft:light_blue_terracotta
setblock 993 56 -149 minecraft:light_blue_terracotta
setblock 993 56 -148 minecraft:light_blue_terracotta
setblock 993 54 -152 minecraft:brown_terracotta
setblock 993 54 -146 minecraft:brown_terracotta
setblock 993 57 -152 minecraft:brown_terracotta
setblock 993 57 -146 minecraft:brown_terracotta
setblock 993 54 -151 minecraft:brown_terracotta
setblock 993 57 -147 minecraft:brown_terracotta
setblock 993 55 -153 minecraft:brown_terracotta
setblock 993 56 -145 minecraft:brown_terracotta
setblock 993 57 -153 minecraft:red_terracotta
summon minecraft:text_display 992.47 57.60 -148.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[90f,0f],text:'[{"text": "CAPTAIN MARLOW\'S MAP\\n", "color": "#E6D3A3", "bold": true}, {"text": "eight roads built. the ninth one goes on.", "color": "#B8A888", "italic": true}]',background:1711276032,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]},brightness:{sky:15,block:15}}
setblock 987 54 -154 minecraft:iron_door[facing=south,half=lower]
setblock 987 55 -154 minecraft:iron_door[facing=south,half=upper]
fill 986 54 -155 988 56 -155 minecraft:deepslate_bricks
summon minecraft:text_display 987.50 56.50 -153.47 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "THE NINTH ROAD\\n", "color": "#E6D3A3", "bold": true}, {"text": "beyond this door", "color": "#B8A888", "italic": true}]',background:1711276032,line_width:120,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]},brightness:{sky:15,block:15}}
