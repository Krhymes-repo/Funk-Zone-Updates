# The Wayfarer Expedition: Old Tamsin's fire and the Wilds Discovery Board (Funk Frontier Wayfarers.java runs this once)
fill ~14 ~1 ~21 ~20 ~4 ~27 minecraft:air replace #minecraft:replaceable
setblock ~17 ~1 ~24 minecraft:campfire[lit=true]
setblock ~18 ~0 ~24 minecraft:cobblestone
setblock ~16 ~0 ~24 minecraft:cobblestone
setblock ~17 ~0 ~25 minecraft:cobblestone
setblock ~17 ~0 ~23 minecraft:cobblestone
setblock ~18 ~0 ~25 minecraft:mossy_cobblestone
setblock ~16 ~0 ~23 minecraft:mossy_cobblestone
setblock ~18 ~0 ~23 minecraft:mossy_cobblestone
setblock ~16 ~0 ~25 minecraft:mossy_cobblestone
setblock ~19 ~1 ~23 minecraft:stripped_oak_log[axis=z]
setblock ~19 ~1 ~24 minecraft:stripped_oak_log[axis=z]
setblock ~15 ~1 ~24 minecraft:stripped_oak_log[axis=z]
setblock ~15 ~1 ~25 minecraft:stripped_oak_log[axis=z]
setblock ~14 ~1 ~22 minecraft:barrel[facing=up]
setblock ~14 ~2 ~22 minecraft:lantern[hanging=false]
setblock ~20 ~1 ~26 minecraft:spruce_stairs[facing=west]
fill ~10 ~1 ~39 ~22 ~7 ~43 minecraft:air replace #minecraft:replaceable
fill ~11 ~1 ~41 ~11 ~6 ~41 minecraft:spruce_log
fill ~21 ~1 ~41 ~21 ~6 ~41 minecraft:spruce_log
fill ~12 ~2 ~41 ~20 ~5 ~41 minecraft:spruce_planks
fill ~12 ~1 ~41 ~20 ~1 ~41 minecraft:spruce_trapdoor[facing=north,half=top,open=false]
fill ~11 ~7 ~41 ~21 ~7 ~41 minecraft:spruce_slab[type=bottom]
fill ~11 ~6 ~40 ~21 ~6 ~40 minecraft:spruce_slab[type=top]
fill ~11 ~0 ~40 ~21 ~0 ~39 minecraft:dirt_path
fill ~16 ~0 ~38 ~16 ~0 ~33 minecraft:dirt_path
setblock ~11 ~7 ~41 minecraft:lantern[hanging=false]
setblock ~21 ~7 ~41 minecraft:lantern[hanging=false]
execute positioned ~10 ~0 ~38 run kill @e[type=minecraft:text_display,tag=wf_board,dx=14,dy=10,dz=6]
summon minecraft:text_display ~16.5 ~5.15 ~40.97 {Tags:["funk_label","wf_board","wf_board_head"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "WILDS DISCOVERY BOARD\\n", "color": "#F3E5AB", "bold": true}, {"text": "the first to find each one is named here", "color": "#C8BC98", "italic": true}]',background:1711276032,line_width:300,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.75f,0.75f,0.75f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~20.25 ~4.05 ~40.97 {Tags:["funk_label","wf_board","wf_board_quarry"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~18.75 ~4.05 ~40.97 {Tags:["funk_label","wf_board","wf_board_summit"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~17.25 ~4.05 ~40.97 {Tags:["funk_label","wf_board","wf_board_wreck"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~15.75 ~4.05 ~40.97 {Tags:["funk_label","wf_board","wf_board_lighthouse"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~14.25 ~4.05 ~40.97 {Tags:["funk_label","wf_board","wf_board_oak"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~12.75 ~4.05 ~40.97 {Tags:["funk_label","wf_board","wf_board_relay"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~20.25 ~3.1 ~40.97 {Tags:["funk_label","wf_board","wf_board_greenhouse"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~18.75 ~3.1 ~40.97 {Tags:["funk_label","wf_board","wf_board_fairy"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~17.25 ~3.1 ~40.97 {Tags:["funk_label","wf_board","wf_board_chapel"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~15.75 ~3.1 ~40.97 {Tags:["funk_label","wf_board","wf_board_lantern"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~14.25 ~3.1 ~40.97 {Tags:["funk_label","wf_board","wf_board_observatory"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~12.75 ~3.1 ~40.97 {Tags:["funk_label","wf_board","wf_board_hermit"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~19.5 ~2.15 ~40.97 {Tags:["funk_label","wf_board","wf_board_dragon"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~18 ~2.15 ~40.97 {Tags:["funk_label","wf_board","wf_board_forge"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~16.5 ~2.15 ~40.97 {Tags:["funk_label","wf_board","wf_board_oldroad"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~15 ~2.15 ~40.97 {Tags:["funk_label","wf_board","wf_board_foundations"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display ~13.5 ~2.15 ~40.97 {Tags:["funk_label","wf_board","wf_board_ninth"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
data modify storage funkcity:state wayfarerCommons set value 1
