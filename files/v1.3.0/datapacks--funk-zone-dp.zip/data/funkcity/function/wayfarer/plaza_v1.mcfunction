# The Wayfarer Expedition: Old Tamsin's fire and the Wilds Discovery Board (Funk Frontier Wayfarers.java runs this once)
fill 63 64 -55 69 67 -49 minecraft:air replace #minecraft:replaceable
setblock 66 64 -52 minecraft:campfire[lit=true]
setblock 67 63 -52 minecraft:cobblestone
setblock 65 63 -52 minecraft:cobblestone
setblock 66 63 -51 minecraft:cobblestone
setblock 66 63 -53 minecraft:cobblestone
setblock 67 63 -51 minecraft:mossy_cobblestone
setblock 65 63 -53 minecraft:mossy_cobblestone
setblock 67 63 -53 minecraft:mossy_cobblestone
setblock 65 63 -51 minecraft:mossy_cobblestone
setblock 68 64 -53 minecraft:stripped_oak_log[axis=z]
setblock 68 64 -52 minecraft:stripped_oak_log[axis=z]
setblock 64 64 -52 minecraft:stripped_oak_log[axis=z]
setblock 64 64 -51 minecraft:stripped_oak_log[axis=z]
setblock 63 64 -54 minecraft:barrel[facing=up]
setblock 63 65 -54 minecraft:lantern[hanging=false]
setblock 69 64 -50 minecraft:spruce_stairs[facing=west]
fill 45 64 -48 57 70 -44 minecraft:air replace #minecraft:replaceable
fill 46 64 -46 46 69 -46 minecraft:spruce_log
fill 56 64 -46 56 69 -46 minecraft:spruce_log
fill 47 65 -46 55 68 -46 minecraft:spruce_planks
fill 47 64 -46 55 64 -46 minecraft:spruce_trapdoor[facing=south,half=top,open=false]
fill 46 70 -46 56 70 -46 minecraft:spruce_slab[type=bottom]
fill 46 69 -45 56 69 -45 minecraft:spruce_slab[type=top]
fill 46 63 -45 56 63 -44 minecraft:dirt_path
fill 51 63 -43 51 63 -38 minecraft:dirt_path
setblock 46 70 -46 minecraft:lantern[hanging=false]
setblock 56 70 -46 minecraft:lantern[hanging=false]
execute positioned 45 63 -49 run kill @e[type=minecraft:text_display,tag=wf_board,dx=14,dy=10,dz=6]
summon minecraft:text_display 51.5 68.15 -44.97 {Tags:["funk_label","wf_board","wf_board_head"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "WILDS DISCOVERY BOARD\\n", "color": "#F3E5AB", "bold": true}, {"text": "the first to find each one is named here", "color": "#C8BC98", "italic": true}]',background:1711276032,line_width:300,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.75f,0.75f,0.75f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 47.75 67.05 -44.97 {Tags:["funk_label","wf_board","wf_board_quarry"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 49.25 67.05 -44.97 {Tags:["funk_label","wf_board","wf_board_summit"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 50.75 67.05 -44.97 {Tags:["funk_label","wf_board","wf_board_wreck"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 52.25 67.05 -44.97 {Tags:["funk_label","wf_board","wf_board_lighthouse"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 53.75 67.05 -44.97 {Tags:["funk_label","wf_board","wf_board_oak"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 55.25 67.05 -44.97 {Tags:["funk_label","wf_board","wf_board_relay"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 47.75 66.1 -44.97 {Tags:["funk_label","wf_board","wf_board_greenhouse"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 49.25 66.1 -44.97 {Tags:["funk_label","wf_board","wf_board_fairy"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 50.75 66.1 -44.97 {Tags:["funk_label","wf_board","wf_board_chapel"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 52.25 66.1 -44.97 {Tags:["funk_label","wf_board","wf_board_lantern"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 53.75 66.1 -44.97 {Tags:["funk_label","wf_board","wf_board_observatory"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 55.25 66.1 -44.97 {Tags:["funk_label","wf_board","wf_board_hermit"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 48.5 65.15 -44.97 {Tags:["funk_label","wf_board","wf_board_dragon"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 50 65.15 -44.97 {Tags:["funk_label","wf_board","wf_board_forge"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 51.5 65.15 -44.97 {Tags:["funk_label","wf_board","wf_board_oldroad"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 53 65.15 -44.97 {Tags:["funk_label","wf_board","wf_board_foundations"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 54.5 65.15 -44.97 {Tags:["funk_label","wf_board","wf_board_ninth"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "Undiscovered\\n", "color": "#8C8C8C", "bold": true}, {"text": "?", "color": "#606060"}]',background:1711276032,line_width:100,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{sky:15,block:15}}
data modify storage funkcity:state wayfarerPlaza set value 1
