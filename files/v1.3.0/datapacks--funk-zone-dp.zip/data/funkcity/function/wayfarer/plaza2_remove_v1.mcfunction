# The Wayfarer Expedition: take down an older Tamsin fire + Discovery Board
execute positioned 56 63 -34 run kill @e[type=minecraft:text_display,tag=wf_board,dx=14,dy=10,dz=6]
execute positioned 63 61 -45 run kill @e[tag=fq_wf_tamsin,dx=12,dy=8,dz=12]
execute positioned 63 61 -45 run kill @e[type=minecraft:text_display,tag=funk_lvl,dx=12,dy=8,dz=12]
fill 66 64 -42 72 66 -36 minecraft:air
fill 68 63 -40 70 63 -38 kantoblocks:grass_1
fill 57 64 -32 67 70 -30 minecraft:air
fill 57 63 -33 67 63 -29 kantoblocks:grass_1 replace minecraft:dirt_path
fill 62 63 -39 62 63 -23 kantoblocks:grass_1 replace minecraft:dirt_path
