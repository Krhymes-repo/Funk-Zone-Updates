# The Relay Hut - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=719,y=-64,z=599,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=719,y=-64,z=599,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=719,y=-64,z=599,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=719,y=-64,z=599,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=719,y=-64,z=599,dx=18,dy=384,dz=18]
fill 723 73 603 733 86 613 minecraft:air replace #minecraft:leaves
fill 723 73 603 733 86 613 minecraft:air replace #minecraft:logs
fill 723 73 603 733 86 613 minecraft:air replace #minecraft:replaceable
fill 723 73 603 733 86 613 minecraft:air replace #minecraft:flowers
fill 723 73 603 733 86 613 minecraft:air replace #minecraft:saplings
fill 723 73 603 733 86 613 minecraft:air replace minecraft:cactus
fill 723 73 603 733 86 613 minecraft:air replace minecraft:sugar_cane
fill 723 73 603 733 86 613 minecraft:air replace minecraft:bamboo
fill 723 73 603 733 86 613 minecraft:air replace minecraft:sweet_berry_bush
fill 723 73 603 733 86 613 minecraft:air replace minecraft:vine
fill 723 73 603 733 86 613 minecraft:air replace minecraft:dead_bush
fill 723 73 603 733 86 613 minecraft:air replace minecraft:snow
fill 723 73 603 733 86 613 minecraft:air replace minecraft:moss_carpet
fill 723 73 603 733 86 613 minecraft:air replace minecraft:pink_petals
fill 724 72 604 732 72 612 minecraft:gravel
fill 725 73 605 731 76 611 minecraft:light_gray_concrete
fill 726 73 606 730 75 610 minecraft:air
fill 725 76 605 731 76 611 minecraft:waxed_weathered_cut_copper
fill 725 73 605 731 73 611 minecraft:gray_concrete replace minecraft:light_gray_concrete
setblock 728 73 611 minecraft:iron_door[facing=south,half=lower,open=true]
setblock 728 74 611 minecraft:iron_door[facing=south,half=upper,open=true]
setblock 731 74 608 minecraft:glass_pane
setblock 725 74 608 minecraft:glass_pane
fill 726 73 606 730 73 606 minecraft:spruce_slab[type=top]
setblock 728 73 606 minecraft:jukebox
setblock 727 74 606 minecraft:redstone_lamp[lit=false]
setblock 729 74 606 minecraft:observer[facing=up]
setblock 726 73 609 minecraft:target
setblock 730 73 609 minecraft:barrel[facing=up]
setblock 730 74 606 minecraft:lever[face=wall,facing=south]
setblock 730 77 610 minecraft:iron_bars
setblock 730 78 610 minecraft:iron_bars
setblock 730 79 610 minecraft:iron_bars
setblock 730 80 610 minecraft:lightning_rod
setblock 730 81 610 minecraft:iron_bars
setblock 730 82 610 minecraft:iron_bars
setblock 730 83 610 minecraft:iron_bars
setblock 730 84 610 minecraft:lightning_rod
setblock 730 85 610 minecraft:iron_bars
setblock 730 86 610 minecraft:iron_bars
setblock 730 87 610 minecraft:iron_bars
setblock 730 88 610 minecraft:lightning_rod
summon minecraft:text_display 726.53 74.60 609.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[-90f,0f],text:'[{"text": "RELAY 7\\n", "color": "#9FE7FF", "bold": true}, {"text": "FUNK FM - NO POWER\\n", "color": "#FF9A9A"}, {"text": "terminal needs a redstone signal", "color": "#C8C8C8"}]',background:1711276032,line_width:160,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]},brightness:{sky:15,block:15}}
summon minecraft:text_display 728.50 75.30 611.53 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[0f,0f],text:'[{"text": "FUNK FM RELAY 7", "color": "#9FE7FF", "bold": true}]',background:1711276032,line_width:120,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]},brightness:{sky:15,block:15}}
