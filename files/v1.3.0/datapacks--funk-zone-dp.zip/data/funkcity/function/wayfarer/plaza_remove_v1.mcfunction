# The Wayfarer Expedition: take down an older Tamsin fire + Discovery Board
execute positioned 45 63 -49 run kill @e[type=minecraft:text_display,tag=wf_board,dx=14,dy=10,dz=6]
execute positioned 60 61 -58 run kill @e[tag=fq_wf_tamsin,dx=12,dy=8,dz=12]
execute positioned 60 61 -58 run kill @e[type=minecraft:text_display,tag=funk_lvl,dx=12,dy=8,dz=12]
fill 63 64 -55 69 66 -49 minecraft:air
fill 65 63 -53 67 63 -51 kantoblocks:grass_1
fill 46 64 -47 56 70 -45 minecraft:air
fill 46 63 -48 56 63 -44 kantoblocks:grass_1 replace minecraft:dirt_path
fill 51 63 -54 51 63 -38 kantoblocks:grass_1 replace minecraft:dirt_path
