# The Quarry Saint - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-183,y=-64,z=-1010,dx=17,dy=384,dz=20]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-183,y=-64,z=-1010,dx=17,dy=384,dz=20]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-183,y=-64,z=-1010,dx=17,dy=384,dz=20]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-183,y=-64,z=-1010,dx=17,dy=384,dz=20]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-183,y=-64,z=-1010,dx=17,dy=384,dz=20]
fill -179 61 -995 -179 64 -995 minecraft:smooth_sandstone
fill -179 65 -995 -179 76 -995 minecraft:air
fill -179 61 -996 -179 64 -996 minecraft:smooth_sandstone
fill -179 65 -996 -179 76 -996 minecraft:air
fill -179 61 -997 -179 64 -997 minecraft:sandstone
fill -179 65 -997 -179 76 -997 minecraft:air
fill -179 61 -998 -179 64 -998 minecraft:smooth_sandstone
fill -179 65 -998 -179 76 -998 minecraft:air
fill -179 61 -999 -179 64 -999 minecraft:smooth_sandstone
fill -179 65 -999 -179 76 -999 minecraft:air
fill -179 61 -1000 -179 64 -1000 minecraft:sandstone
fill -179 65 -1000 -179 76 -1000 minecraft:air
fill -179 61 -1001 -179 64 -1001 minecraft:smooth_sandstone
fill -179 65 -1001 -179 76 -1001 minecraft:air
fill -179 61 -1002 -179 64 -1002 minecraft:smooth_sandstone
fill -179 65 -1002 -179 76 -1002 minecraft:air
fill -179 61 -1003 -179 64 -1003 minecraft:sandstone
fill -179 65 -1003 -179 76 -1003 minecraft:air
fill -179 61 -1004 -179 64 -1004 minecraft:smooth_sandstone
fill -179 65 -1004 -179 76 -1004 minecraft:air
fill -179 61 -1005 -179 64 -1005 minecraft:smooth_sandstone
fill -179 65 -1005 -179 76 -1005 minecraft:air
fill -178 61 -995 -178 64 -995 minecraft:smooth_sandstone
fill -178 65 -995 -178 76 -995 minecraft:air
fill -178 61 -996 -178 64 -996 minecraft:sandstone
fill -178 65 -996 -178 76 -996 minecraft:air
fill -178 61 -997 -178 64 -997 minecraft:smooth_sandstone
fill -178 65 -997 -178 76 -997 minecraft:air
fill -178 61 -998 -178 64 -998 minecraft:smooth_sandstone
fill -178 65 -998 -178 76 -998 minecraft:air
fill -178 61 -999 -178 64 -999 minecraft:sandstone
fill -178 65 -999 -178 76 -999 minecraft:air
fill -178 61 -1000 -178 64 -1000 minecraft:smooth_sandstone
fill -178 65 -1000 -178 76 -1000 minecraft:air
fill -178 61 -1001 -178 64 -1001 minecraft:smooth_sandstone
fill -178 65 -1001 -178 76 -1001 minecraft:air
fill -178 61 -1002 -178 64 -1002 minecraft:sandstone
fill -178 65 -1002 -178 76 -1002 minecraft:air
fill -178 61 -1003 -178 64 -1003 minecraft:smooth_sandstone
fill -178 65 -1003 -178 76 -1003 minecraft:air
fill -178 61 -1004 -178 64 -1004 minecraft:smooth_sandstone
fill -178 65 -1004 -178 76 -1004 minecraft:air
fill -178 61 -1005 -178 64 -1005 minecraft:sandstone
fill -178 65 -1005 -178 76 -1005 minecraft:air
fill -177 61 -995 -177 64 -995 minecraft:sandstone
fill -177 65 -995 -177 76 -995 minecraft:air
fill -177 61 -996 -177 64 -996 minecraft:smooth_sandstone
fill -177 65 -996 -177 76 -996 minecraft:air
fill -177 61 -997 -177 64 -997 minecraft:smooth_sandstone
fill -177 65 -997 -177 76 -997 minecraft:air
fill -177 61 -998 -177 64 -998 minecraft:sandstone
fill -177 65 -998 -177 76 -998 minecraft:air
fill -177 61 -999 -177 64 -999 minecraft:smooth_sandstone
fill -177 65 -999 -177 76 -999 minecraft:air
fill -177 61 -1000 -177 64 -1000 minecraft:smooth_sandstone
fill -177 65 -1000 -177 76 -1000 minecraft:air
fill -177 61 -1001 -177 64 -1001 minecraft:sandstone
fill -177 65 -1001 -177 76 -1001 minecraft:air
fill -177 61 -1002 -177 64 -1002 minecraft:smooth_sandstone
fill -177 65 -1002 -177 76 -1002 minecraft:air
fill -177 61 -1003 -177 64 -1003 minecraft:smooth_sandstone
fill -177 65 -1003 -177 76 -1003 minecraft:air
fill -177 61 -1004 -177 64 -1004 minecraft:sandstone
fill -177 65 -1004 -177 76 -1004 minecraft:air
fill -177 61 -1005 -177 64 -1005 minecraft:smooth_sandstone
fill -177 65 -1005 -177 76 -1005 minecraft:air
fill -176 61 -995 -176 64 -995 minecraft:smooth_sandstone
fill -176 65 -995 -176 76 -995 minecraft:air
fill -176 61 -996 -176 64 -996 minecraft:smooth_sandstone
fill -176 65 -996 -176 76 -996 minecraft:air
fill -176 61 -997 -176 64 -997 minecraft:sandstone
fill -176 65 -997 -176 76 -997 minecraft:air
fill -176 61 -998 -176 64 -998 minecraft:smooth_sandstone
fill -176 65 -998 -176 76 -998 minecraft:air
fill -176 61 -999 -176 64 -999 minecraft:smooth_sandstone
fill -176 65 -999 -176 76 -999 minecraft:air
fill -176 61 -1000 -176 64 -1000 minecraft:sandstone
fill -176 65 -1000 -176 76 -1000 minecraft:air
fill -176 61 -1001 -176 64 -1001 minecraft:smooth_sandstone
fill -176 65 -1001 -176 76 -1001 minecraft:air
fill -176 61 -1002 -176 64 -1002 minecraft:smooth_sandstone
fill -176 65 -1002 -176 76 -1002 minecraft:air
fill -176 61 -1003 -176 64 -1003 minecraft:sandstone
fill -176 65 -1003 -176 76 -1003 minecraft:air
fill -176 61 -1004 -176 64 -1004 minecraft:smooth_sandstone
fill -176 65 -1004 -176 76 -1004 minecraft:air
fill -176 61 -1005 -176 64 -1005 minecraft:smooth_sandstone
fill -176 65 -1005 -176 76 -1005 minecraft:air
fill -175 61 -995 -175 64 -995 minecraft:smooth_sandstone
fill -175 65 -995 -175 76 -995 minecraft:air
fill -175 61 -996 -175 64 -996 minecraft:sandstone
fill -175 65 -996 -175 76 -996 minecraft:air
fill -175 61 -997 -175 64 -997 minecraft:smooth_sandstone
fill -175 65 -997 -175 76 -997 minecraft:air
fill -175 61 -998 -175 64 -998 minecraft:smooth_sandstone
fill -175 65 -998 -175 76 -998 minecraft:air
fill -175 61 -999 -175 64 -999 minecraft:sandstone
fill -175 65 -999 -175 76 -999 minecraft:air
fill -175 61 -1000 -175 64 -1000 minecraft:smooth_sandstone
fill -175 65 -1000 -175 76 -1000 minecraft:air
fill -175 61 -1001 -175 64 -1001 minecraft:smooth_sandstone
fill -175 65 -1001 -175 76 -1001 minecraft:air
fill -175 61 -1002 -175 64 -1002 minecraft:sandstone
fill -175 65 -1002 -175 76 -1002 minecraft:air
fill -175 61 -1003 -175 64 -1003 minecraft:smooth_sandstone
fill -175 65 -1003 -175 76 -1003 minecraft:air
fill -175 61 -1004 -175 64 -1004 minecraft:smooth_sandstone
fill -175 65 -1004 -175 76 -1004 minecraft:air
fill -175 61 -1005 -175 64 -1005 minecraft:sandstone
fill -175 65 -1005 -175 76 -1005 minecraft:air
fill -174 61 -995 -174 64 -995 minecraft:sandstone
fill -174 65 -995 -174 76 -995 minecraft:air
fill -174 61 -996 -174 64 -996 minecraft:smooth_sandstone
fill -174 65 -996 -174 76 -996 minecraft:air
fill -174 61 -997 -174 64 -997 minecraft:smooth_sandstone
fill -174 65 -997 -174 76 -997 minecraft:air
fill -174 61 -998 -174 64 -998 minecraft:sandstone
fill -174 65 -998 -174 76 -998 minecraft:air
fill -174 61 -999 -174 64 -999 minecraft:smooth_sandstone
fill -174 65 -999 -174 76 -999 minecraft:air
fill -174 61 -1000 -174 64 -1000 minecraft:smooth_sandstone
fill -174 65 -1000 -174 76 -1000 minecraft:air
fill -174 61 -1001 -174 64 -1001 minecraft:sandstone
fill -174 65 -1001 -174 76 -1001 minecraft:air
fill -174 61 -1002 -174 64 -1002 minecraft:smooth_sandstone
fill -174 65 -1002 -174 76 -1002 minecraft:air
fill -174 61 -1003 -174 64 -1003 minecraft:smooth_sandstone
fill -174 65 -1003 -174 76 -1003 minecraft:air
fill -174 61 -1004 -174 64 -1004 minecraft:sandstone
fill -174 65 -1004 -174 76 -1004 minecraft:air
fill -174 61 -1005 -174 64 -1005 minecraft:smooth_sandstone
fill -174 65 -1005 -174 76 -1005 minecraft:air
fill -173 61 -995 -173 64 -995 minecraft:smooth_sandstone
fill -173 65 -995 -173 76 -995 minecraft:air
fill -173 61 -996 -173 64 -996 minecraft:smooth_sandstone
fill -173 65 -996 -173 76 -996 minecraft:air
fill -173 61 -997 -173 64 -997 minecraft:sandstone
fill -173 65 -997 -173 76 -997 minecraft:air
fill -173 61 -998 -173 64 -998 minecraft:smooth_sandstone
fill -173 65 -998 -173 76 -998 minecraft:air
fill -173 61 -999 -173 64 -999 minecraft:smooth_sandstone
fill -173 65 -999 -173 76 -999 minecraft:air
fill -173 61 -1000 -173 64 -1000 minecraft:sandstone
fill -173 65 -1000 -173 76 -1000 minecraft:air
fill -173 61 -1001 -173 64 -1001 minecraft:smooth_sandstone
fill -173 65 -1001 -173 76 -1001 minecraft:air
fill -173 61 -1002 -173 64 -1002 minecraft:smooth_sandstone
fill -173 65 -1002 -173 76 -1002 minecraft:air
fill -173 61 -1003 -173 64 -1003 minecraft:sandstone
fill -173 65 -1003 -173 76 -1003 minecraft:air
fill -173 61 -1004 -173 64 -1004 minecraft:smooth_sandstone
fill -173 65 -1004 -173 76 -1004 minecraft:air
fill -173 61 -1005 -173 64 -1005 minecraft:smooth_sandstone
fill -173 65 -1005 -173 76 -1005 minecraft:air
fill -172 62 -994 -172 74 -994 minecraft:stone
fill -172 62 -995 -172 74 -995 minecraft:stone
fill -172 62 -996 -172 74 -996 minecraft:andesite
fill -172 62 -997 -172 74 -997 minecraft:stone
fill -172 62 -998 -172 74 -998 minecraft:stone
fill -172 62 -999 -172 74 -999 minecraft:stone
fill -172 62 -1000 -172 74 -1000 minecraft:andesite
fill -172 62 -1001 -172 74 -1001 minecraft:stone
fill -172 62 -1002 -172 74 -1002 minecraft:stone
fill -172 62 -1003 -172 74 -1003 minecraft:stone
fill -172 62 -1004 -172 74 -1004 minecraft:andesite
fill -172 62 -1005 -172 74 -1005 minecraft:stone
fill -172 62 -1006 -172 74 -1006 minecraft:stone
fill -171 62 -994 -171 74 -994 minecraft:stone
fill -171 62 -995 -171 74 -995 minecraft:andesite
fill -171 62 -996 -171 74 -996 minecraft:stone
fill -171 62 -997 -171 74 -997 minecraft:stone
fill -171 62 -998 -171 74 -998 minecraft:stone
fill -171 62 -999 -171 74 -999 minecraft:andesite
fill -171 62 -1000 -171 74 -1000 minecraft:stone
fill -171 62 -1001 -171 74 -1001 minecraft:stone
fill -171 62 -1002 -171 74 -1002 minecraft:stone
fill -171 62 -1003 -171 74 -1003 minecraft:andesite
fill -171 62 -1004 -171 74 -1004 minecraft:stone
fill -171 62 -1005 -171 74 -1005 minecraft:stone
fill -171 62 -1006 -171 74 -1006 minecraft:stone
fill -170 62 -994 -170 74 -994 minecraft:andesite
fill -170 62 -995 -170 74 -995 minecraft:stone
fill -170 62 -996 -170 74 -996 minecraft:stone
fill -170 62 -997 -170 74 -997 minecraft:stone
fill -170 62 -998 -170 74 -998 minecraft:andesite
fill -170 62 -999 -170 74 -999 minecraft:stone
fill -170 62 -1000 -170 74 -1000 minecraft:stone
fill -170 62 -1001 -170 74 -1001 minecraft:stone
fill -170 62 -1002 -170 74 -1002 minecraft:andesite
fill -170 62 -1003 -170 74 -1003 minecraft:stone
fill -170 62 -1004 -170 74 -1004 minecraft:stone
fill -170 62 -1005 -170 74 -1005 minecraft:stone
fill -170 62 -1006 -170 74 -1006 minecraft:andesite
fill -179 65 -994 -179 67 -994 minecraft:stone
fill -178 65 -994 -178 67 -994 minecraft:cobblestone
fill -177 65 -994 -177 69 -994 minecraft:stone
fill -176 65 -994 -176 73 -994 minecraft:cobblestone
fill -175 65 -994 -175 73 -994 minecraft:stone
fill -174 65 -994 -174 73 -994 minecraft:cobblestone
fill -173 65 -994 -173 73 -994 minecraft:stone
fill -179 65 -1006 -179 67 -1006 minecraft:stone
fill -178 65 -1006 -178 67 -1006 minecraft:cobblestone
fill -177 65 -1006 -177 68 -1006 minecraft:stone
fill -176 65 -1006 -176 68 -1006 minecraft:cobblestone
fill -175 65 -1006 -175 69 -1006 minecraft:stone
fill -174 65 -1006 -174 69 -1006 minecraft:cobblestone
fill -173 65 -1006 -173 70 -1006 minecraft:stone
setblock -173 74 -999 minecraft:polished_andesite
setblock -173 74 -1000 minecraft:polished_andesite
setblock -173 74 -1001 minecraft:polished_andesite
setblock -173 73 -998 minecraft:polished_andesite
setblock -173 73 -999 minecraft:polished_andesite
setblock -173 73 -1000 minecraft:polished_andesite
setblock -173 73 -1001 minecraft:polished_andesite
setblock -173 73 -1002 minecraft:polished_andesite
setblock -173 72 -997 minecraft:polished_andesite
setblock -173 72 -998 minecraft:polished_andesite
setblock -173 72 -999 minecraft:polished_andesite
setblock -173 72 -1000 minecraft:polished_andesite
setblock -173 72 -1001 minecraft:polished_andesite
setblock -173 72 -1002 minecraft:polished_andesite
setblock -173 72 -1003 minecraft:polished_andesite
setblock -173 71 -997 minecraft:polished_andesite
setblock -173 71 -998 minecraft:air
setblock -172 71 -998 minecraft:black_concrete
setblock -173 71 -1000 minecraft:polished_andesite
setblock -173 71 -1002 minecraft:air
setblock -172 71 -1002 minecraft:black_concrete
setblock -173 71 -1003 minecraft:polished_andesite
setblock -173 70 -997 minecraft:polished_andesite
setblock -173 70 -998 minecraft:polished_andesite
setblock -173 70 -999 minecraft:polished_andesite
setblock -173 70 -1000 minecraft:polished_andesite
setblock -173 70 -1001 minecraft:polished_andesite
setblock -173 70 -1002 minecraft:polished_andesite
setblock -173 70 -1003 minecraft:polished_andesite
setblock -173 69 -997 minecraft:polished_andesite
setblock -173 69 -998 minecraft:polished_andesite
setblock -173 69 -999 minecraft:polished_andesite
setblock -173 69 -1000 minecraft:chiseled_stone_bricks
setblock -173 69 -1001 minecraft:polished_andesite
setblock -173 69 -1002 minecraft:polished_andesite
setblock -173 69 -1003 minecraft:polished_andesite
setblock -173 68 -998 minecraft:polished_andesite
setblock -173 68 -999 minecraft:polished_andesite
setblock -173 68 -1000 minecraft:polished_andesite
setblock -173 68 -1001 minecraft:polished_andesite
setblock -173 68 -1002 minecraft:polished_andesite
setblock -173 67 -998 minecraft:polished_andesite
setblock -173 67 -999 minecraft:air
setblock -172 67 -999 minecraft:stone
setblock -173 67 -1000 minecraft:air
setblock -172 67 -1000 minecraft:stone
setblock -173 67 -1001 minecraft:air
setblock -172 67 -1001 minecraft:stone
setblock -173 67 -1002 minecraft:polished_andesite
setblock -173 66 -999 minecraft:polished_andesite
setblock -173 66 -1000 minecraft:polished_andesite
setblock -173 66 -1001 minecraft:polished_andesite
setblock -173 75 -998 minecraft:mossy_cobblestone
setblock -173 75 -999 minecraft:mossy_cobblestone
setblock -173 75 -1000 minecraft:mossy_cobblestone
setblock -173 75 -1001 minecraft:mossy_cobblestone
setblock -173 75 -1002 minecraft:mossy_cobblestone
fill -175 65 -1001 -175 65 -999 minecraft:polished_andesite
setblock -175 66 -999 minecraft:candle[candles=2,lit=true]
setblock -175 66 -1001 minecraft:candle[candles=3,lit=true]
setblock -175 66 -1000 minecraft:chest[facing=west]
setblock -177 65 -998 minecraft:potted_dandelion
setblock -177 65 -1002 minecraft:potted_poppy
setblock -178 65 -1004 minecraft:stone_bricks
setblock -178 66 -1004 minecraft:cracked_stone_bricks
setblock -177 65 -1004 minecraft:stone_brick_stairs[facing=east]
summon minecraft:text_display -173.02 66.25 -999.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[90f,0f],text:'[{"text": "SAINT OF THE QUARRY\\n", "color": "#D9C9A3", "bold": true}, {"text": "keeper of cut stone\\nleave a light, take a stone", "color": "#BBB09A"}]',background:1711276032,line_width:120,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]},brightness:{sky:15,block:15}}
