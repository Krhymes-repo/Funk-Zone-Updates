# The Hermit of the Hollow - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-279,y=-64,z=821,dx=22,dy=384,dz=22]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-279,y=-64,z=821,dx=22,dy=384,dz=22]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-279,y=-64,z=821,dx=22,dy=384,dz=22]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-279,y=-64,z=821,dx=22,dy=384,dz=22]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-279,y=-64,z=821,dx=22,dy=384,dz=22]
fill -275 90 825 -261 106 839 minecraft:air replace #minecraft:leaves
fill -275 90 825 -261 106 839 minecraft:air replace #minecraft:logs
fill -275 90 825 -261 106 839 minecraft:air replace #minecraft:replaceable
fill -275 90 825 -261 106 839 minecraft:air replace #minecraft:flowers
fill -275 90 825 -261 106 839 minecraft:air replace #minecraft:saplings
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:cactus
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:sugar_cane
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:bamboo
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:sweet_berry_bush
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:vine
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:dead_bush
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:snow
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:moss_carpet
fill -275 90 825 -261 106 839 minecraft:air replace minecraft:pink_petals
fill -274 90 826 -274 95 826 minecraft:air
fill -274 90 827 -274 95 827 minecraft:air
fill -274 90 828 -274 94 828 minecraft:air
fill -274 90 829 -274 94 829 minecraft:air
fill -274 90 830 -274 93 830 minecraft:air
fill -274 90 835 -274 90 835 minecraft:air
fill -274 90 836 -274 91 836 minecraft:air
fill -274 90 837 -274 91 837 minecraft:air
fill -274 90 838 -274 92 838 minecraft:air
fill -273 90 826 -273 93 826 minecraft:air
fill -273 90 827 -273 93 827 minecraft:air
fill -273 90 828 -273 92 828 minecraft:air
fill -273 90 829 -273 92 829 minecraft:air
fill -273 90 830 -273 91 830 minecraft:air
fill -273 90 831 -273 91 831 minecraft:air
fill -273 90 835 -273 90 835 minecraft:air
fill -273 90 836 -273 90 836 minecraft:air
fill -273 90 837 -273 90 837 minecraft:air
fill -273 90 838 -273 90 838 minecraft:air
fill -272 90 826 -272 92 826 minecraft:air
fill -272 90 827 -272 91 827 minecraft:air
fill -272 90 828 -272 91 828 minecraft:air
fill -272 90 829 -272 91 829 minecraft:air
fill -272 90 830 -272 90 830 minecraft:air
fill -272 90 831 -272 90 831 minecraft:air
fill -272 90 838 -272 90 838 minecraft:air
fill -271 90 826 -271 91 826 minecraft:air
fill -271 90 827 -271 91 827 minecraft:air
fill -271 90 828 -271 91 828 minecraft:air
fill -271 90 829 -271 91 829 minecraft:air
fill -271 90 830 -271 90 830 minecraft:air
fill -271 90 831 -271 90 831 minecraft:air
fill -271 90 837 -271 90 837 minecraft:air
fill -271 90 838 -271 90 838 minecraft:air
fill -270 90 826 -270 91 826 minecraft:air
fill -270 90 827 -270 91 827 minecraft:air
fill -270 90 828 -270 91 828 minecraft:air
fill -270 90 829 -270 90 829 minecraft:air
fill -270 90 830 -270 90 830 minecraft:air
fill -270 90 831 -270 90 831 minecraft:air
fill -270 90 837 -270 90 837 minecraft:air
fill -270 90 838 -270 91 838 minecraft:air
fill -269 90 826 -269 91 826 minecraft:air
fill -269 90 827 -269 90 827 minecraft:air
fill -269 90 828 -269 90 828 minecraft:air
fill -269 90 829 -269 90 829 minecraft:air
fill -269 90 830 -269 90 830 minecraft:air
fill -269 90 835 -269 90 835 minecraft:air
fill -269 90 836 -269 90 836 minecraft:air
fill -269 90 837 -269 90 837 minecraft:air
fill -269 90 838 -269 91 838 minecraft:air
fill -268 90 826 -268 90 826 minecraft:air
fill -268 90 827 -268 90 827 minecraft:air
fill -268 90 828 -268 90 828 minecraft:air
fill -268 90 829 -268 90 829 minecraft:air
fill -268 90 834 -268 90 834 minecraft:air
fill -268 90 835 -268 90 835 minecraft:air
fill -268 90 836 -268 90 836 minecraft:air
fill -268 90 837 -268 91 837 minecraft:air
fill -268 90 838 -268 91 838 minecraft:air
fill -267 90 826 -267 91 826 minecraft:air
fill -267 90 827 -267 90 827 minecraft:air
fill -267 90 828 -267 90 828 minecraft:air
fill -267 90 829 -267 90 829 minecraft:air
fill -267 90 830 -267 90 830 minecraft:air
fill -267 90 834 -267 90 834 minecraft:air
fill -267 90 835 -267 90 835 minecraft:air
fill -267 90 836 -267 90 836 minecraft:air
fill -267 90 837 -267 91 837 minecraft:air
fill -267 90 838 -267 91 838 minecraft:air
fill -266 90 826 -266 91 826 minecraft:air
fill -266 90 827 -266 91 827 minecraft:air
fill -266 90 828 -266 90 828 minecraft:air
fill -266 90 829 -266 90 829 minecraft:air
fill -266 90 830 -266 90 830 minecraft:air
fill -266 90 831 -266 90 831 minecraft:air
fill -266 90 833 -266 90 833 minecraft:air
fill -266 90 834 -266 91 834 minecraft:air
fill -266 90 835 -266 90 835 minecraft:air
fill -266 90 836 -266 90 836 minecraft:air
fill -266 90 837 -266 91 837 minecraft:air
fill -266 90 838 -266 91 838 minecraft:air
fill -265 90 826 -265 91 826 minecraft:air
fill -265 90 827 -265 91 827 minecraft:air
fill -265 90 828 -265 91 828 minecraft:air
fill -265 90 829 -265 90 829 minecraft:air
fill -265 90 830 -265 90 830 minecraft:air
fill -265 90 831 -265 90 831 minecraft:air
fill -265 90 832 -265 90 832 minecraft:air
fill -265 90 833 -265 90 833 minecraft:air
fill -265 90 834 -265 90 834 minecraft:air
fill -265 90 835 -265 90 835 minecraft:air
fill -265 90 836 -265 91 836 minecraft:air
fill -265 90 837 -265 91 837 minecraft:air
fill -265 90 838 -265 91 838 minecraft:air
fill -264 90 826 -264 91 826 minecraft:air
fill -264 90 827 -264 91 827 minecraft:air
fill -264 90 828 -264 91 828 minecraft:air
fill -264 90 829 -264 91 829 minecraft:air
fill -264 90 830 -264 90 830 minecraft:air
fill -264 90 831 -264 90 831 minecraft:air
fill -264 90 832 -264 90 832 minecraft:air
fill -264 90 833 -264 90 833 minecraft:air
fill -264 90 834 -264 90 834 minecraft:air
fill -264 90 835 -264 91 835 minecraft:air
fill -264 90 836 -264 91 836 minecraft:air
fill -264 90 837 -264 91 837 minecraft:air
fill -264 90 838 -264 92 838 minecraft:air
fill -263 90 826 -263 92 826 minecraft:air
fill -263 90 827 -263 92 827 minecraft:air
fill -263 90 828 -263 91 828 minecraft:air
fill -263 90 829 -263 91 829 minecraft:air
fill -263 90 830 -263 91 830 minecraft:air
fill -263 90 831 -263 91 831 minecraft:air
fill -263 90 832 -263 90 832 minecraft:air
fill -263 90 833 -263 91 833 minecraft:air
fill -263 90 834 -263 91 834 minecraft:air
fill -263 90 835 -263 91 835 minecraft:air
fill -263 90 836 -263 91 836 minecraft:air
fill -263 90 837 -263 92 837 minecraft:air
fill -263 90 838 -263 92 838 minecraft:air
fill -262 90 826 -262 92 826 minecraft:air
fill -262 90 827 -262 92 827 minecraft:air
fill -262 90 828 -262 92 828 minecraft:air
fill -262 90 829 -262 92 829 minecraft:air
fill -262 90 830 -262 91 830 minecraft:air
fill -262 90 831 -262 91 831 minecraft:air
fill -262 90 832 -262 91 832 minecraft:air
fill -262 90 833 -262 91 833 minecraft:air
fill -262 90 834 -262 91 834 minecraft:air
fill -262 90 835 -262 92 835 minecraft:air
fill -262 90 836 -262 92 836 minecraft:air
fill -262 90 837 -262 92 837 minecraft:air
fill -262 90 838 -262 93 838 minecraft:air
fill -274 89 826 -262 89 838 minecraft:grass_block
fill -271 89 829 -265 89 835 minecraft:spruce_planks
setblock -271 90 829 minecraft:spruce_log
setblock -271 91 829 minecraft:spruce_log
setblock -271 92 829 minecraft:spruce_log
setblock -271 90 830 minecraft:mossy_cobblestone
setblock -271 91 830 minecraft:stripped_spruce_wood
setblock -271 92 830 minecraft:stripped_spruce_wood
setblock -271 90 831 minecraft:mossy_cobblestone
setblock -271 91 831 minecraft:stripped_spruce_wood
setblock -271 92 831 minecraft:stripped_spruce_wood
setblock -271 90 832 minecraft:mossy_cobblestone
setblock -271 91 832 minecraft:stripped_spruce_wood
setblock -271 92 832 minecraft:stripped_spruce_wood
setblock -271 90 833 minecraft:mossy_cobblestone
setblock -271 91 833 minecraft:stripped_spruce_wood
setblock -271 92 833 minecraft:stripped_spruce_wood
setblock -271 90 834 minecraft:mossy_cobblestone
setblock -271 91 834 minecraft:stripped_spruce_wood
setblock -271 92 834 minecraft:stripped_spruce_wood
setblock -271 90 835 minecraft:spruce_log
setblock -271 91 835 minecraft:spruce_log
setblock -271 92 835 minecraft:spruce_log
setblock -270 90 829 minecraft:mossy_cobblestone
setblock -270 91 829 minecraft:stripped_spruce_wood
setblock -270 92 829 minecraft:stripped_spruce_wood
setblock -270 90 835 minecraft:mossy_cobblestone
setblock -270 91 835 minecraft:stripped_spruce_wood
setblock -270 92 835 minecraft:stripped_spruce_wood
setblock -269 90 829 minecraft:mossy_cobblestone
setblock -269 91 829 minecraft:stripped_spruce_wood
setblock -269 92 829 minecraft:stripped_spruce_wood
setblock -269 90 835 minecraft:mossy_cobblestone
setblock -269 91 835 minecraft:stripped_spruce_wood
setblock -269 92 835 minecraft:stripped_spruce_wood
setblock -268 90 829 minecraft:mossy_cobblestone
setblock -268 91 829 minecraft:stripped_spruce_wood
setblock -268 92 829 minecraft:stripped_spruce_wood
setblock -268 90 835 minecraft:mossy_cobblestone
setblock -268 91 835 minecraft:stripped_spruce_wood
setblock -268 92 835 minecraft:stripped_spruce_wood
setblock -267 90 829 minecraft:mossy_cobblestone
setblock -267 91 829 minecraft:stripped_spruce_wood
setblock -267 92 829 minecraft:stripped_spruce_wood
setblock -267 90 835 minecraft:mossy_cobblestone
setblock -267 91 835 minecraft:stripped_spruce_wood
setblock -267 92 835 minecraft:stripped_spruce_wood
setblock -266 90 829 minecraft:mossy_cobblestone
setblock -266 91 829 minecraft:stripped_spruce_wood
setblock -266 92 829 minecraft:stripped_spruce_wood
setblock -266 90 835 minecraft:mossy_cobblestone
setblock -266 91 835 minecraft:stripped_spruce_wood
setblock -266 92 835 minecraft:stripped_spruce_wood
setblock -265 90 829 minecraft:spruce_log
setblock -265 91 829 minecraft:spruce_log
setblock -265 92 829 minecraft:spruce_log
setblock -265 90 830 minecraft:mossy_cobblestone
setblock -265 91 830 minecraft:stripped_spruce_wood
setblock -265 92 830 minecraft:stripped_spruce_wood
setblock -265 90 831 minecraft:mossy_cobblestone
setblock -265 91 831 minecraft:stripped_spruce_wood
setblock -265 92 831 minecraft:stripped_spruce_wood
setblock -265 90 832 minecraft:mossy_cobblestone
setblock -265 91 832 minecraft:stripped_spruce_wood
setblock -265 92 832 minecraft:stripped_spruce_wood
setblock -265 90 833 minecraft:mossy_cobblestone
setblock -265 91 833 minecraft:stripped_spruce_wood
setblock -265 92 833 minecraft:stripped_spruce_wood
setblock -265 90 834 minecraft:mossy_cobblestone
setblock -265 91 834 minecraft:stripped_spruce_wood
setblock -265 92 834 minecraft:stripped_spruce_wood
setblock -265 90 835 minecraft:spruce_log
setblock -265 91 835 minecraft:spruce_log
setblock -265 92 835 minecraft:spruce_log
setblock -272 93 828 minecraft:spruce_slab[type=bottom]
setblock -272 94 829 minecraft:spruce_slab[type=bottom]
setblock -272 94 830 minecraft:spruce_slab[type=bottom]
setblock -272 95 831 minecraft:spruce_slab[type=bottom]
setblock -272 95 832 minecraft:dark_oak_planks
setblock -272 95 833 minecraft:spruce_slab[type=bottom]
setblock -272 94 834 minecraft:spruce_slab[type=bottom]
setblock -272 94 835 minecraft:spruce_slab[type=bottom]
setblock -272 93 836 minecraft:spruce_slab[type=bottom]
setblock -271 93 828 minecraft:spruce_slab[type=bottom]
setblock -271 94 829 minecraft:spruce_slab[type=bottom]
setblock -271 94 830 minecraft:spruce_slab[type=bottom]
setblock -271 95 831 minecraft:spruce_slab[type=bottom]
setblock -271 95 832 minecraft:dark_oak_planks
setblock -271 95 833 minecraft:spruce_slab[type=bottom]
setblock -271 94 834 minecraft:spruce_slab[type=bottom]
setblock -271 94 835 minecraft:spruce_slab[type=bottom]
setblock -271 93 836 minecraft:spruce_slab[type=bottom]
setblock -270 93 828 minecraft:spruce_slab[type=bottom]
setblock -270 94 829 minecraft:spruce_slab[type=bottom]
setblock -270 94 830 minecraft:spruce_slab[type=bottom]
setblock -270 95 831 minecraft:spruce_slab[type=bottom]
setblock -270 95 832 minecraft:dark_oak_planks
setblock -270 95 833 minecraft:spruce_slab[type=bottom]
setblock -270 94 834 minecraft:spruce_slab[type=bottom]
setblock -270 94 835 minecraft:spruce_slab[type=bottom]
setblock -270 93 836 minecraft:spruce_slab[type=bottom]
setblock -269 93 828 minecraft:spruce_slab[type=bottom]
setblock -269 94 829 minecraft:spruce_slab[type=bottom]
setblock -269 94 830 minecraft:spruce_slab[type=bottom]
setblock -269 95 831 minecraft:spruce_slab[type=bottom]
setblock -269 95 832 minecraft:dark_oak_planks
setblock -269 95 833 minecraft:spruce_slab[type=bottom]
setblock -269 94 834 minecraft:spruce_slab[type=bottom]
setblock -269 94 835 minecraft:spruce_slab[type=bottom]
setblock -269 93 836 minecraft:spruce_slab[type=bottom]
setblock -268 93 828 minecraft:spruce_slab[type=bottom]
setblock -268 94 829 minecraft:spruce_slab[type=bottom]
setblock -268 94 830 minecraft:spruce_slab[type=bottom]
setblock -268 95 831 minecraft:spruce_slab[type=bottom]
setblock -268 95 832 minecraft:dark_oak_planks
setblock -268 95 833 minecraft:spruce_slab[type=bottom]
setblock -268 94 834 minecraft:spruce_slab[type=bottom]
setblock -268 94 835 minecraft:spruce_slab[type=bottom]
setblock -268 93 836 minecraft:spruce_slab[type=bottom]
setblock -267 93 828 minecraft:spruce_slab[type=bottom]
setblock -267 94 829 minecraft:spruce_slab[type=bottom]
setblock -267 94 830 minecraft:spruce_slab[type=bottom]
setblock -267 95 831 minecraft:spruce_slab[type=bottom]
setblock -267 95 832 minecraft:dark_oak_planks
setblock -267 95 833 minecraft:spruce_slab[type=bottom]
setblock -267 94 834 minecraft:spruce_slab[type=bottom]
setblock -267 94 835 minecraft:spruce_slab[type=bottom]
setblock -267 93 836 minecraft:spruce_slab[type=bottom]
setblock -266 93 828 minecraft:spruce_slab[type=bottom]
setblock -266 94 829 minecraft:spruce_slab[type=bottom]
setblock -266 94 830 minecraft:spruce_slab[type=bottom]
setblock -266 95 831 minecraft:spruce_slab[type=bottom]
setblock -266 95 832 minecraft:dark_oak_planks
setblock -266 95 833 minecraft:spruce_slab[type=bottom]
setblock -266 94 834 minecraft:spruce_slab[type=bottom]
setblock -266 94 835 minecraft:spruce_slab[type=bottom]
setblock -266 93 836 minecraft:spruce_slab[type=bottom]
setblock -265 93 828 minecraft:spruce_slab[type=bottom]
setblock -265 94 829 minecraft:spruce_slab[type=bottom]
setblock -265 94 830 minecraft:spruce_slab[type=bottom]
setblock -265 95 831 minecraft:spruce_slab[type=bottom]
setblock -265 95 832 minecraft:dark_oak_planks
setblock -265 95 833 minecraft:spruce_slab[type=bottom]
setblock -265 94 834 minecraft:spruce_slab[type=bottom]
setblock -265 94 835 minecraft:spruce_slab[type=bottom]
setblock -265 93 836 minecraft:spruce_slab[type=bottom]
setblock -264 93 828 minecraft:spruce_slab[type=bottom]
setblock -264 94 829 minecraft:spruce_slab[type=bottom]
setblock -264 94 830 minecraft:spruce_slab[type=bottom]
setblock -264 95 831 minecraft:spruce_slab[type=bottom]
setblock -264 95 832 minecraft:dark_oak_planks
setblock -264 95 833 minecraft:spruce_slab[type=bottom]
setblock -264 94 834 minecraft:spruce_slab[type=bottom]
setblock -264 94 835 minecraft:spruce_slab[type=bottom]
setblock -264 93 836 minecraft:spruce_slab[type=bottom]
fill -271 93 829 -265 93 835 minecraft:spruce_planks
fill -265 90 829 -265 96 829 minecraft:cobblestone
setblock -265 97 829 minecraft:campfire[lit=true,signal_fire=false]
setblock -268 90 835 minecraft:spruce_door[facing=south,half=lower]
setblock -268 91 835 minecraft:spruce_door[facing=south,half=upper]
setblock -271 91 832 minecraft:glass_pane
setblock -265 91 832 minecraft:glass_pane
setblock -270 90 830 minecraft:red_bed[facing=north,part=head]
setblock -270 90 831 minecraft:red_bed[facing=north,part=foot]
setblock -266 90 830 minecraft:smoker[facing=south,lit=true]
setblock -266 90 831 minecraft:barrel[facing=up]
setblock -270 90 834 minecraft:bookshelf
setblock -270 91 834 minecraft:bookshelf
setblock -267 90 833 minecraft:spruce_fence
setblock -267 91 833 minecraft:spruce_pressure_plate
setblock -268 92 832 minecraft:lantern[hanging=true]
setblock -271 89 836 minecraft:spruce_planks
setblock -270 89 836 minecraft:spruce_planks
setblock -269 89 836 minecraft:spruce_planks
setblock -268 89 836 minecraft:spruce_planks
setblock -267 89 836 minecraft:spruce_planks
setblock -266 89 836 minecraft:spruce_planks
setblock -265 89 836 minecraft:spruce_planks
setblock -270 90 836 minecraft:spruce_stairs[facing=east]
setblock -274 89 831 minecraft:farmland[moisture=7]
setblock -274 90 831 minecraft:carrots[age=7]
setblock -274 89 832 minecraft:farmland[moisture=7]
setblock -274 90 832 minecraft:potatoes[age=7]
setblock -274 89 833 minecraft:farmland[moisture=7]
setblock -274 90 833 minecraft:carrots[age=7]
setblock -273 89 831 minecraft:farmland[moisture=7]
setblock -273 90 831 minecraft:carrots[age=7]
setblock -273 89 832 minecraft:farmland[moisture=7]
setblock -273 90 832 minecraft:potatoes[age=7]
setblock -273 89 833 minecraft:farmland[moisture=7]
setblock -273 90 833 minecraft:carrots[age=7]
setblock -272 89 831 minecraft:farmland[moisture=7]
setblock -272 90 831 minecraft:carrots[age=7]
setblock -272 89 832 minecraft:farmland[moisture=7]
setblock -272 90 832 minecraft:potatoes[age=7]
setblock -272 89 833 minecraft:farmland[moisture=7]
setblock -272 90 833 minecraft:carrots[age=7]
setblock -274 89 832 minecraft:water
