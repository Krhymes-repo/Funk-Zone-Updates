# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-429,y=-64,z=-681,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-429,y=-64,z=-681,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-429,y=-64,z=-681,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-429,y=-64,z=-681,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-429,y=-64,z=-681,dx=18,dy=384,dz=18]
fill -424 65 -676 -416 78 -668 minecraft:air replace #minecraft:leaves
fill -424 65 -676 -416 78 -668 minecraft:air replace #minecraft:logs
fill -424 65 -676 -416 78 -668 minecraft:air replace #minecraft:replaceable
fill -424 65 -676 -416 78 -668 minecraft:air replace #minecraft:flowers
fill -424 65 -676 -416 78 -668 minecraft:air replace #minecraft:saplings
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:cactus
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:sugar_cane
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:bamboo
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:sweet_berry_bush
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:vine
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:dead_bush
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:snow
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:moss_carpet
fill -424 65 -676 -416 78 -668 minecraft:air replace minecraft:pink_petals
fill -423 64 -675 -417 64 -669 minecraft:red_sand
fill -425 65 -677 -415 86 -667 minecraft:air replace #minecraft:leaves
fill -425 65 -677 -415 86 -667 minecraft:air replace #minecraft:logs
fill -425 65 -677 -415 86 -667 minecraft:air replace #minecraft:replaceable
fill -425 65 -677 -415 86 -667 minecraft:air replace #minecraft:flowers
fill -425 65 -677 -415 86 -667 minecraft:air replace #minecraft:saplings
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:cactus
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:sugar_cane
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:bamboo
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:sweet_berry_bush
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:vine
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:dead_bush
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:snow
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:moss_carpet
fill -425 65 -677 -415 86 -667 minecraft:air replace minecraft:pink_petals
setblock -420 65 -672 minecraft:campfire[lit=false]
setblock -418 65 -672 minecraft:mossy_cobblestone_slab
setblock -422 65 -672 minecraft:mossy_cobblestone_slab
setblock -420 65 -670 minecraft:mossy_cobblestone_slab
setblock -420 65 -674 minecraft:mossy_cobblestone_slab
setblock -423 65 -673 minecraft:brown_carpet
setblock -423 65 -672 minecraft:brown_carpet
setblock -423 65 -671 minecraft:white_carpet
setblock -417 65 -673 minecraft:spruce_fence
setblock -417 66 -673 minecraft:lantern[hanging=false]
setblock -419 65 -674 minecraft:chest[facing=south]
setblock -418 65 -674 minecraft:barrel[facing=up]
setblock -417 65 -671 minecraft:spruce_fence
setblock -417 66 -671 minecraft:bell[attachment=floor,facing=east]
setblock -422 65 -669 minecraft:spruce_fence
setblock -422 66 -669 minecraft:spruce_fence
setblock -422 67 -669 minecraft:light_gray_banner[rotation=0]
