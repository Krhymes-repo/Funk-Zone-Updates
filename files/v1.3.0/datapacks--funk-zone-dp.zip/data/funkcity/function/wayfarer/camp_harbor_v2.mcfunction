# Wayfarer camp - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=351,y=-64,z=-721,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=351,y=-64,z=-721,dx=18,dy=384,dz=18]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=351,y=-64,z=-721,dx=18,dy=384,dz=18]
kill @e[type=minecraft:minecart,tag=wf_prop,x=351,y=-64,z=-721,dx=18,dy=384,dz=18]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=351,y=-64,z=-721,dx=18,dy=384,dz=18]
fill 356 71 -716 364 84 -708 minecraft:air replace #minecraft:leaves
fill 356 71 -716 364 84 -708 minecraft:air replace #minecraft:logs
fill 356 71 -716 364 84 -708 minecraft:air replace #minecraft:replaceable
fill 356 71 -716 364 84 -708 minecraft:air replace #minecraft:flowers
fill 356 71 -716 364 84 -708 minecraft:air replace #minecraft:saplings
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:cactus
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:sugar_cane
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:bamboo
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:sweet_berry_bush
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:vine
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:dead_bush
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:snow
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:moss_carpet
fill 356 71 -716 364 84 -708 minecraft:air replace minecraft:pink_petals
fill 357 70 -715 363 70 -709 minecraft:grass_block
fill 355 71 -717 365 92 -707 minecraft:air replace #minecraft:leaves
fill 355 71 -717 365 92 -707 minecraft:air replace #minecraft:logs
fill 355 71 -717 365 92 -707 minecraft:air replace #minecraft:replaceable
fill 355 71 -717 365 92 -707 minecraft:air replace #minecraft:flowers
fill 355 71 -717 365 92 -707 minecraft:air replace #minecraft:saplings
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:cactus
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:sugar_cane
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:bamboo
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:sweet_berry_bush
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:vine
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:dead_bush
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:snow
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:moss_carpet
fill 355 71 -717 365 92 -707 minecraft:air replace minecraft:pink_petals
setblock 360 71 -712 minecraft:campfire[lit=false]
setblock 362 71 -712 minecraft:mossy_cobblestone_slab
setblock 358 71 -712 minecraft:mossy_cobblestone_slab
setblock 360 71 -710 minecraft:mossy_cobblestone_slab
setblock 360 71 -714 minecraft:mossy_cobblestone_slab
setblock 357 71 -713 minecraft:brown_carpet
setblock 357 71 -712 minecraft:brown_carpet
setblock 357 71 -711 minecraft:white_carpet
setblock 363 71 -713 minecraft:spruce_fence
setblock 363 72 -713 minecraft:lantern[hanging=false]
setblock 361 71 -714 minecraft:chest[facing=south]
setblock 362 71 -714 minecraft:barrel[facing=up]
summon minecraft:item_frame 362 72 -714 {Facing:1b,Invisible:1b,Fixed:1b,Invulnerable:1b,Tags:["wf_prop"],Item:{id:"minecraft:fishing_rod",count:1}}
setblock 358 71 -709 minecraft:spruce_fence
setblock 358 72 -709 minecraft:spruce_fence
setblock 358 73 -709 minecraft:light_gray_banner[rotation=0]
