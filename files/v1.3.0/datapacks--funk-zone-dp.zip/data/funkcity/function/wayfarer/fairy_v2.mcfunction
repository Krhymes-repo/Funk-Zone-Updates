# The Fairy Ring - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=222,y=-64,z=886,dx=20,dy=384,dz=20]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=222,y=-64,z=886,dx=20,dy=384,dz=20]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=222,y=-64,z=886,dx=20,dy=384,dz=20]
kill @e[type=minecraft:minecart,tag=wf_prop,x=222,y=-64,z=886,dx=20,dy=384,dz=20]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=222,y=-64,z=886,dx=20,dy=384,dz=20]
fill 226 75 890 238 92 902 minecraft:air replace #minecraft:leaves
fill 226 75 890 238 92 902 minecraft:air replace #minecraft:logs
fill 226 75 890 238 92 902 minecraft:air replace #minecraft:replaceable
fill 226 75 890 238 92 902 minecraft:air replace #minecraft:flowers
fill 226 75 890 238 92 902 minecraft:air replace #minecraft:saplings
fill 226 75 890 238 92 902 minecraft:air replace minecraft:cactus
fill 226 75 890 238 92 902 minecraft:air replace minecraft:sugar_cane
fill 226 75 890 238 92 902 minecraft:air replace minecraft:bamboo
fill 226 75 890 238 92 902 minecraft:air replace minecraft:sweet_berry_bush
fill 226 75 890 238 92 902 minecraft:air replace minecraft:vine
fill 226 75 890 238 92 902 minecraft:air replace minecraft:dead_bush
fill 226 75 890 238 92 902 minecraft:air replace minecraft:snow
fill 226 75 890 238 92 902 minecraft:air replace minecraft:moss_carpet
fill 226 75 890 238 92 902 minecraft:air replace minecraft:pink_petals
fill 227 74 891 237 74 901 minecraft:grass_block
setblock 236 74 896 minecraft:podzol
setblock 236 75 896 minecraft:brown_mushroom
setblock 236 74 897 minecraft:mycelium
setblock 236 75 897 minecraft:red_mushroom
setblock 235 74 898 minecraft:podzol
setblock 235 75 898 minecraft:red_mushroom
setblock 234 74 899 minecraft:mycelium
setblock 234 75 899 minecraft:brown_mushroom
setblock 233 74 900 minecraft:podzol
setblock 233 75 900 minecraft:red_mushroom
setblock 232 74 900 minecraft:mycelium
setblock 232 75 900 minecraft:red_mushroom
setblock 231 74 900 minecraft:podzol
setblock 231 75 900 minecraft:brown_mushroom
setblock 230 74 899 minecraft:mycelium
setblock 230 75 899 minecraft:red_mushroom
setblock 229 74 898 minecraft:podzol
setblock 229 75 898 minecraft:red_mushroom
setblock 228 74 897 minecraft:mycelium
setblock 228 75 897 minecraft:brown_mushroom
setblock 228 74 896 minecraft:podzol
setblock 228 75 896 minecraft:red_mushroom
setblock 228 74 895 minecraft:mycelium
setblock 228 75 895 minecraft:red_mushroom
setblock 229 74 894 minecraft:podzol
setblock 229 75 894 minecraft:brown_mushroom
setblock 230 74 893 minecraft:mycelium
setblock 230 75 893 minecraft:red_mushroom
setblock 231 74 892 minecraft:podzol
setblock 231 75 892 minecraft:red_mushroom
setblock 232 74 892 minecraft:mycelium
setblock 232 75 892 minecraft:brown_mushroom
setblock 233 74 892 minecraft:podzol
setblock 233 75 892 minecraft:red_mushroom
setblock 234 74 893 minecraft:mycelium
setblock 234 75 893 minecraft:red_mushroom
setblock 235 74 894 minecraft:podzol
setblock 235 75 894 minecraft:brown_mushroom
setblock 236 74 895 minecraft:mycelium
setblock 236 75 895 minecraft:red_mushroom
setblock 231 75 895 minecraft:air
setblock 231 75 896 minecraft:pink_petals[flower_amount=4,facing=north]
setblock 231 75 897 minecraft:air
setblock 232 75 895 minecraft:pink_petals[flower_amount=4,facing=north]
setblock 232 75 896 minecraft:air
setblock 232 75 897 minecraft:pink_petals[flower_amount=4,facing=north]
setblock 233 75 895 minecraft:air
setblock 233 75 896 minecraft:pink_petals[flower_amount=4,facing=north]
setblock 233 75 897 minecraft:air
setblock 232 75 896 minecraft:moss_carpet
