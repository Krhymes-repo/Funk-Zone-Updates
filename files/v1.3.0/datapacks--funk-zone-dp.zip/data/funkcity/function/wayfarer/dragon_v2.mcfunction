# Dragon's Rest - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-1074,y=-64,z=-128,dx=57,dy=384,dz=24]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-1074,y=-64,z=-128,dx=57,dy=384,dz=24]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-1074,y=-64,z=-128,dx=57,dy=384,dz=24]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-1074,y=-64,z=-128,dx=57,dy=384,dz=24]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-1074,y=-64,z=-128,dx=57,dy=384,dz=24]
fill -1060 50 -124 -1024 101 -108 minecraft:air replace #minecraft:leaves
fill -1060 102 -124 -1024 140 -108 minecraft:air replace #minecraft:leaves
fill -1060 50 -124 -1024 101 -108 minecraft:air replace #minecraft:logs
fill -1060 102 -124 -1024 140 -108 minecraft:air replace #minecraft:logs
fill -1060 50 -124 -1024 101 -108 minecraft:air replace #minecraft:replaceable
fill -1060 102 -124 -1024 140 -108 minecraft:air replace #minecraft:replaceable
fill -1060 50 -124 -1024 101 -108 minecraft:air replace #minecraft:flowers
fill -1060 102 -124 -1024 140 -108 minecraft:air replace #minecraft:flowers
fill -1060 50 -124 -1024 101 -108 minecraft:air replace #minecraft:saplings
fill -1060 102 -124 -1024 140 -108 minecraft:air replace #minecraft:saplings
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:cactus
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:cactus
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:sugar_cane
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:sugar_cane
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:bamboo
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:bamboo
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:sweet_berry_bush
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:sweet_berry_bush
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:vine
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:vine
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:dead_bush
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:dead_bush
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:snow
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:snow
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:moss_carpet
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:moss_carpet
fill -1060 50 -124 -1024 101 -108 minecraft:air replace minecraft:pink_petals
fill -1060 102 -124 -1024 140 -108 minecraft:air replace minecraft:pink_petals
setblock -1060 69 -116 minecraft:bone_block
setblock -1059 69 -116 minecraft:bone_block
setblock -1058 69 -116 minecraft:bone_block
setblock -1057 69 -116 minecraft:bone_block
setblock -1056 69 -116 minecraft:bone_block
setblock -1055 69 -116 minecraft:bone_block
setblock -1054 69 -116 minecraft:bone_block
setblock -1053 68 -116 minecraft:bone_block
setblock -1052 68 -116 minecraft:bone_block
setblock -1051 69 -116 minecraft:bone_block
setblock -1050 69 -116 minecraft:bone_block
setblock -1049 69 -116 minecraft:bone_block
setblock -1048 74 -116 minecraft:bone_block
setblock -1048 75 -116 minecraft:bone_block[axis=y]
setblock -1047 74 -116 minecraft:bone_block
setblock -1046 74 -116 minecraft:bone_block
setblock -1046 75 -116 minecraft:bone_block[axis=y]
setblock -1045 74 -116 minecraft:bone_block
setblock -1044 74 -116 minecraft:bone_block
setblock -1044 75 -116 minecraft:bone_block[axis=y]
setblock -1043 74 -116 minecraft:bone_block
setblock -1042 74 -116 minecraft:bone_block
setblock -1042 75 -116 minecraft:bone_block[axis=y]
setblock -1041 74 -116 minecraft:bone_block
setblock -1040 74 -116 minecraft:bone_block
setblock -1040 75 -116 minecraft:bone_block[axis=y]
setblock -1039 74 -116 minecraft:bone_block
setblock -1038 75 -116 minecraft:bone_block
setblock -1038 76 -116 minecraft:bone_block[axis=y]
setblock -1037 75 -116 minecraft:bone_block
setblock -1036 75 -116 minecraft:bone_block
setblock -1036 76 -116 minecraft:bone_block[axis=y]
setblock -1035 71 -116 minecraft:bone_block
setblock -1034 72 -116 minecraft:bone_block
setblock -1033 72 -116 minecraft:bone_block
setblock -1032 73 -116 minecraft:bone_block
setblock -1031 73 -116 minecraft:bone_block
setblock -1030 73 -116 minecraft:bone_block
setblock -1029 74 -116 minecraft:bone_block
setblock -1028 74 -116 minecraft:bone_block
setblock -1027 74 -116 minecraft:bone_block
setblock -1048 70 -112 minecraft:bone_block
fill -1048 65 -112 -1048 70 -112 minecraft:bone_block
setblock -1048 72 -113 minecraft:bone_block
setblock -1048 73 -114 minecraft:bone_block
setblock -1048 74 -115 minecraft:bone_block
setblock -1048 74 -116 minecraft:bone_block
setblock -1048 74 -117 minecraft:bone_block
setblock -1048 73 -118 minecraft:bone_block
setblock -1048 72 -119 minecraft:bone_block
setblock -1048 70 -120 minecraft:bone_block
fill -1048 67 -120 -1048 70 -120 minecraft:bone_block
setblock -1046 70 -112 minecraft:bone_block
fill -1046 64 -112 -1046 70 -112 minecraft:bone_block
setblock -1046 72 -113 minecraft:bone_block
setblock -1046 73 -114 minecraft:bone_block
setblock -1046 74 -115 minecraft:bone_block
setblock -1046 74 -116 minecraft:bone_block
setblock -1046 74 -117 minecraft:bone_block
setblock -1046 73 -118 minecraft:bone_block
setblock -1046 72 -119 minecraft:bone_block
setblock -1046 70 -120 minecraft:bone_block
fill -1046 66 -120 -1046 70 -120 minecraft:bone_block
setblock -1044 70 -112 minecraft:bone_block
fill -1044 64 -112 -1044 70 -112 minecraft:bone_block
setblock -1044 72 -113 minecraft:bone_block
setblock -1044 73 -114 minecraft:bone_block
setblock -1044 74 -115 minecraft:bone_block
setblock -1044 74 -116 minecraft:bone_block
setblock -1044 74 -117 minecraft:bone_block
setblock -1044 73 -118 minecraft:bone_block
setblock -1044 72 -119 minecraft:bone_block
setblock -1044 70 -120 minecraft:bone_block
fill -1044 66 -120 -1044 70 -120 minecraft:bone_block
setblock -1042 70 -112 minecraft:bone_block
fill -1042 65 -112 -1042 70 -112 minecraft:bone_block
setblock -1042 72 -113 minecraft:bone_block
setblock -1042 73 -114 minecraft:bone_block
setblock -1042 74 -115 minecraft:bone_block
setblock -1042 74 -116 minecraft:bone_block
setblock -1042 74 -117 minecraft:bone_block
setblock -1042 73 -118 minecraft:bone_block
setblock -1042 72 -119 minecraft:bone_block
setblock -1042 70 -120 minecraft:bone_block
fill -1042 66 -120 -1042 70 -120 minecraft:bone_block
setblock -1040 70 -112 minecraft:bone_block
fill -1040 65 -112 -1040 70 -112 minecraft:bone_block
setblock -1040 72 -113 minecraft:bone_block
setblock -1040 73 -114 minecraft:bone_block
setblock -1040 74 -115 minecraft:bone_block
setblock -1040 74 -116 minecraft:bone_block
setblock -1040 74 -117 minecraft:bone_block
setblock -1040 73 -118 minecraft:bone_block
setblock -1040 72 -119 minecraft:bone_block
setblock -1040 70 -120 minecraft:bone_block
fill -1040 65 -120 -1040 70 -120 minecraft:bone_block
setblock -1038 71 -112 minecraft:bone_block
fill -1038 66 -112 -1038 71 -112 minecraft:bone_block
setblock -1038 73 -113 minecraft:bone_block
setblock -1038 74 -114 minecraft:bone_block
setblock -1038 75 -115 minecraft:bone_block
setblock -1038 75 -116 minecraft:bone_block
setblock -1038 75 -117 minecraft:bone_block
setblock -1038 74 -118 minecraft:bone_block
setblock -1038 73 -119 minecraft:bone_block
setblock -1038 71 -120 minecraft:bone_block
fill -1038 65 -120 -1038 71 -120 minecraft:bone_block
setblock -1036 71 -112 minecraft:bone_block
fill -1036 68 -112 -1036 71 -112 minecraft:bone_block
setblock -1036 73 -113 minecraft:bone_block
setblock -1036 74 -114 minecraft:bone_block
setblock -1036 75 -115 minecraft:bone_block
setblock -1036 75 -116 minecraft:bone_block
setblock -1036 75 -117 minecraft:bone_block
setblock -1036 74 -118 minecraft:bone_block
setblock -1036 73 -119 minecraft:bone_block
setblock -1036 71 -120 minecraft:bone_block
fill -1036 65 -120 -1036 71 -120 minecraft:bone_block
fill -1048 68 -113 -1048 71 -113 minecraft:air
setblock -1048 67 -113 minecraft:red_sand
fill -1048 68 -114 -1048 71 -114 minecraft:air
setblock -1048 67 -114 minecraft:red_sand
fill -1048 68 -115 -1048 72 -115 minecraft:air
setblock -1048 67 -115 minecraft:coarse_dirt
fill -1048 68 -116 -1048 72 -116 minecraft:air
setblock -1048 67 -116 minecraft:red_sand
fill -1048 68 -117 -1048 72 -117 minecraft:air
setblock -1048 67 -117 minecraft:red_sand
fill -1048 68 -118 -1048 71 -118 minecraft:air
setblock -1048 67 -118 minecraft:coarse_dirt
fill -1048 68 -119 -1048 71 -119 minecraft:air
setblock -1048 67 -119 minecraft:red_sand
fill -1047 68 -113 -1047 71 -113 minecraft:air
setblock -1047 67 -113 minecraft:red_sand
fill -1047 68 -114 -1047 71 -114 minecraft:air
setblock -1047 67 -114 minecraft:coarse_dirt
fill -1047 68 -115 -1047 72 -115 minecraft:air
setblock -1047 67 -115 minecraft:red_sand
fill -1047 68 -116 -1047 72 -116 minecraft:air
setblock -1047 67 -116 minecraft:red_sand
fill -1047 68 -117 -1047 72 -117 minecraft:air
setblock -1047 67 -117 minecraft:coarse_dirt
fill -1047 68 -118 -1047 71 -118 minecraft:air
setblock -1047 67 -118 minecraft:red_sand
fill -1047 68 -119 -1047 71 -119 minecraft:air
setblock -1047 67 -119 minecraft:red_sand
fill -1046 68 -113 -1046 71 -113 minecraft:air
setblock -1046 67 -113 minecraft:coarse_dirt
fill -1046 68 -114 -1046 71 -114 minecraft:air
setblock -1046 67 -114 minecraft:red_sand
fill -1046 68 -115 -1046 72 -115 minecraft:air
setblock -1046 67 -115 minecraft:red_sand
fill -1046 68 -116 -1046 72 -116 minecraft:air
setblock -1046 67 -116 minecraft:coarse_dirt
fill -1046 68 -117 -1046 72 -117 minecraft:air
setblock -1046 67 -117 minecraft:red_sand
fill -1046 68 -118 -1046 71 -118 minecraft:air
setblock -1046 67 -118 minecraft:red_sand
fill -1046 68 -119 -1046 71 -119 minecraft:air
setblock -1046 67 -119 minecraft:coarse_dirt
fill -1045 68 -113 -1045 71 -113 minecraft:air
setblock -1045 67 -113 minecraft:red_sand
fill -1045 68 -114 -1045 71 -114 minecraft:air
setblock -1045 67 -114 minecraft:red_sand
fill -1045 68 -115 -1045 72 -115 minecraft:air
setblock -1045 67 -115 minecraft:coarse_dirt
fill -1045 68 -116 -1045 72 -116 minecraft:air
setblock -1045 67 -116 minecraft:red_sand
fill -1045 68 -117 -1045 72 -117 minecraft:air
setblock -1045 67 -117 minecraft:red_sand
fill -1045 68 -118 -1045 71 -118 minecraft:air
setblock -1045 67 -118 minecraft:coarse_dirt
fill -1045 68 -119 -1045 71 -119 minecraft:air
setblock -1045 67 -119 minecraft:red_sand
fill -1044 68 -113 -1044 71 -113 minecraft:air
setblock -1044 67 -113 minecraft:red_sand
fill -1044 68 -114 -1044 71 -114 minecraft:air
setblock -1044 67 -114 minecraft:coarse_dirt
fill -1044 68 -115 -1044 72 -115 minecraft:air
setblock -1044 67 -115 minecraft:red_sand
fill -1044 68 -116 -1044 72 -116 minecraft:air
setblock -1044 67 -116 minecraft:red_sand
fill -1044 68 -117 -1044 72 -117 minecraft:air
setblock -1044 67 -117 minecraft:coarse_dirt
fill -1044 68 -118 -1044 71 -118 minecraft:air
setblock -1044 67 -118 minecraft:red_sand
fill -1044 68 -119 -1044 71 -119 minecraft:air
setblock -1044 67 -119 minecraft:red_sand
fill -1043 68 -113 -1043 71 -113 minecraft:air
setblock -1043 67 -113 minecraft:coarse_dirt
fill -1043 68 -114 -1043 71 -114 minecraft:air
setblock -1043 67 -114 minecraft:red_sand
fill -1043 68 -115 -1043 72 -115 minecraft:air
setblock -1043 67 -115 minecraft:red_sand
fill -1043 68 -116 -1043 72 -116 minecraft:air
setblock -1043 67 -116 minecraft:coarse_dirt
fill -1043 68 -117 -1043 72 -117 minecraft:air
setblock -1043 67 -117 minecraft:red_sand
fill -1043 68 -118 -1043 71 -118 minecraft:air
setblock -1043 67 -118 minecraft:red_sand
fill -1043 68 -119 -1043 71 -119 minecraft:air
setblock -1043 67 -119 minecraft:coarse_dirt
fill -1042 68 -113 -1042 71 -113 minecraft:air
setblock -1042 67 -113 minecraft:red_sand
fill -1042 68 -114 -1042 71 -114 minecraft:air
setblock -1042 67 -114 minecraft:red_sand
fill -1042 68 -115 -1042 72 -115 minecraft:air
setblock -1042 67 -115 minecraft:coarse_dirt
fill -1042 68 -116 -1042 72 -116 minecraft:air
setblock -1042 67 -116 minecraft:red_sand
fill -1042 68 -117 -1042 72 -117 minecraft:air
setblock -1042 67 -117 minecraft:red_sand
fill -1042 68 -118 -1042 71 -118 minecraft:air
setblock -1042 67 -118 minecraft:coarse_dirt
fill -1042 68 -119 -1042 71 -119 minecraft:air
setblock -1042 67 -119 minecraft:red_sand
fill -1041 68 -113 -1041 71 -113 minecraft:air
setblock -1041 67 -113 minecraft:red_sand
fill -1041 68 -114 -1041 71 -114 minecraft:air
setblock -1041 67 -114 minecraft:coarse_dirt
fill -1041 68 -115 -1041 72 -115 minecraft:air
setblock -1041 67 -115 minecraft:red_sand
fill -1041 68 -116 -1041 72 -116 minecraft:air
setblock -1041 67 -116 minecraft:red_sand
fill -1041 68 -117 -1041 72 -117 minecraft:air
setblock -1041 67 -117 minecraft:coarse_dirt
fill -1041 68 -118 -1041 71 -118 minecraft:air
setblock -1041 67 -118 minecraft:red_sand
fill -1041 68 -119 -1041 71 -119 minecraft:air
setblock -1041 67 -119 minecraft:red_sand
fill -1040 68 -113 -1040 71 -113 minecraft:air
setblock -1040 67 -113 minecraft:coarse_dirt
fill -1040 68 -114 -1040 71 -114 minecraft:air
setblock -1040 67 -114 minecraft:red_sand
fill -1040 68 -115 -1040 72 -115 minecraft:air
setblock -1040 67 -115 minecraft:red_sand
fill -1040 68 -116 -1040 72 -116 minecraft:air
setblock -1040 67 -116 minecraft:coarse_dirt
fill -1040 68 -117 -1040 72 -117 minecraft:air
setblock -1040 67 -117 minecraft:red_sand
fill -1040 68 -118 -1040 71 -118 minecraft:air
setblock -1040 67 -118 minecraft:red_sand
fill -1040 68 -119 -1040 71 -119 minecraft:air
setblock -1040 67 -119 minecraft:coarse_dirt
fill -1039 68 -113 -1039 71 -113 minecraft:air
setblock -1039 67 -113 minecraft:red_sand
fill -1039 68 -114 -1039 71 -114 minecraft:air
setblock -1039 67 -114 minecraft:red_sand
fill -1039 68 -115 -1039 72 -115 minecraft:air
setblock -1039 67 -115 minecraft:coarse_dirt
fill -1039 68 -116 -1039 72 -116 minecraft:air
setblock -1039 67 -116 minecraft:red_sand
fill -1039 68 -117 -1039 72 -117 minecraft:air
setblock -1039 67 -117 minecraft:red_sand
fill -1039 68 -118 -1039 71 -118 minecraft:air
setblock -1039 67 -118 minecraft:coarse_dirt
fill -1039 68 -119 -1039 71 -119 minecraft:air
setblock -1039 67 -119 minecraft:red_sand
fill -1038 69 -113 -1038 72 -113 minecraft:air
setblock -1038 68 -113 minecraft:red_sand
fill -1038 69 -114 -1038 72 -114 minecraft:air
setblock -1038 68 -114 minecraft:coarse_dirt
fill -1038 69 -115 -1038 73 -115 minecraft:air
setblock -1038 68 -115 minecraft:red_sand
fill -1038 69 -116 -1038 73 -116 minecraft:air
setblock -1038 68 -116 minecraft:red_sand
fill -1038 69 -117 -1038 73 -117 minecraft:air
setblock -1038 68 -117 minecraft:coarse_dirt
fill -1038 69 -118 -1038 72 -118 minecraft:air
setblock -1038 68 -118 minecraft:red_sand
fill -1038 69 -119 -1038 72 -119 minecraft:air
setblock -1038 68 -119 minecraft:red_sand
fill -1037 69 -113 -1037 72 -113 minecraft:air
setblock -1037 68 -113 minecraft:coarse_dirt
fill -1037 69 -114 -1037 72 -114 minecraft:air
setblock -1037 68 -114 minecraft:red_sand
fill -1037 69 -115 -1037 73 -115 minecraft:air
setblock -1037 68 -115 minecraft:red_sand
fill -1037 69 -116 -1037 73 -116 minecraft:air
setblock -1037 68 -116 minecraft:coarse_dirt
fill -1037 69 -117 -1037 73 -117 minecraft:air
setblock -1037 68 -117 minecraft:red_sand
fill -1037 69 -118 -1037 72 -118 minecraft:air
setblock -1037 68 -118 minecraft:red_sand
fill -1037 69 -119 -1037 72 -119 minecraft:air
setblock -1037 68 -119 minecraft:coarse_dirt
fill -1036 69 -113 -1036 72 -113 minecraft:air
setblock -1036 68 -113 minecraft:red_sand
fill -1036 69 -114 -1036 72 -114 minecraft:air
setblock -1036 68 -114 minecraft:red_sand
fill -1036 69 -115 -1036 73 -115 minecraft:air
setblock -1036 68 -115 minecraft:coarse_dirt
fill -1036 69 -116 -1036 73 -116 minecraft:air
setblock -1036 68 -116 minecraft:red_sand
fill -1036 69 -117 -1036 73 -117 minecraft:air
setblock -1036 68 -117 minecraft:red_sand
fill -1036 69 -118 -1036 72 -118 minecraft:air
setblock -1036 68 -118 minecraft:coarse_dirt
fill -1036 69 -119 -1036 72 -119 minecraft:air
setblock -1036 68 -119 minecraft:red_sand
setblock -1042 68 -116 minecraft:chest[facing=west]
setblock -1042 68 -117 minecraft:skeleton_skull[rotation=0]
setblock -1042 68 -114 minecraft:soul_lantern
setblock -1026 72 -113 minecraft:bone_block
setblock -1026 73 -113 minecraft:bone_block
setblock -1026 74 -113 minecraft:bone_block
setblock -1026 75 -113 minecraft:bone_block
setblock -1026 76 -113 minecraft:bone_block
setblock -1026 72 -114 minecraft:bone_block
setblock -1026 73 -114 minecraft:air
setblock -1026 74 -114 minecraft:air
setblock -1026 75 -114 minecraft:air
setblock -1026 76 -114 minecraft:bone_block
setblock -1026 72 -115 minecraft:bone_block
setblock -1026 73 -115 minecraft:air
setblock -1026 74 -115 minecraft:air
setblock -1026 75 -115 minecraft:air
setblock -1026 76 -115 minecraft:bone_block
setblock -1026 72 -116 minecraft:bone_block
setblock -1026 73 -116 minecraft:air
setblock -1026 74 -116 minecraft:air
setblock -1026 75 -116 minecraft:air
setblock -1026 76 -116 minecraft:bone_block
setblock -1026 72 -117 minecraft:bone_block
setblock -1026 73 -117 minecraft:air
setblock -1026 74 -117 minecraft:air
setblock -1026 75 -117 minecraft:air
setblock -1026 76 -117 minecraft:bone_block
setblock -1026 72 -118 minecraft:bone_block
setblock -1026 73 -118 minecraft:air
setblock -1026 74 -118 minecraft:air
setblock -1026 75 -118 minecraft:air
setblock -1026 76 -118 minecraft:bone_block
setblock -1026 72 -119 minecraft:bone_block
setblock -1026 73 -119 minecraft:bone_block
setblock -1026 74 -119 minecraft:bone_block
setblock -1026 75 -119 minecraft:bone_block
setblock -1026 76 -119 minecraft:bone_block
setblock -1025 72 -113 minecraft:bone_block
setblock -1025 73 -113 minecraft:bone_block
setblock -1025 74 -113 minecraft:bone_block
setblock -1025 75 -113 minecraft:bone_block
setblock -1025 76 -113 minecraft:bone_block
setblock -1025 72 -114 minecraft:bone_block
setblock -1025 73 -114 minecraft:air
setblock -1025 74 -114 minecraft:air
setblock -1025 75 -114 minecraft:air
setblock -1025 76 -114 minecraft:bone_block
setblock -1025 72 -115 minecraft:bone_block
setblock -1025 73 -115 minecraft:air
setblock -1025 74 -115 minecraft:air
setblock -1025 75 -115 minecraft:air
setblock -1025 76 -115 minecraft:bone_block
setblock -1025 72 -116 minecraft:bone_block
setblock -1025 73 -116 minecraft:air
setblock -1025 74 -116 minecraft:air
setblock -1025 75 -116 minecraft:air
setblock -1025 76 -116 minecraft:bone_block
setblock -1025 72 -117 minecraft:bone_block
setblock -1025 73 -117 minecraft:air
setblock -1025 74 -117 minecraft:air
setblock -1025 75 -117 minecraft:air
setblock -1025 76 -117 minecraft:bone_block
setblock -1025 72 -118 minecraft:bone_block
setblock -1025 73 -118 minecraft:air
setblock -1025 74 -118 minecraft:air
setblock -1025 75 -118 minecraft:air
setblock -1025 76 -118 minecraft:bone_block
setblock -1025 72 -119 minecraft:bone_block
setblock -1025 73 -119 minecraft:bone_block
setblock -1025 74 -119 minecraft:bone_block
setblock -1025 75 -119 minecraft:bone_block
setblock -1025 76 -119 minecraft:bone_block
setblock -1024 72 -113 minecraft:bone_block
setblock -1024 73 -113 minecraft:bone_block
setblock -1024 74 -113 minecraft:black_concrete
setblock -1024 75 -113 minecraft:bone_block
setblock -1024 76 -113 minecraft:bone_block
setblock -1024 72 -114 minecraft:bone_block
setblock -1024 73 -114 minecraft:air
setblock -1024 74 -114 minecraft:air
setblock -1024 75 -114 minecraft:air
setblock -1024 76 -114 minecraft:bone_block
setblock -1024 72 -115 minecraft:bone_block
setblock -1024 73 -115 minecraft:air
setblock -1024 74 -115 minecraft:air
setblock -1024 75 -115 minecraft:air
setblock -1024 76 -115 minecraft:bone_block
setblock -1024 72 -116 minecraft:bone_block
setblock -1024 73 -116 minecraft:air
setblock -1024 74 -116 minecraft:air
setblock -1024 75 -116 minecraft:air
setblock -1024 76 -116 minecraft:bone_block
setblock -1024 72 -117 minecraft:bone_block
setblock -1024 73 -117 minecraft:air
setblock -1024 74 -117 minecraft:air
setblock -1024 75 -117 minecraft:air
setblock -1024 76 -117 minecraft:bone_block
setblock -1024 72 -118 minecraft:bone_block
setblock -1024 73 -118 minecraft:air
setblock -1024 74 -118 minecraft:air
setblock -1024 75 -118 minecraft:air
setblock -1024 76 -118 minecraft:bone_block
setblock -1024 72 -119 minecraft:bone_block
setblock -1024 73 -119 minecraft:bone_block
setblock -1024 74 -119 minecraft:black_concrete
setblock -1024 75 -119 minecraft:bone_block
setblock -1024 76 -119 minecraft:bone_block
setblock -1023 72 -113 minecraft:bone_block
setblock -1023 73 -113 minecraft:bone_block
setblock -1023 74 -113 minecraft:black_concrete
setblock -1023 75 -113 minecraft:bone_block
setblock -1023 76 -113 minecraft:bone_block
setblock -1023 72 -114 minecraft:bone_block
setblock -1023 73 -114 minecraft:air
setblock -1023 74 -114 minecraft:air
setblock -1023 75 -114 minecraft:air
setblock -1023 76 -114 minecraft:bone_block
setblock -1023 72 -115 minecraft:bone_block
setblock -1023 73 -115 minecraft:air
setblock -1023 74 -115 minecraft:air
setblock -1023 75 -115 minecraft:air
setblock -1023 76 -115 minecraft:bone_block
setblock -1023 72 -116 minecraft:bone_block
setblock -1023 73 -116 minecraft:air
setblock -1023 74 -116 minecraft:air
setblock -1023 75 -116 minecraft:air
setblock -1023 76 -116 minecraft:bone_block
setblock -1023 72 -117 minecraft:bone_block
setblock -1023 73 -117 minecraft:air
setblock -1023 74 -117 minecraft:air
setblock -1023 75 -117 minecraft:air
setblock -1023 76 -117 minecraft:bone_block
setblock -1023 72 -118 minecraft:bone_block
setblock -1023 73 -118 minecraft:air
setblock -1023 74 -118 minecraft:air
setblock -1023 75 -118 minecraft:air
setblock -1023 76 -118 minecraft:bone_block
setblock -1023 72 -119 minecraft:bone_block
setblock -1023 73 -119 minecraft:bone_block
setblock -1023 74 -119 minecraft:black_concrete
setblock -1023 75 -119 minecraft:bone_block
setblock -1023 76 -119 minecraft:bone_block
setblock -1022 72 -113 minecraft:bone_block
setblock -1022 73 -113 minecraft:bone_block
setblock -1022 74 -113 minecraft:bone_block
setblock -1022 75 -113 minecraft:bone_block
setblock -1022 76 -113 minecraft:bone_block
setblock -1022 72 -114 minecraft:bone_block
setblock -1022 73 -114 minecraft:air
setblock -1022 74 -114 minecraft:air
setblock -1022 75 -114 minecraft:air
setblock -1022 76 -114 minecraft:bone_block
setblock -1022 72 -115 minecraft:bone_block
setblock -1022 73 -115 minecraft:air
setblock -1022 74 -115 minecraft:air
setblock -1022 75 -115 minecraft:air
setblock -1022 76 -115 minecraft:bone_block
setblock -1022 72 -116 minecraft:bone_block
setblock -1022 73 -116 minecraft:air
setblock -1022 74 -116 minecraft:air
setblock -1022 75 -116 minecraft:air
setblock -1022 76 -116 minecraft:bone_block
setblock -1022 72 -117 minecraft:bone_block
setblock -1022 73 -117 minecraft:air
setblock -1022 74 -117 minecraft:air
setblock -1022 75 -117 minecraft:air
setblock -1022 76 -117 minecraft:bone_block
setblock -1022 72 -118 minecraft:bone_block
setblock -1022 73 -118 minecraft:air
setblock -1022 74 -118 minecraft:air
setblock -1022 75 -118 minecraft:air
setblock -1022 76 -118 minecraft:bone_block
setblock -1022 72 -119 minecraft:bone_block
setblock -1022 73 -119 minecraft:bone_block
setblock -1022 74 -119 minecraft:bone_block
setblock -1022 75 -119 minecraft:bone_block
setblock -1022 76 -119 minecraft:bone_block
setblock -1021 72 -113 minecraft:bone_block
setblock -1021 73 -113 minecraft:bone_block
setblock -1021 74 -113 minecraft:bone_block
setblock -1021 75 -113 minecraft:bone_block
setblock -1021 76 -113 minecraft:bone_block
setblock -1021 72 -114 minecraft:bone_block
setblock -1021 73 -114 minecraft:bone_block
setblock -1021 74 -114 minecraft:bone_block
setblock -1021 75 -114 minecraft:bone_block
setblock -1021 76 -114 minecraft:bone_block
setblock -1021 72 -115 minecraft:bone_block
setblock -1021 73 -115 minecraft:bone_block
setblock -1021 74 -115 minecraft:bone_block
setblock -1021 75 -115 minecraft:bone_block
setblock -1021 76 -115 minecraft:bone_block
setblock -1021 72 -116 minecraft:bone_block
setblock -1021 73 -116 minecraft:bone_block
setblock -1021 74 -116 minecraft:bone_block
setblock -1021 75 -116 minecraft:bone_block
setblock -1021 76 -116 minecraft:bone_block
setblock -1021 72 -117 minecraft:bone_block
setblock -1021 73 -117 minecraft:bone_block
setblock -1021 74 -117 minecraft:bone_block
setblock -1021 75 -117 minecraft:bone_block
setblock -1021 76 -117 minecraft:bone_block
setblock -1021 72 -118 minecraft:bone_block
setblock -1021 73 -118 minecraft:bone_block
setblock -1021 74 -118 minecraft:bone_block
setblock -1021 75 -118 minecraft:bone_block
setblock -1021 76 -118 minecraft:bone_block
setblock -1021 72 -119 minecraft:bone_block
setblock -1021 73 -119 minecraft:bone_block
setblock -1021 74 -119 minecraft:bone_block
setblock -1021 75 -119 minecraft:bone_block
setblock -1021 76 -119 minecraft:bone_block
setblock -1024 77 -114 minecraft:bone_block
setblock -1025 78 -114 minecraft:bone_block
setblock -1026 79 -112 minecraft:bone_block
setblock -1027 80 -112 minecraft:bone_block
setblock -1024 77 -118 minecraft:bone_block
setblock -1025 78 -118 minecraft:bone_block
setblock -1026 79 -120 minecraft:bone_block
setblock -1027 80 -120 minecraft:bone_block
setblock -1031 71 -114 minecraft:bone_block
setblock -1031 70 -118 minecraft:bone_block
setblock -1030 72 -114 minecraft:bone_block
setblock -1030 71 -118 minecraft:bone_block
setblock -1029 72 -114 minecraft:bone_block
setblock -1029 71 -118 minecraft:bone_block
setblock -1028 72 -114 minecraft:bone_block
setblock -1028 72 -118 minecraft:bone_block
setblock -1027 72 -114 minecraft:bone_block
setblock -1027 72 -118 minecraft:bone_block
setblock -1070 67 -116 minecraft:bone_block
setblock -1068 67 -117 minecraft:bone_block
setblock -1066 68 -117 minecraft:bone_block
setblock -1064 68 -116 minecraft:bone_block
setblock -1062 69 -116 minecraft:bone_block
fill -1050 68 -118 -1050 69 -118 minecraft:polished_blackstone
summon minecraft:text_display -1050.03 68.80 -117.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[90f,0f],text:'[{"text": "HERE SLEEPS WHAT THE\\nFIRE MADE.\\n", "color": "#F0C6A0", "bold": true}, {"text": "take what it gives.\\ndo not wake it twice.", "color": "#C89878"}]',background:1711276032,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]},brightness:{sky:15,block:15}}
