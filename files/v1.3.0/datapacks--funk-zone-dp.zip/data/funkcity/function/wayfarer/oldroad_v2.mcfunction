# The Old Road - built by Funk Frontier Wayfarers.java (once)
kill @e[type=minecraft:text_display,tag=wf_sign,x=-631,y=-64,z=-524,dx=17,dy=384,dz=77]
kill @e[type=minecraft:item_frame,tag=wf_dial,x=-631,y=-64,z=-524,dx=17,dy=384,dz=77]
kill @e[type=minecraft:item_frame,tag=wf_prop,x=-631,y=-64,z=-524,dx=17,dy=384,dz=77]
kill @e[type=minecraft:minecart,tag=wf_prop,x=-631,y=-64,z=-524,dx=17,dy=384,dz=77]
kill @e[type=minecraft:armor_stand,tag=wf_prop,x=-631,y=-64,z=-524,dx=17,dy=384,dz=77]
fill -627 76 -520 -627 77 -520 minecraft:red_sandstone
setblock -627 78 -520 minecraft:red_sand
fill -627 79 -520 -627 83 -520 minecraft:air
fill -626 76 -520 -626 77 -520 minecraft:red_sandstone
setblock -626 78 -520 minecraft:black_concrete
fill -626 79 -520 -626 83 -520 minecraft:air
fill -625 76 -520 -625 77 -520 minecraft:red_sandstone
setblock -625 78 -520 minecraft:black_concrete
fill -625 79 -520 -625 83 -520 minecraft:air
fill -624 76 -520 -624 77 -520 minecraft:red_sandstone
setblock -624 78 -520 minecraft:yellow_terracotta
fill -624 79 -520 -624 83 -520 minecraft:air
fill -623 75 -520 -623 77 -520 minecraft:red_sandstone
setblock -623 78 -520 minecraft:black_concrete
fill -623 79 -520 -623 83 -520 minecraft:air
fill -622 75 -520 -622 77 -520 minecraft:red_sandstone
setblock -622 78 -520 minecraft:black_concrete
fill -622 79 -520 -622 83 -520 minecraft:air
fill -621 75 -520 -621 77 -520 minecraft:red_sandstone
setblock -621 78 -520 minecraft:red_sand
fill -621 79 -520 -621 83 -520 minecraft:air
fill -627 76 -519 -627 77 -519 minecraft:red_sandstone
setblock -627 78 -519 minecraft:light_gray_concrete
fill -627 79 -519 -627 83 -519 minecraft:air
fill -626 76 -519 -626 77 -519 minecraft:red_sandstone
setblock -626 78 -519 minecraft:black_concrete
fill -626 79 -519 -626 83 -519 minecraft:air
fill -625 76 -519 -625 77 -519 minecraft:red_sandstone
setblock -625 78 -519 minecraft:gray_concrete_powder
fill -625 79 -519 -625 83 -519 minecraft:air
fill -624 76 -519 -624 77 -519 minecraft:red_sandstone
setblock -624 78 -519 minecraft:yellow_terracotta
fill -624 79 -519 -624 83 -519 minecraft:air
fill -623 76 -519 -623 77 -519 minecraft:red_sandstone
setblock -623 78 -519 minecraft:black_concrete
fill -623 79 -519 -623 83 -519 minecraft:air
fill -622 75 -519 -622 77 -519 minecraft:red_sandstone
setblock -622 78 -519 minecraft:coarse_dirt
fill -622 79 -519 -622 83 -519 minecraft:air
fill -621 75 -519 -621 77 -519 minecraft:red_sandstone
setblock -621 78 -519 minecraft:light_gray_concrete
fill -621 79 -519 -621 83 -519 minecraft:air
fill -627 76 -518 -627 77 -518 minecraft:red_sandstone
setblock -627 78 -518 minecraft:light_gray_concrete
fill -627 79 -518 -627 83 -518 minecraft:air
fill -626 76 -518 -626 77 -518 minecraft:red_sandstone
setblock -626 78 -518 minecraft:gray_concrete_powder
fill -626 79 -518 -626 83 -518 minecraft:air
fill -625 76 -518 -625 77 -518 minecraft:red_sandstone
setblock -625 78 -518 minecraft:black_concrete
fill -625 79 -518 -625 83 -518 minecraft:air
fill -624 76 -518 -624 77 -518 minecraft:red_sandstone
setblock -624 78 -518 minecraft:yellow_terracotta
fill -624 79 -518 -624 83 -518 minecraft:air
fill -623 76 -518 -623 77 -518 minecraft:red_sandstone
setblock -623 78 -518 minecraft:black_concrete
fill -623 79 -518 -623 83 -518 minecraft:air
fill -622 75 -518 -622 77 -518 minecraft:red_sandstone
setblock -622 78 -518 minecraft:gray_concrete_powder
fill -622 79 -518 -622 83 -518 minecraft:air
fill -621 75 -518 -621 77 -518 minecraft:red_sandstone
setblock -621 78 -518 minecraft:light_gray_concrete
fill -621 79 -518 -621 83 -518 minecraft:air
fill -627 76 -517 -627 77 -517 minecraft:red_sandstone
setblock -627 78 -517 minecraft:light_gray_concrete
fill -627 79 -517 -627 83 -517 minecraft:air
fill -626 76 -517 -626 77 -517 minecraft:red_sandstone
setblock -626 78 -517 minecraft:black_concrete
fill -626 79 -517 -626 83 -517 minecraft:air
fill -625 76 -517 -625 77 -517 minecraft:red_sandstone
setblock -625 78 -517 minecraft:black_concrete
fill -625 79 -517 -625 83 -517 minecraft:air
fill -624 76 -517 -624 77 -517 minecraft:red_sandstone
setblock -624 78 -517 minecraft:black_concrete
fill -624 79 -517 -624 83 -517 minecraft:air
fill -623 76 -517 -623 77 -517 minecraft:red_sandstone
setblock -623 78 -517 minecraft:gray_concrete_powder
fill -623 79 -517 -623 83 -517 minecraft:air
fill -622 76 -517 -622 77 -517 minecraft:red_sandstone
setblock -622 78 -517 minecraft:black_concrete
fill -622 79 -517 -622 83 -517 minecraft:air
fill -621 75 -517 -621 77 -517 minecraft:red_sandstone
setblock -621 78 -517 minecraft:light_gray_concrete
fill -621 79 -517 -621 83 -517 minecraft:air
fill -627 76 -516 -627 77 -516 minecraft:red_sandstone
setblock -627 78 -516 minecraft:light_gray_concrete
fill -627 79 -516 -627 83 -516 minecraft:air
fill -626 76 -516 -626 77 -516 minecraft:red_sandstone
setblock -626 78 -516 minecraft:black_concrete
fill -626 79 -516 -626 83 -516 minecraft:air
fill -625 76 -516 -625 77 -516 minecraft:red_sandstone
setblock -625 78 -516 minecraft:black_concrete
fill -625 79 -516 -625 83 -516 minecraft:air
fill -624 76 -516 -624 77 -516 minecraft:red_sandstone
setblock -624 78 -516 minecraft:gray_concrete_powder
fill -624 79 -516 -624 83 -516 minecraft:air
fill -623 76 -516 -623 77 -516 minecraft:red_sandstone
setblock -623 78 -516 minecraft:black_concrete
fill -623 79 -516 -623 83 -516 minecraft:air
fill -622 76 -516 -622 77 -516 minecraft:red_sandstone
setblock -622 78 -516 minecraft:black_concrete
fill -622 79 -516 -622 83 -516 minecraft:air
fill -621 76 -516 -621 77 -516 minecraft:red_sandstone
setblock -621 78 -516 minecraft:light_gray_concrete
fill -621 79 -516 -621 83 -516 minecraft:air
fill -627 76 -515 -627 77 -515 minecraft:red_sandstone
setblock -627 78 -515 minecraft:light_gray_concrete
fill -627 79 -515 -627 83 -515 minecraft:air
fill -626 76 -515 -626 77 -515 minecraft:red_sandstone
setblock -626 78 -515 minecraft:black_concrete
fill -626 79 -515 -626 83 -515 minecraft:air
fill -625 76 -515 -625 77 -515 minecraft:red_sandstone
setblock -625 78 -515 minecraft:coarse_dirt
fill -625 79 -515 -625 83 -515 minecraft:air
fill -624 76 -515 -624 77 -515 minecraft:red_sandstone
setblock -624 78 -515 minecraft:black_concrete
fill -624 79 -515 -624 83 -515 minecraft:air
fill -623 76 -515 -623 77 -515 minecraft:red_sandstone
setblock -623 78 -515 minecraft:black_concrete
fill -623 79 -515 -623 83 -515 minecraft:air
fill -622 76 -515 -622 77 -515 minecraft:red_sandstone
setblock -622 78 -515 minecraft:black_concrete
fill -622 79 -515 -622 83 -515 minecraft:air
fill -621 76 -515 -621 77 -515 minecraft:red_sandstone
setblock -621 78 -515 minecraft:light_gray_concrete
fill -621 79 -515 -621 83 -515 minecraft:air
fill -627 77 -514 -627 77 -514 minecraft:red_sandstone
setblock -627 78 -514 minecraft:light_gray_concrete
fill -627 79 -514 -627 83 -514 minecraft:air
fill -626 76 -514 -626 77 -514 minecraft:red_sandstone
setblock -626 78 -514 minecraft:gray_concrete_powder
fill -626 79 -514 -626 83 -514 minecraft:air
fill -625 76 -514 -625 77 -514 minecraft:red_sandstone
setblock -625 78 -514 minecraft:black_concrete
fill -625 79 -514 -625 83 -514 minecraft:air
fill -624 76 -514 -624 77 -514 minecraft:red_sandstone
setblock -624 78 -514 minecraft:yellow_terracotta
fill -624 79 -514 -624 83 -514 minecraft:air
fill -623 76 -514 -623 77 -514 minecraft:red_sandstone
setblock -623 78 -514 minecraft:coarse_dirt
fill -623 79 -514 -623 83 -514 minecraft:air
fill -622 76 -514 -622 77 -514 minecraft:red_sandstone
setblock -622 78 -514 minecraft:gray_concrete_powder
fill -622 79 -514 -622 83 -514 minecraft:air
fill -621 76 -514 -621 77 -514 minecraft:red_sandstone
setblock -621 78 -514 minecraft:light_gray_concrete
fill -621 79 -514 -621 83 -514 minecraft:air
fill -627 77 -513 -627 77 -513 minecraft:red_sandstone
setblock -627 78 -513 minecraft:light_gray_concrete
fill -627 79 -513 -627 83 -513 minecraft:air
fill -626 77 -513 -626 77 -513 minecraft:red_sandstone
setblock -626 78 -513 minecraft:black_concrete
fill -626 79 -513 -626 83 -513 minecraft:air
fill -625 77 -513 -625 77 -513 minecraft:red_sandstone
setblock -625 78 -513 minecraft:black_concrete
fill -625 79 -513 -625 83 -513 minecraft:air
fill -624 77 -513 -624 77 -513 minecraft:red_sandstone
setblock -624 78 -513 minecraft:yellow_terracotta
fill -624 79 -513 -624 83 -513 minecraft:air
fill -623 76 -513 -623 77 -513 minecraft:red_sandstone
setblock -623 78 -513 minecraft:gray_concrete_powder
fill -623 79 -513 -623 83 -513 minecraft:air
fill -622 76 -513 -622 77 -513 minecraft:red_sandstone
setblock -622 78 -513 minecraft:black_concrete
fill -622 79 -513 -622 83 -513 minecraft:air
fill -621 76 -513 -621 77 -513 minecraft:red_sandstone
setblock -621 78 -513 minecraft:light_gray_concrete
fill -621 79 -513 -621 83 -513 minecraft:air
fill -627 77 -512 -627 77 -512 minecraft:red_sandstone
setblock -627 78 -512 minecraft:light_gray_concrete
fill -627 79 -512 -627 83 -512 minecraft:air
fill -626 77 -512 -626 77 -512 minecraft:red_sandstone
setblock -626 78 -512 minecraft:black_concrete
fill -626 79 -512 -626 83 -512 minecraft:air
fill -625 77 -512 -625 77 -512 minecraft:red_sandstone
setblock -625 78 -512 minecraft:black_concrete
fill -625 79 -512 -625 83 -512 minecraft:air
fill -624 77 -512 -624 77 -512 minecraft:red_sandstone
setblock -624 78 -512 minecraft:yellow_terracotta
fill -624 79 -512 -624 83 -512 minecraft:air
fill -623 77 -512 -623 77 -512 minecraft:red_sandstone
setblock -623 78 -512 minecraft:black_concrete
fill -623 79 -512 -623 83 -512 minecraft:air
fill -622 76 -512 -622 77 -512 minecraft:red_sandstone
setblock -622 78 -512 minecraft:black_concrete
fill -622 79 -512 -622 83 -512 minecraft:air
fill -621 76 -512 -621 77 -512 minecraft:red_sandstone
setblock -621 78 -512 minecraft:light_gray_concrete
fill -621 79 -512 -621 83 -512 minecraft:air
fill -627 77 -511 -627 77 -511 minecraft:red_sandstone
setblock -627 78 -511 minecraft:red_sand
fill -627 79 -511 -627 83 -511 minecraft:air
fill -626 77 -511 -626 77 -511 minecraft:red_sandstone
setblock -626 78 -511 minecraft:black_concrete
fill -626 79 -511 -626 83 -511 minecraft:air
fill -625 77 -511 -625 77 -511 minecraft:red_sandstone
setblock -625 78 -511 minecraft:gray_concrete_powder
fill -625 79 -511 -625 83 -511 minecraft:air
fill -624 77 -511 -624 77 -511 minecraft:red_sandstone
setblock -624 78 -511 minecraft:black_concrete
fill -624 79 -511 -624 83 -511 minecraft:air
fill -623 77 -511 -623 77 -511 minecraft:red_sandstone
setblock -623 78 -511 minecraft:black_concrete
fill -623 79 -511 -623 83 -511 minecraft:air
fill -622 76 -511 -622 77 -511 minecraft:red_sandstone
setblock -622 78 -511 minecraft:black_concrete
fill -622 79 -511 -622 83 -511 minecraft:air
fill -621 76 -511 -621 77 -511 minecraft:red_sandstone
setblock -621 78 -511 minecraft:red_sand
fill -621 79 -511 -621 83 -511 minecraft:air
fill -627 77 -510 -627 77 -510 minecraft:red_sandstone
setblock -627 78 -510 minecraft:light_gray_concrete
fill -627 79 -510 -627 83 -510 minecraft:air
fill -626 77 -510 -626 77 -510 minecraft:red_sandstone
setblock -626 78 -510 minecraft:coarse_dirt
fill -626 79 -510 -626 83 -510 minecraft:air
fill -625 77 -510 -625 77 -510 minecraft:red_sandstone
setblock -625 78 -510 minecraft:black_concrete
fill -625 79 -510 -625 83 -510 minecraft:air
fill -624 77 -510 -624 77 -510 minecraft:red_sandstone
setblock -624 78 -510 minecraft:black_concrete
fill -624 79 -510 -624 83 -510 minecraft:air
fill -623 76 -510 -623 77 -510 minecraft:red_sandstone
setblock -623 78 -510 minecraft:black_concrete
fill -623 79 -510 -623 83 -510 minecraft:air
fill -622 76 -510 -622 77 -510 minecraft:red_sandstone
setblock -622 78 -510 minecraft:gray_concrete_powder
fill -622 79 -510 -622 83 -510 minecraft:air
fill -621 76 -510 -621 77 -510 minecraft:red_sandstone
setblock -621 78 -510 minecraft:light_gray_concrete
fill -621 79 -510 -621 83 -510 minecraft:air
fill -627 77 -509 -627 77 -509 minecraft:red_sandstone
setblock -627 78 -509 minecraft:light_gray_concrete
fill -627 79 -509 -627 83 -509 minecraft:air
fill -626 77 -509 -626 77 -509 minecraft:red_sandstone
setblock -626 78 -509 minecraft:black_concrete
fill -626 79 -509 -626 83 -509 minecraft:air
fill -625 77 -509 -625 77 -509 minecraft:red_sandstone
setblock -625 78 -509 minecraft:black_concrete
fill -625 79 -509 -625 83 -509 minecraft:air
fill -624 77 -509 -624 77 -509 minecraft:red_sandstone
setblock -624 78 -509 minecraft:coarse_dirt
fill -624 79 -509 -624 83 -509 minecraft:air
fill -623 76 -509 -623 77 -509 minecraft:red_sandstone
setblock -623 78 -509 minecraft:gray_concrete_powder
fill -623 79 -509 -623 83 -509 minecraft:air
fill -622 76 -509 -622 77 -509 minecraft:red_sandstone
setblock -622 78 -509 minecraft:black_concrete
fill -622 79 -509 -622 83 -509 minecraft:air
fill -621 76 -509 -621 77 -509 minecraft:red_sandstone
setblock -621 78 -509 minecraft:light_gray_concrete
fill -621 79 -509 -621 83 -509 minecraft:air
fill -627 77 -508 -627 77 -508 minecraft:red_sandstone
setblock -627 78 -508 minecraft:light_gray_concrete
fill -627 79 -508 -627 83 -508 minecraft:air
fill -626 77 -508 -626 77 -508 minecraft:red_sandstone
setblock -626 78 -508 minecraft:black_concrete
fill -626 79 -508 -626 83 -508 minecraft:air
fill -625 77 -508 -625 77 -508 minecraft:red_sandstone
setblock -625 78 -508 minecraft:black_concrete
fill -625 79 -508 -625 83 -508 minecraft:air
fill -624 77 -508 -624 77 -508 minecraft:red_sandstone
setblock -624 78 -508 minecraft:yellow_terracotta
fill -624 79 -508 -624 83 -508 minecraft:air
fill -623 76 -508 -623 77 -508 minecraft:red_sandstone
setblock -623 78 -508 minecraft:black_concrete
fill -623 79 -508 -623 83 -508 minecraft:air
fill -622 76 -508 -622 77 -508 minecraft:red_sandstone
setblock -622 78 -508 minecraft:coarse_dirt
fill -622 79 -508 -622 83 -508 minecraft:air
fill -621 76 -508 -621 77 -508 minecraft:red_sandstone
setblock -621 78 -508 minecraft:light_gray_concrete
fill -621 79 -508 -621 83 -508 minecraft:air
fill -627 77 -507 -627 77 -507 minecraft:red_sandstone
setblock -627 78 -507 minecraft:light_gray_concrete
fill -627 79 -507 -627 83 -507 minecraft:air
fill -626 77 -507 -626 77 -507 minecraft:red_sandstone
setblock -626 78 -507 minecraft:black_concrete
fill -626 79 -507 -626 83 -507 minecraft:air
fill -625 77 -507 -625 77 -507 minecraft:red_sandstone
setblock -625 78 -507 minecraft:gray_concrete_powder
fill -625 79 -507 -625 83 -507 minecraft:air
fill -624 77 -507 -624 77 -507 minecraft:red_sandstone
setblock -624 78 -507 minecraft:yellow_terracotta
fill -624 79 -507 -624 83 -507 minecraft:air
fill -623 77 -507 -623 77 -507 minecraft:red_sandstone
setblock -623 78 -507 minecraft:black_concrete
fill -623 79 -507 -623 83 -507 minecraft:air
fill -622 77 -507 -622 77 -507 minecraft:red_sandstone
setblock -622 78 -507 minecraft:black_concrete
fill -622 79 -507 -622 83 -507 minecraft:air
fill -621 76 -507 -621 77 -507 minecraft:red_sandstone
setblock -621 78 -507 minecraft:light_gray_concrete
fill -621 79 -507 -621 83 -507 minecraft:air
fill -627 77 -506 -627 77 -506 minecraft:red_sandstone
setblock -627 78 -506 minecraft:light_gray_concrete
fill -627 79 -506 -627 83 -506 minecraft:air
fill -626 77 -506 -626 77 -506 minecraft:red_sandstone
setblock -626 78 -506 minecraft:gray_concrete_powder
fill -626 79 -506 -626 83 -506 minecraft:air
fill -625 77 -506 -625 77 -506 minecraft:red_sandstone
setblock -625 78 -506 minecraft:black_concrete
fill -625 79 -506 -625 83 -506 minecraft:air
fill -624 77 -506 -624 77 -506 minecraft:red_sandstone
setblock -624 78 -506 minecraft:yellow_terracotta
fill -624 79 -506 -624 83 -506 minecraft:air
fill -623 77 -506 -623 77 -506 minecraft:red_sandstone
setblock -623 78 -506 minecraft:black_concrete
fill -623 79 -506 -623 83 -506 minecraft:air
fill -622 77 -506 -622 77 -506 minecraft:red_sandstone
setblock -622 78 -506 minecraft:gray_concrete_powder
fill -622 79 -506 -622 83 -506 minecraft:air
fill -621 77 -506 -621 77 -506 minecraft:red_sandstone
setblock -621 78 -506 minecraft:light_gray_concrete
fill -621 79 -506 -621 83 -506 minecraft:air
fill -627 77 -505 -627 77 -505 minecraft:red_sandstone
setblock -627 78 -505 minecraft:light_gray_concrete
fill -627 79 -505 -627 83 -505 minecraft:air
fill -626 77 -505 -626 77 -505 minecraft:red_sandstone
setblock -626 78 -505 minecraft:black_concrete
fill -626 79 -505 -626 83 -505 minecraft:air
fill -625 77 -505 -625 77 -505 minecraft:red_sandstone
setblock -625 78 -505 minecraft:black_concrete
fill -625 79 -505 -625 83 -505 minecraft:air
fill -624 77 -505 -624 77 -505 minecraft:red_sandstone
setblock -624 78 -505 minecraft:black_concrete
fill -624 79 -505 -624 83 -505 minecraft:air
fill -623 77 -505 -623 77 -505 minecraft:red_sandstone
setblock -623 78 -505 minecraft:gray_concrete_powder
fill -623 79 -505 -623 83 -505 minecraft:air
fill -622 77 -505 -622 77 -505 minecraft:red_sandstone
setblock -622 78 -505 minecraft:black_concrete
fill -622 79 -505 -622 83 -505 minecraft:air
fill -621 77 -505 -621 77 -505 minecraft:red_sandstone
setblock -621 78 -505 minecraft:light_gray_concrete
fill -621 79 -505 -621 83 -505 minecraft:air
fill -627 77 -504 -627 77 -504 minecraft:red_sandstone
setblock -627 78 -504 minecraft:light_gray_concrete
fill -627 79 -504 -627 83 -504 minecraft:air
fill -626 77 -504 -626 77 -504 minecraft:red_sandstone
setblock -626 78 -504 minecraft:black_concrete
fill -626 79 -504 -626 83 -504 minecraft:air
fill -625 77 -504 -625 77 -504 minecraft:red_sandstone
setblock -625 78 -504 minecraft:coarse_dirt
fill -625 79 -504 -625 83 -504 minecraft:air
fill -624 77 -504 -624 77 -504 minecraft:red_sandstone
setblock -624 78 -504 minecraft:gray_concrete_powder
fill -624 79 -504 -624 83 -504 minecraft:air
fill -623 77 -504 -623 77 -504 minecraft:red_sandstone
setblock -623 78 -504 minecraft:black_concrete
fill -623 79 -504 -623 83 -504 minecraft:air
fill -622 77 -504 -622 77 -504 minecraft:red_sandstone
setblock -622 78 -504 minecraft:black_concrete
fill -622 79 -504 -622 83 -504 minecraft:air
fill -621 77 -504 -621 77 -504 minecraft:red_sandstone
setblock -621 78 -504 minecraft:light_gray_concrete
fill -621 79 -504 -621 83 -504 minecraft:air
fill -627 77 -503 -627 77 -503 minecraft:red_sandstone
setblock -627 78 -503 minecraft:light_gray_concrete
fill -627 79 -503 -627 83 -503 minecraft:air
fill -626 77 -503 -626 77 -503 minecraft:red_sandstone
setblock -626 78 -503 minecraft:black_concrete
fill -626 79 -503 -626 83 -503 minecraft:air
fill -625 77 -503 -625 77 -503 minecraft:red_sandstone
setblock -625 78 -503 minecraft:gray_concrete_powder
fill -625 79 -503 -625 83 -503 minecraft:air
fill -624 77 -503 -624 77 -503 minecraft:red_sandstone
setblock -624 78 -503 minecraft:black_concrete
fill -624 79 -503 -624 83 -503 minecraft:air
fill -623 77 -503 -623 77 -503 minecraft:red_sandstone
setblock -623 78 -503 minecraft:coarse_dirt
fill -623 79 -503 -623 83 -503 minecraft:air
fill -622 77 -503 -622 77 -503 minecraft:red_sandstone
setblock -622 78 -503 minecraft:black_concrete
fill -622 79 -503 -622 83 -503 minecraft:air
fill -621 77 -503 -621 77 -503 minecraft:red_sandstone
setblock -621 78 -503 minecraft:light_gray_concrete
fill -621 79 -503 -621 83 -503 minecraft:air
fill -627 77 -502 -627 77 -502 minecraft:red_sandstone
setblock -627 78 -502 minecraft:red_sand
fill -627 79 -502 -627 83 -502 minecraft:air
fill -626 77 -502 -626 77 -502 minecraft:red_sandstone
setblock -626 78 -502 minecraft:gray_concrete_powder
fill -626 79 -502 -626 83 -502 minecraft:air
fill -625 77 -502 -625 77 -502 minecraft:red_sandstone
setblock -625 78 -502 minecraft:black_concrete
fill -625 79 -502 -625 83 -502 minecraft:air
fill -624 77 -502 -624 77 -502 minecraft:red_sandstone
setblock -624 78 -502 minecraft:yellow_terracotta
fill -624 79 -502 -624 83 -502 minecraft:air
fill -623 77 -502 -623 77 -502 minecraft:red_sandstone
setblock -623 78 -502 minecraft:black_concrete
fill -623 79 -502 -623 83 -502 minecraft:air
fill -622 77 -502 -622 77 -502 minecraft:red_sandstone
setblock -622 78 -502 minecraft:gray_concrete_powder
fill -622 79 -502 -622 83 -502 minecraft:air
fill -621 77 -502 -621 77 -502 minecraft:red_sandstone
setblock -621 78 -502 minecraft:red_sand
fill -621 79 -502 -621 83 -502 minecraft:air
fill -627 77 -501 -627 77 -501 minecraft:red_sandstone
setblock -627 78 -501 minecraft:light_gray_concrete
fill -627 79 -501 -627 83 -501 minecraft:air
fill -626 77 -501 -626 77 -501 minecraft:red_sandstone
setblock -626 78 -501 minecraft:black_concrete
fill -626 79 -501 -626 83 -501 minecraft:air
setblock -625 78 -501 minecraft:black_concrete
fill -625 79 -501 -625 83 -501 minecraft:air
setblock -624 78 -501 minecraft:yellow_terracotta
fill -624 79 -501 -624 83 -501 minecraft:air
setblock -623 78 -501 minecraft:gray_concrete_powder
fill -623 79 -501 -623 83 -501 minecraft:air
fill -622 77 -501 -622 77 -501 minecraft:red_sandstone
setblock -622 78 -501 minecraft:black_concrete
fill -622 79 -501 -622 83 -501 minecraft:air
fill -621 77 -501 -621 77 -501 minecraft:red_sandstone
setblock -621 78 -501 minecraft:light_gray_concrete
fill -621 79 -501 -621 83 -501 minecraft:air
fill -627 77 -500 -627 77 -500 minecraft:red_sandstone
setblock -627 78 -500 minecraft:light_gray_concrete
fill -627 79 -500 -627 83 -500 minecraft:air
setblock -626 78 -500 minecraft:black_concrete
fill -626 79 -500 -626 83 -500 minecraft:air
setblock -625 78 -500 minecraft:black_concrete
fill -625 79 -500 -625 83 -500 minecraft:air
setblock -624 78 -500 minecraft:yellow_terracotta
fill -624 79 -500 -624 83 -500 minecraft:air
setblock -623 78 -500 minecraft:black_concrete
fill -623 79 -500 -623 83 -500 minecraft:air
setblock -622 78 -500 minecraft:black_concrete
fill -622 79 -500 -622 83 -500 minecraft:air
setblock -621 78 -500 minecraft:light_gray_concrete
fill -621 79 -500 -621 83 -500 minecraft:air
fill -627 77 -499 -627 77 -499 minecraft:red_sandstone
setblock -627 78 -499 minecraft:light_gray_concrete
fill -627 79 -499 -627 83 -499 minecraft:air
setblock -626 78 -499 minecraft:coarse_dirt
fill -626 79 -499 -626 83 -499 minecraft:air
setblock -625 78 -499 minecraft:gray_concrete_powder
fill -625 79 -499 -625 83 -499 minecraft:air
setblock -624 78 -499 minecraft:black_concrete
fill -624 79 -499 -624 83 -499 minecraft:air
setblock -623 78 -499 minecraft:black_concrete
fill -623 79 -499 -623 83 -499 minecraft:air
setblock -622 78 -499 minecraft:black_concrete
fill -622 79 -499 -622 83 -499 minecraft:air
setblock -621 78 -499 minecraft:light_gray_concrete
fill -621 79 -499 -621 83 -499 minecraft:air
setblock -627 78 -498 minecraft:light_gray_concrete
fill -627 79 -498 -627 83 -498 minecraft:air
setblock -626 78 -498 minecraft:gray_concrete_powder
fill -626 79 -498 -626 83 -498 minecraft:air
setblock -625 78 -498 minecraft:black_concrete
fill -625 79 -498 -625 83 -498 minecraft:air
setblock -624 78 -498 minecraft:coarse_dirt
fill -624 79 -498 -624 83 -498 minecraft:air
setblock -623 78 -498 minecraft:black_concrete
fill -623 79 -498 -623 83 -498 minecraft:air
setblock -622 78 -498 minecraft:gray_concrete_powder
fill -622 79 -498 -622 83 -498 minecraft:air
setblock -621 78 -498 minecraft:light_gray_concrete
fill -621 79 -498 -621 83 -498 minecraft:air
setblock -627 78 -497 minecraft:light_gray_concrete
fill -627 79 -497 -627 83 -497 minecraft:air
setblock -626 78 -497 minecraft:black_concrete
fill -626 79 -497 -626 83 -497 minecraft:air
setblock -625 78 -497 minecraft:black_concrete
fill -625 79 -497 -625 83 -497 minecraft:air
setblock -624 78 -497 minecraft:black_concrete
fill -624 79 -497 -624 83 -497 minecraft:air
setblock -623 78 -497 minecraft:gray_concrete_powder
fill -623 79 -497 -623 83 -497 minecraft:air
setblock -622 78 -497 minecraft:coarse_dirt
fill -622 79 -497 -622 83 -497 minecraft:air
setblock -621 78 -497 minecraft:light_gray_concrete
fill -621 79 -497 -621 83 -497 minecraft:air
setblock -627 78 -496 minecraft:light_gray_concrete
fill -627 79 -496 -627 83 -496 minecraft:air
setblock -626 78 -496 minecraft:black_concrete
fill -626 79 -496 -626 83 -496 minecraft:air
setblock -625 78 -496 minecraft:black_concrete
fill -625 79 -496 -625 83 -496 minecraft:air
setblock -624 78 -496 minecraft:yellow_terracotta
fill -624 79 -496 -624 83 -496 minecraft:air
setblock -623 78 -496 minecraft:black_concrete
fill -623 79 -496 -623 83 -496 minecraft:air
setblock -622 78 -496 minecraft:black_concrete
fill -622 79 -496 -622 83 -496 minecraft:air
setblock -621 78 -496 minecraft:light_gray_concrete
fill -621 79 -496 -621 83 -496 minecraft:air
setblock -627 78 -495 minecraft:light_gray_concrete
fill -627 79 -495 -627 83 -495 minecraft:air
setblock -626 78 -495 minecraft:black_concrete
fill -626 79 -495 -626 83 -495 minecraft:air
setblock -625 78 -495 minecraft:gray_concrete_powder
fill -625 79 -495 -625 83 -495 minecraft:air
setblock -624 78 -495 minecraft:yellow_terracotta
fill -624 79 -495 -624 83 -495 minecraft:air
setblock -623 78 -495 minecraft:black_concrete
fill -623 79 -495 -623 83 -495 minecraft:air
setblock -622 78 -495 minecraft:black_concrete
fill -622 79 -495 -622 83 -495 minecraft:air
setblock -621 78 -495 minecraft:light_gray_concrete
fill -621 79 -495 -621 83 -495 minecraft:air
fill -627 77 -494 -627 77 -494 minecraft:red_sandstone
setblock -627 78 -494 minecraft:light_gray_concrete
fill -627 79 -494 -627 83 -494 minecraft:air
fill -626 77 -494 -626 77 -494 minecraft:red_sandstone
setblock -626 78 -494 minecraft:gray_concrete_powder
fill -626 79 -494 -626 83 -494 minecraft:air
fill -625 77 -494 -625 77 -494 minecraft:red_sandstone
setblock -625 78 -494 minecraft:black_concrete
fill -625 79 -494 -625 83 -494 minecraft:air
fill -624 77 -494 -624 77 -494 minecraft:red_sandstone
setblock -624 78 -494 minecraft:yellow_terracotta
fill -624 79 -494 -624 83 -494 minecraft:air
fill -623 77 -494 -623 77 -494 minecraft:red_sandstone
setblock -623 78 -494 minecraft:black_concrete
fill -623 79 -494 -623 83 -494 minecraft:air
fill -622 77 -494 -622 77 -494 minecraft:red_sandstone
setblock -622 78 -494 minecraft:gray_concrete_powder
fill -622 79 -494 -622 83 -494 minecraft:air
fill -621 77 -494 -621 77 -494 minecraft:red_sandstone
setblock -621 78 -494 minecraft:light_gray_concrete
fill -621 79 -494 -621 83 -494 minecraft:air
fill -627 77 -493 -627 77 -493 minecraft:red_sandstone
setblock -627 78 -493 minecraft:red_sand
fill -627 79 -493 -627 83 -493 minecraft:air
fill -626 77 -493 -626 77 -493 minecraft:red_sandstone
setblock -626 78 -493 minecraft:black_concrete
fill -626 79 -493 -626 83 -493 minecraft:air
fill -625 77 -493 -625 77 -493 minecraft:red_sandstone
setblock -625 78 -493 minecraft:coarse_dirt
fill -625 79 -493 -625 83 -493 minecraft:air
fill -624 77 -493 -624 77 -493 minecraft:red_sandstone
setblock -624 78 -493 minecraft:black_concrete
fill -624 79 -493 -624 83 -493 minecraft:air
fill -623 77 -493 -623 77 -493 minecraft:red_sandstone
setblock -623 78 -493 minecraft:gray_concrete_powder
fill -623 79 -493 -623 83 -493 minecraft:air
fill -622 77 -493 -622 77 -493 minecraft:red_sandstone
setblock -622 78 -493 minecraft:black_concrete
fill -622 79 -493 -622 83 -493 minecraft:air
fill -621 77 -493 -621 77 -493 minecraft:red_sandstone
setblock -621 78 -493 minecraft:red_sand
fill -621 79 -493 -621 83 -493 minecraft:air
fill -627 77 -492 -627 77 -492 minecraft:red_sandstone
setblock -627 78 -492 minecraft:light_gray_concrete
fill -627 79 -492 -627 83 -492 minecraft:air
fill -626 77 -492 -626 77 -492 minecraft:red_sandstone
setblock -626 78 -492 minecraft:black_concrete
fill -626 79 -492 -626 83 -492 minecraft:air
fill -625 77 -492 -625 77 -492 minecraft:red_sandstone
setblock -625 78 -492 minecraft:black_concrete
fill -625 79 -492 -625 83 -492 minecraft:air
fill -624 77 -492 -624 77 -492 minecraft:red_sandstone
setblock -624 78 -492 minecraft:gray_concrete_powder
fill -624 79 -492 -624 83 -492 minecraft:air
fill -623 77 -492 -623 77 -492 minecraft:red_sandstone
setblock -623 78 -492 minecraft:coarse_dirt
fill -623 79 -492 -623 83 -492 minecraft:air
fill -622 77 -492 -622 77 -492 minecraft:red_sandstone
setblock -622 78 -492 minecraft:black_concrete
fill -622 79 -492 -622 83 -492 minecraft:air
fill -621 77 -492 -621 77 -492 minecraft:red_sandstone
setblock -621 78 -492 minecraft:light_gray_concrete
fill -621 79 -492 -621 83 -492 minecraft:air
fill -627 77 -491 -627 77 -491 minecraft:red_sandstone
setblock -627 78 -491 minecraft:light_gray_concrete
fill -627 79 -491 -627 83 -491 minecraft:air
fill -626 77 -491 -626 77 -491 minecraft:red_sandstone
setblock -626 78 -491 minecraft:black_concrete
fill -626 79 -491 -626 83 -491 minecraft:air
fill -625 77 -491 -625 77 -491 minecraft:red_sandstone
setblock -625 78 -491 minecraft:gray_concrete_powder
fill -625 79 -491 -625 83 -491 minecraft:air
fill -624 77 -491 -624 77 -491 minecraft:red_sandstone
setblock -624 78 -491 minecraft:black_concrete
fill -624 79 -491 -624 83 -491 minecraft:air
fill -623 77 -491 -623 77 -491 minecraft:red_sandstone
setblock -623 78 -491 minecraft:black_concrete
fill -623 79 -491 -623 83 -491 minecraft:air
fill -622 77 -491 -622 77 -491 minecraft:red_sandstone
setblock -622 78 -491 minecraft:black_concrete
fill -622 79 -491 -622 83 -491 minecraft:air
fill -621 77 -491 -621 77 -491 minecraft:red_sandstone
setblock -621 78 -491 minecraft:light_gray_concrete
fill -621 79 -491 -621 83 -491 minecraft:air
fill -627 77 -490 -627 77 -490 minecraft:red_sandstone
setblock -627 78 -490 minecraft:light_gray_concrete
fill -627 79 -490 -627 83 -490 minecraft:air
fill -626 77 -490 -626 77 -490 minecraft:red_sandstone
setblock -626 78 -490 minecraft:gray_concrete_powder
fill -626 79 -490 -626 83 -490 minecraft:air
fill -625 77 -490 -625 77 -490 minecraft:red_sandstone
setblock -625 78 -490 minecraft:black_concrete
fill -625 79 -490 -625 83 -490 minecraft:air
fill -624 77 -490 -624 77 -490 minecraft:red_sandstone
setblock -624 78 -490 minecraft:yellow_terracotta
fill -624 79 -490 -624 83 -490 minecraft:air
fill -623 77 -490 -623 77 -490 minecraft:red_sandstone
setblock -623 78 -490 minecraft:black_concrete
fill -623 79 -490 -623 83 -490 minecraft:air
fill -622 77 -490 -622 77 -490 minecraft:red_sandstone
setblock -622 78 -490 minecraft:gray_concrete_powder
fill -622 79 -490 -622 83 -490 minecraft:air
fill -621 77 -490 -621 77 -490 minecraft:red_sandstone
setblock -621 78 -490 minecraft:light_gray_concrete
fill -621 79 -490 -621 83 -490 minecraft:air
fill -627 77 -489 -627 77 -489 minecraft:red_sandstone
setblock -627 78 -489 minecraft:light_gray_concrete
fill -627 79 -489 -627 83 -489 minecraft:air
fill -626 77 -489 -626 77 -489 minecraft:red_sandstone
setblock -626 78 -489 minecraft:black_concrete
fill -626 79 -489 -626 83 -489 minecraft:air
fill -625 77 -489 -625 77 -489 minecraft:red_sandstone
setblock -625 78 -489 minecraft:black_concrete
fill -625 79 -489 -625 83 -489 minecraft:air
fill -624 77 -489 -624 77 -489 minecraft:red_sandstone
setblock -624 78 -489 minecraft:yellow_terracotta
fill -624 79 -489 -624 83 -489 minecraft:air
fill -623 77 -489 -623 77 -489 minecraft:red_sandstone
setblock -623 78 -489 minecraft:gray_concrete_powder
fill -623 79 -489 -623 83 -489 minecraft:air
fill -622 77 -489 -622 77 -489 minecraft:red_sandstone
setblock -622 78 -489 minecraft:black_concrete
fill -622 79 -489 -622 83 -489 minecraft:air
fill -621 77 -489 -621 77 -489 minecraft:red_sandstone
setblock -621 78 -489 minecraft:light_gray_concrete
fill -621 79 -489 -621 83 -489 minecraft:air
fill -627 77 -488 -627 77 -488 minecraft:red_sandstone
setblock -627 78 -488 minecraft:light_gray_concrete
fill -627 79 -488 -627 83 -488 minecraft:air
fill -626 77 -488 -626 77 -488 minecraft:red_sandstone
setblock -626 78 -488 minecraft:coarse_dirt
fill -626 79 -488 -626 83 -488 minecraft:air
fill -625 77 -488 -625 77 -488 minecraft:red_sandstone
setblock -625 78 -488 minecraft:black_concrete
fill -625 79 -488 -625 83 -488 minecraft:air
fill -624 77 -488 -624 77 -488 minecraft:red_sandstone
setblock -624 78 -488 minecraft:yellow_terracotta
fill -624 79 -488 -624 83 -488 minecraft:air
fill -623 77 -488 -623 77 -488 minecraft:red_sandstone
setblock -623 78 -488 minecraft:black_concrete
fill -623 79 -488 -623 83 -488 minecraft:air
fill -622 77 -488 -622 77 -488 minecraft:red_sandstone
setblock -622 78 -488 minecraft:black_concrete
fill -622 79 -488 -622 83 -488 minecraft:air
fill -621 77 -488 -621 77 -488 minecraft:red_sandstone
setblock -621 78 -488 minecraft:light_gray_concrete
fill -621 79 -488 -621 83 -488 minecraft:air
fill -627 77 -487 -627 77 -487 minecraft:red_sandstone
setblock -627 78 -487 minecraft:light_gray_concrete
fill -627 79 -487 -627 83 -487 minecraft:air
fill -626 77 -487 -626 77 -487 minecraft:red_sandstone
setblock -626 78 -487 minecraft:black_concrete
fill -626 79 -487 -626 83 -487 minecraft:air
fill -625 77 -487 -625 77 -487 minecraft:red_sandstone
setblock -625 78 -487 minecraft:gray_concrete_powder
fill -625 79 -487 -625 83 -487 minecraft:air
fill -624 77 -487 -624 77 -487 minecraft:red_sandstone
setblock -624 78 -487 minecraft:coarse_dirt
fill -624 79 -487 -624 83 -487 minecraft:air
fill -623 77 -487 -623 77 -487 minecraft:red_sandstone
setblock -623 78 -487 minecraft:black_concrete
fill -623 79 -487 -623 83 -487 minecraft:air
fill -622 77 -487 -622 77 -487 minecraft:red_sandstone
setblock -622 78 -487 minecraft:black_concrete
fill -622 79 -487 -622 83 -487 minecraft:air
fill -621 77 -487 -621 77 -487 minecraft:red_sandstone
setblock -621 78 -487 minecraft:light_gray_concrete
fill -621 79 -487 -621 83 -487 minecraft:air
fill -627 77 -486 -627 77 -486 minecraft:red_sandstone
setblock -627 78 -486 minecraft:light_gray_concrete
fill -627 79 -486 -627 83 -486 minecraft:air
fill -626 77 -486 -626 77 -486 minecraft:red_sandstone
setblock -626 78 -486 minecraft:gray_concrete_powder
fill -626 79 -486 -626 83 -486 minecraft:air
fill -625 77 -486 -625 77 -486 minecraft:red_sandstone
setblock -625 78 -486 minecraft:black_concrete
fill -625 79 -486 -625 83 -486 minecraft:air
fill -624 77 -486 -624 77 -486 minecraft:red_sandstone
setblock -624 78 -486 minecraft:black_concrete
fill -624 79 -486 -624 83 -486 minecraft:air
fill -623 77 -486 -623 77 -486 minecraft:red_sandstone
setblock -623 78 -486 minecraft:black_concrete
fill -623 79 -486 -623 83 -486 minecraft:air
fill -622 77 -486 -622 77 -486 minecraft:red_sandstone
setblock -622 78 -486 minecraft:coarse_dirt
fill -622 79 -486 -622 83 -486 minecraft:air
fill -621 77 -486 -621 77 -486 minecraft:red_sandstone
setblock -621 78 -486 minecraft:light_gray_concrete
fill -621 79 -486 -621 83 -486 minecraft:air
fill -627 77 -485 -627 77 -485 minecraft:red_sandstone
setblock -627 78 -485 minecraft:light_gray_concrete
fill -627 79 -485 -627 83 -485 minecraft:air
fill -626 77 -485 -626 77 -485 minecraft:red_sandstone
setblock -626 78 -485 minecraft:black_concrete
fill -626 79 -485 -626 83 -485 minecraft:air
fill -625 77 -485 -625 77 -485 minecraft:red_sandstone
setblock -625 78 -485 minecraft:black_concrete
fill -625 79 -485 -625 83 -485 minecraft:air
fill -624 77 -485 -624 77 -485 minecraft:red_sandstone
setblock -624 78 -485 minecraft:black_concrete
fill -624 79 -485 -624 83 -485 minecraft:air
fill -623 77 -485 -623 77 -485 minecraft:red_sandstone
setblock -623 78 -485 minecraft:gray_concrete_powder
fill -623 79 -485 -623 83 -485 minecraft:air
fill -622 77 -485 -622 77 -485 minecraft:red_sandstone
setblock -622 78 -485 minecraft:black_concrete
fill -622 79 -485 -622 83 -485 minecraft:air
fill -621 77 -485 -621 77 -485 minecraft:red_sandstone
setblock -621 78 -485 minecraft:light_gray_concrete
fill -621 79 -485 -621 83 -485 minecraft:air
fill -627 77 -484 -627 77 -484 minecraft:red_sandstone
setblock -627 78 -484 minecraft:red_sand
fill -627 79 -484 -627 83 -484 minecraft:air
fill -626 77 -484 -626 77 -484 minecraft:red_sandstone
setblock -626 78 -484 minecraft:black_concrete
fill -626 79 -484 -626 83 -484 minecraft:air
fill -625 77 -484 -625 77 -484 minecraft:red_sandstone
setblock -625 78 -484 minecraft:black_concrete
fill -625 79 -484 -625 83 -484 minecraft:air
fill -624 77 -484 -624 77 -484 minecraft:red_sandstone
setblock -624 78 -484 minecraft:yellow_terracotta
fill -624 79 -484 -624 83 -484 minecraft:air
fill -623 77 -484 -623 77 -484 minecraft:red_sandstone
setblock -623 78 -484 minecraft:black_concrete
fill -623 79 -484 -623 83 -484 minecraft:air
fill -622 77 -484 -622 77 -484 minecraft:red_sandstone
setblock -622 78 -484 minecraft:black_concrete
fill -622 79 -484 -622 83 -484 minecraft:air
fill -621 77 -484 -621 77 -484 minecraft:red_sandstone
setblock -621 78 -484 minecraft:red_sand
fill -621 79 -484 -621 83 -484 minecraft:air
fill -627 77 -483 -627 77 -483 minecraft:red_sandstone
setblock -627 78 -483 minecraft:light_gray_concrete
fill -627 79 -483 -627 83 -483 minecraft:air
fill -626 77 -483 -626 77 -483 minecraft:red_sandstone
setblock -626 78 -483 minecraft:black_concrete
fill -626 79 -483 -626 83 -483 minecraft:air
fill -625 77 -483 -625 77 -483 minecraft:red_sandstone
setblock -625 78 -483 minecraft:gray_concrete_powder
fill -625 79 -483 -625 83 -483 minecraft:air
fill -624 77 -483 -624 77 -483 minecraft:red_sandstone
setblock -624 78 -483 minecraft:yellow_terracotta
fill -624 79 -483 -624 83 -483 minecraft:air
fill -623 77 -483 -623 77 -483 minecraft:red_sandstone
setblock -623 78 -483 minecraft:black_concrete
fill -623 79 -483 -623 83 -483 minecraft:air
fill -622 77 -483 -622 77 -483 minecraft:red_sandstone
setblock -622 78 -483 minecraft:black_concrete
fill -622 79 -483 -622 83 -483 minecraft:air
fill -621 77 -483 -621 77 -483 minecraft:red_sandstone
setblock -621 78 -483 minecraft:light_gray_concrete
fill -621 79 -483 -621 83 -483 minecraft:air
fill -627 77 -482 -627 77 -482 minecraft:red_sandstone
setblock -627 78 -482 minecraft:light_gray_concrete
fill -627 79 -482 -627 83 -482 minecraft:air
fill -626 77 -482 -626 77 -482 minecraft:red_sandstone
setblock -626 78 -482 minecraft:gray_concrete_powder
fill -626 79 -482 -626 83 -482 minecraft:air
fill -625 77 -482 -625 77 -482 minecraft:red_sandstone
setblock -625 78 -482 minecraft:coarse_dirt
fill -625 79 -482 -625 83 -482 minecraft:air
fill -624 76 -482 -624 77 -482 minecraft:red_sandstone
setblock -624 78 -482 minecraft:yellow_terracotta
fill -624 79 -482 -624 83 -482 minecraft:air
fill -623 77 -482 -623 77 -482 minecraft:red_sandstone
setblock -623 78 -482 minecraft:black_concrete
fill -623 79 -482 -623 83 -482 minecraft:air
fill -622 77 -482 -622 77 -482 minecraft:red_sandstone
setblock -622 78 -482 minecraft:gray_concrete_powder
fill -622 79 -482 -622 83 -482 minecraft:air
fill -621 77 -482 -621 77 -482 minecraft:red_sandstone
setblock -621 78 -482 minecraft:light_gray_concrete
fill -621 79 -482 -621 83 -482 minecraft:air
fill -627 76 -481 -627 77 -481 minecraft:red_sandstone
setblock -627 78 -481 minecraft:light_gray_concrete
fill -627 79 -481 -627 83 -481 minecraft:air
fill -626 76 -481 -626 77 -481 minecraft:red_sandstone
setblock -626 78 -481 minecraft:black_concrete
fill -626 79 -481 -626 83 -481 minecraft:air
fill -625 76 -481 -625 77 -481 minecraft:red_sandstone
setblock -625 78 -481 minecraft:black_concrete
fill -625 79 -481 -625 83 -481 minecraft:air
fill -624 76 -481 -624 77 -481 minecraft:red_sandstone
setblock -624 78 -481 minecraft:black_concrete
fill -624 79 -481 -624 83 -481 minecraft:air
fill -623 76 -481 -623 77 -481 minecraft:red_sandstone
setblock -623 78 -481 minecraft:coarse_dirt
fill -623 79 -481 -623 83 -481 minecraft:air
fill -622 77 -481 -622 77 -481 minecraft:red_sandstone
setblock -622 78 -481 minecraft:black_concrete
fill -622 79 -481 -622 83 -481 minecraft:air
fill -621 77 -481 -621 77 -481 minecraft:red_sandstone
setblock -621 78 -481 minecraft:light_gray_concrete
fill -621 79 -481 -621 83 -481 minecraft:air
fill -627 76 -480 -627 77 -480 minecraft:red_sandstone
setblock -627 78 -480 minecraft:light_gray_concrete
fill -627 79 -480 -627 83 -480 minecraft:air
fill -626 76 -480 -626 77 -480 minecraft:red_sandstone
setblock -626 78 -480 minecraft:black_concrete
fill -626 79 -480 -626 83 -480 minecraft:air
fill -625 76 -480 -625 77 -480 minecraft:red_sandstone
setblock -625 78 -480 minecraft:black_concrete
fill -625 79 -480 -625 83 -480 minecraft:air
fill -624 76 -480 -624 77 -480 minecraft:red_sandstone
setblock -624 78 -480 minecraft:gray_concrete_powder
fill -624 79 -480 -624 83 -480 minecraft:air
fill -623 76 -480 -623 77 -480 minecraft:red_sandstone
setblock -623 78 -480 minecraft:black_concrete
fill -623 79 -480 -623 83 -480 minecraft:air
fill -622 77 -480 -622 77 -480 minecraft:red_sandstone
setblock -622 78 -480 minecraft:black_concrete
fill -622 79 -480 -622 83 -480 minecraft:air
fill -621 77 -480 -621 77 -480 minecraft:red_sandstone
setblock -621 78 -480 minecraft:light_gray_concrete
fill -621 79 -480 -621 83 -480 minecraft:air
fill -627 76 -479 -627 77 -479 minecraft:red_sandstone
setblock -627 78 -479 minecraft:light_gray_concrete
fill -627 79 -479 -627 83 -479 minecraft:air
fill -626 76 -479 -626 77 -479 minecraft:red_sandstone
setblock -626 78 -479 minecraft:black_concrete
fill -626 79 -479 -626 83 -479 minecraft:air
fill -625 76 -479 -625 77 -479 minecraft:red_sandstone
setblock -625 78 -479 minecraft:gray_concrete_powder
fill -625 79 -479 -625 83 -479 minecraft:air
fill -624 76 -479 -624 77 -479 minecraft:red_sandstone
setblock -624 78 -479 minecraft:black_concrete
fill -624 79 -479 -624 83 -479 minecraft:air
fill -623 76 -479 -623 77 -479 minecraft:red_sandstone
setblock -623 78 -479 minecraft:black_concrete
fill -623 79 -479 -623 83 -479 minecraft:air
fill -622 76 -479 -622 77 -479 minecraft:red_sandstone
setblock -622 78 -479 minecraft:black_concrete
fill -622 79 -479 -622 83 -479 minecraft:air
fill -621 77 -479 -621 77 -479 minecraft:red_sandstone
setblock -621 78 -479 minecraft:light_gray_concrete
fill -621 79 -479 -621 83 -479 minecraft:air
fill -627 76 -478 -627 77 -478 minecraft:red_sandstone
setblock -627 78 -478 minecraft:light_gray_concrete
fill -627 79 -478 -627 83 -478 minecraft:air
fill -626 76 -478 -626 77 -478 minecraft:red_sandstone
setblock -626 78 -478 minecraft:gray_concrete_powder
fill -626 79 -478 -626 83 -478 minecraft:air
fill -625 76 -478 -625 77 -478 minecraft:red_sandstone
setblock -625 78 -478 minecraft:black_concrete
fill -625 79 -478 -625 83 -478 minecraft:air
fill -624 76 -478 -624 77 -478 minecraft:red_sandstone
setblock -624 78 -478 minecraft:yellow_terracotta
fill -624 79 -478 -624 83 -478 minecraft:air
fill -623 76 -478 -623 77 -478 minecraft:red_sandstone
setblock -623 78 -478 minecraft:black_concrete
fill -623 79 -478 -623 83 -478 minecraft:air
fill -622 76 -478 -622 77 -478 minecraft:red_sandstone
setblock -622 78 -478 minecraft:gray_concrete_powder
fill -622 79 -478 -622 83 -478 minecraft:air
fill -621 76 -478 -621 77 -478 minecraft:red_sandstone
setblock -621 78 -478 minecraft:light_gray_concrete
fill -621 79 -478 -621 83 -478 minecraft:air
fill -627 76 -477 -627 77 -477 minecraft:red_sandstone
setblock -627 78 -477 minecraft:light_gray_concrete
fill -627 79 -477 -627 83 -477 minecraft:air
fill -626 76 -477 -626 77 -477 minecraft:red_sandstone
setblock -626 78 -477 minecraft:coarse_dirt
fill -626 79 -477 -626 83 -477 minecraft:air
fill -625 76 -477 -625 77 -477 minecraft:red_sandstone
setblock -625 78 -477 minecraft:black_concrete
fill -625 79 -477 -625 83 -477 minecraft:air
fill -624 76 -477 -624 77 -477 minecraft:red_sandstone
setblock -624 78 -477 minecraft:yellow_terracotta
fill -624 79 -477 -624 83 -477 minecraft:air
fill -623 76 -477 -623 77 -477 minecraft:red_sandstone
setblock -623 78 -477 minecraft:gray_concrete_powder
fill -623 79 -477 -623 83 -477 minecraft:air
fill -622 76 -477 -622 77 -477 minecraft:red_sandstone
setblock -622 78 -477 minecraft:black_concrete
fill -622 79 -477 -622 83 -477 minecraft:air
fill -621 76 -477 -621 77 -477 minecraft:red_sandstone
setblock -621 78 -477 minecraft:light_gray_concrete
fill -621 79 -477 -621 83 -477 minecraft:air
fill -627 76 -476 -627 77 -476 minecraft:red_sandstone
setblock -627 78 -476 minecraft:light_gray_concrete
fill -627 79 -476 -627 83 -476 minecraft:air
fill -626 76 -476 -626 77 -476 minecraft:red_sandstone
setblock -626 78 -476 minecraft:black_concrete
fill -626 79 -476 -626 83 -476 minecraft:air
fill -625 76 -476 -625 77 -476 minecraft:red_sandstone
setblock -625 78 -476 minecraft:black_concrete
fill -625 79 -476 -625 83 -476 minecraft:air
fill -624 76 -476 -624 77 -476 minecraft:red_sandstone
setblock -624 78 -476 minecraft:yellow_terracotta
fill -624 79 -476 -624 83 -476 minecraft:air
fill -623 76 -476 -623 77 -476 minecraft:red_sandstone
setblock -623 78 -476 minecraft:black_concrete
fill -623 79 -476 -623 83 -476 minecraft:air
fill -622 76 -476 -622 77 -476 minecraft:red_sandstone
setblock -622 78 -476 minecraft:black_concrete
fill -622 79 -476 -622 83 -476 minecraft:air
fill -621 76 -476 -621 77 -476 minecraft:red_sandstone
setblock -621 78 -476 minecraft:light_gray_concrete
fill -621 79 -476 -621 83 -476 minecraft:air
fill -627 76 -475 -627 77 -475 minecraft:red_sandstone
setblock -627 78 -475 minecraft:red_sand
fill -627 79 -475 -627 83 -475 minecraft:air
fill -626 76 -475 -626 77 -475 minecraft:red_sandstone
setblock -626 78 -475 minecraft:black_concrete
fill -626 79 -475 -626 83 -475 minecraft:air
fill -625 76 -475 -625 77 -475 minecraft:red_sandstone
setblock -625 78 -475 minecraft:gray_concrete_powder
fill -625 79 -475 -625 83 -475 minecraft:air
fill -624 76 -475 -624 77 -475 minecraft:red_sandstone
setblock -624 78 -475 minecraft:black_concrete
fill -624 79 -475 -624 83 -475 minecraft:air
fill -623 76 -475 -623 77 -475 minecraft:red_sandstone
setblock -623 78 -475 minecraft:black_concrete
fill -623 79 -475 -623 83 -475 minecraft:air
fill -622 76 -475 -622 77 -475 minecraft:red_sandstone
setblock -622 78 -475 minecraft:coarse_dirt
fill -622 79 -475 -622 83 -475 minecraft:air
fill -621 76 -475 -621 77 -475 minecraft:red_sandstone
setblock -621 78 -475 minecraft:red_sand
fill -621 79 -475 -621 83 -475 minecraft:air
fill -627 76 -474 -627 77 -474 minecraft:red_sandstone
setblock -627 78 -474 minecraft:light_gray_concrete
fill -627 79 -474 -627 83 -474 minecraft:air
fill -626 76 -474 -626 77 -474 minecraft:red_sandstone
setblock -626 78 -474 minecraft:gray_concrete_powder
fill -626 79 -474 -626 83 -474 minecraft:air
fill -625 76 -474 -625 77 -474 minecraft:red_sandstone
setblock -625 78 -474 minecraft:black_concrete
fill -625 79 -474 -625 83 -474 minecraft:air
fill -624 76 -474 -624 77 -474 minecraft:red_sandstone
setblock -624 78 -474 minecraft:black_concrete
fill -624 79 -474 -624 83 -474 minecraft:air
fill -623 76 -474 -623 77 -474 minecraft:red_sandstone
setblock -623 78 -474 minecraft:black_concrete
fill -623 79 -474 -623 83 -474 minecraft:air
fill -622 76 -474 -622 77 -474 minecraft:red_sandstone
setblock -622 78 -474 minecraft:gray_concrete_powder
fill -622 79 -474 -622 83 -474 minecraft:air
fill -621 76 -474 -621 77 -474 minecraft:red_sandstone
setblock -621 78 -474 minecraft:light_gray_concrete
fill -621 79 -474 -621 83 -474 minecraft:air
fill -627 76 -473 -627 77 -473 minecraft:red_sandstone
setblock -627 78 -473 minecraft:light_gray_concrete
fill -627 79 -473 -627 83 -473 minecraft:air
fill -626 76 -473 -626 77 -473 minecraft:red_sandstone
setblock -626 78 -473 minecraft:black_concrete
fill -626 79 -473 -626 83 -473 minecraft:air
fill -625 76 -473 -625 77 -473 minecraft:red_sandstone
setblock -625 78 -473 minecraft:black_concrete
fill -625 79 -473 -625 83 -473 minecraft:air
fill -624 76 -473 -624 77 -473 minecraft:red_sandstone
setblock -624 78 -473 minecraft:black_concrete
fill -624 79 -473 -624 83 -473 minecraft:air
fill -623 76 -473 -623 77 -473 minecraft:red_sandstone
setblock -623 78 -473 minecraft:gray_concrete_powder
fill -623 79 -473 -623 83 -473 minecraft:air
fill -622 76 -473 -622 77 -473 minecraft:red_sandstone
setblock -622 78 -473 minecraft:black_concrete
fill -622 79 -473 -622 83 -473 minecraft:air
fill -621 76 -473 -621 77 -473 minecraft:red_sandstone
setblock -621 78 -473 minecraft:light_gray_concrete
fill -621 79 -473 -621 83 -473 minecraft:air
fill -627 76 -472 -627 77 -472 minecraft:red_sandstone
setblock -627 78 -472 minecraft:light_gray_concrete
fill -627 79 -472 -627 83 -472 minecraft:air
fill -626 76 -472 -626 77 -472 minecraft:red_sandstone
setblock -626 78 -472 minecraft:black_concrete
fill -626 79 -472 -626 83 -472 minecraft:air
fill -625 76 -472 -625 77 -472 minecraft:red_sandstone
setblock -625 78 -472 minecraft:black_concrete
fill -625 79 -472 -625 83 -472 minecraft:air
fill -624 76 -472 -624 77 -472 minecraft:red_sandstone
setblock -624 78 -472 minecraft:yellow_terracotta
fill -624 79 -472 -624 83 -472 minecraft:air
fill -623 76 -472 -623 77 -472 minecraft:red_sandstone
setblock -623 78 -472 minecraft:black_concrete
fill -623 79 -472 -623 83 -472 minecraft:air
fill -622 76 -472 -622 77 -472 minecraft:red_sandstone
setblock -622 78 -472 minecraft:black_concrete
fill -622 79 -472 -622 83 -472 minecraft:air
fill -621 76 -472 -621 77 -472 minecraft:red_sandstone
setblock -621 78 -472 minecraft:light_gray_concrete
fill -621 79 -472 -621 83 -472 minecraft:air
fill -627 76 -471 -627 77 -471 minecraft:red_sandstone
setblock -627 78 -471 minecraft:light_gray_concrete
fill -627 79 -471 -627 83 -471 minecraft:air
fill -626 76 -471 -626 77 -471 minecraft:red_sandstone
setblock -626 78 -471 minecraft:black_concrete
fill -626 79 -471 -626 83 -471 minecraft:air
fill -625 76 -471 -625 77 -471 minecraft:red_sandstone
setblock -625 78 -471 minecraft:red_sand
fill -625 79 -471 -625 83 -471 minecraft:air
fill -624 76 -471 -624 77 -471 minecraft:red_sandstone
setblock -624 78 -471 minecraft:yellow_terracotta
fill -624 79 -471 -624 83 -471 minecraft:air
fill -623 76 -471 -623 77 -471 minecraft:red_sandstone
setblock -623 78 -471 minecraft:black_concrete
fill -623 79 -471 -623 83 -471 minecraft:air
fill -622 77 -471 -622 77 -471 minecraft:red_sandstone
setblock -622 78 -471 minecraft:red_sand
fill -622 79 -471 -622 83 -471 minecraft:air
fill -621 77 -471 -621 77 -471 minecraft:red_sandstone
setblock -621 78 -471 minecraft:light_gray_concrete
fill -621 79 -471 -621 83 -471 minecraft:air
fill -627 76 -470 -627 77 -470 minecraft:red_sandstone
setblock -627 78 -470 minecraft:light_gray_concrete
fill -627 79 -470 -627 83 -470 minecraft:air
fill -626 76 -470 -626 77 -470 minecraft:red_sandstone
setblock -626 78 -470 minecraft:red_sand
fill -626 79 -470 -626 83 -470 minecraft:air
fill -625 77 -470 -625 77 -470 minecraft:red_sandstone
setblock -625 78 -470 minecraft:black_concrete
fill -625 79 -470 -625 83 -470 minecraft:air
fill -624 77 -470 -624 77 -470 minecraft:red_sandstone
setblock -624 78 -470 minecraft:yellow_terracotta
fill -624 79 -470 -624 83 -470 minecraft:air
fill -623 77 -470 -623 77 -470 minecraft:red_sandstone
setblock -623 78 -470 minecraft:red_sand
fill -623 79 -470 -623 83 -470 minecraft:air
fill -622 77 -470 -622 77 -470 minecraft:red_sandstone
setblock -622 78 -470 minecraft:gray_concrete_powder
fill -622 79 -470 -622 83 -470 minecraft:air
fill -621 77 -470 -621 77 -470 minecraft:red_sandstone
setblock -621 78 -470 minecraft:light_gray_concrete
fill -621 79 -470 -621 83 -470 minecraft:air
fill -627 76 -469 -627 77 -469 minecraft:red_sandstone
setblock -627 78 -469 minecraft:light_gray_concrete
fill -627 79 -469 -627 83 -469 minecraft:air
fill -626 76 -469 -626 77 -469 minecraft:red_sandstone
setblock -626 78 -469 minecraft:black_concrete
fill -626 79 -469 -626 83 -469 minecraft:air
fill -625 77 -469 -625 77 -469 minecraft:red_sandstone
setblock -625 78 -469 minecraft:black_concrete
fill -625 79 -469 -625 83 -469 minecraft:air
fill -624 77 -469 -624 77 -469 minecraft:red_sandstone
setblock -624 78 -469 minecraft:red_sand
fill -624 79 -469 -624 83 -469 minecraft:air
fill -623 77 -469 -623 77 -469 minecraft:red_sandstone
setblock -623 78 -469 minecraft:gray_concrete_powder
fill -623 79 -469 -623 83 -469 minecraft:air
setblock -622 78 -469 minecraft:black_concrete
fill -622 79 -469 -622 83 -469 minecraft:air
setblock -621 78 -469 minecraft:light_gray_concrete
fill -621 79 -469 -621 83 -469 minecraft:air
fill -627 76 -468 -627 77 -468 minecraft:red_sandstone
setblock -627 78 -468 minecraft:light_gray_concrete
fill -627 79 -468 -627 83 -468 minecraft:air
fill -626 76 -468 -626 77 -468 minecraft:red_sandstone
setblock -626 78 -468 minecraft:black_concrete
fill -626 79 -468 -626 83 -468 minecraft:air
fill -625 77 -468 -625 77 -468 minecraft:red_sandstone
setblock -625 78 -468 minecraft:red_sand
fill -625 79 -468 -625 83 -468 minecraft:air
fill -624 77 -468 -624 77 -468 minecraft:red_sandstone
setblock -624 78 -468 minecraft:gray_concrete_powder
fill -624 79 -468 -624 83 -468 minecraft:air
setblock -623 78 -468 minecraft:black_concrete
fill -623 79 -468 -623 83 -468 minecraft:air
setblock -622 78 -468 minecraft:red_sand
fill -622 79 -468 -622 83 -468 minecraft:air
setblock -621 78 -468 minecraft:light_gray_concrete
fill -621 79 -468 -621 83 -468 minecraft:air
fill -627 77 -467 -627 77 -467 minecraft:red_sandstone
setblock -627 78 -467 minecraft:light_gray_concrete
fill -627 79 -467 -627 83 -467 minecraft:air
setblock -626 78 -467 minecraft:red_sand
fill -626 79 -467 -626 83 -467 minecraft:air
setblock -625 78 -467 minecraft:gray_concrete_powder
fill -625 79 -467 -625 83 -467 minecraft:air
setblock -624 78 -467 minecraft:black_concrete
fill -624 79 -467 -624 83 -467 minecraft:air
fill -623 79 -467 -623 79 -467 minecraft:air
setblock -623 78 -467 minecraft:red_sand
fill -623 79 -467 -623 83 -467 minecraft:air
fill -622 79 -467 -622 79 -467 minecraft:air
setblock -622 78 -467 minecraft:black_concrete
fill -622 79 -467 -622 83 -467 minecraft:air
fill -621 79 -467 -621 80 -467 minecraft:air
setblock -621 78 -467 minecraft:light_gray_concrete
fill -621 79 -467 -621 83 -467 minecraft:air
setblock -627 78 -466 minecraft:red_sand
fill -627 79 -466 -627 83 -466 minecraft:air
setblock -626 78 -466 minecraft:coarse_dirt
fill -626 79 -466 -626 83 -466 minecraft:air
fill -625 79 -466 -625 79 -466 minecraft:air
setblock -625 78 -466 minecraft:black_concrete
fill -625 79 -466 -625 83 -466 minecraft:air
fill -624 79 -466 -624 79 -466 minecraft:air
setblock -624 78 -466 minecraft:red_sand
fill -624 79 -466 -624 83 -466 minecraft:air
fill -623 79 -466 -623 80 -466 minecraft:air
setblock -623 78 -466 minecraft:black_concrete
fill -623 79 -466 -623 83 -466 minecraft:air
fill -622 79 -466 -622 81 -466 minecraft:air
setblock -622 78 -466 minecraft:gray_concrete_powder
fill -622 79 -466 -622 83 -466 minecraft:air
fill -621 79 -466 -621 82 -466 minecraft:air
setblock -621 78 -466 minecraft:red_sand
fill -621 79 -466 -621 83 -466 minecraft:air
setblock -627 78 -465 minecraft:light_gray_concrete
fill -627 79 -465 -627 83 -465 minecraft:air
fill -626 79 -465 -626 79 -465 minecraft:air
setblock -626 78 -465 minecraft:black_concrete
fill -626 79 -465 -626 83 -465 minecraft:air
fill -625 79 -465 -625 79 -465 minecraft:air
setblock -625 78 -465 minecraft:red_sand
fill -625 79 -465 -625 83 -465 minecraft:air
fill -624 79 -465 -624 80 -465 minecraft:air
setblock -624 78 -465 minecraft:yellow_terracotta
fill -624 79 -465 -624 83 -465 minecraft:air
fill -623 79 -465 -623 81 -465 minecraft:air
setblock -623 78 -465 minecraft:gray_concrete_powder
fill -623 79 -465 -623 83 -465 minecraft:air
fill -622 79 -465 -622 83 -465 minecraft:air
setblock -622 78 -465 minecraft:red_sand
fill -622 79 -465 -622 83 -465 minecraft:air
fill -621 79 -465 -621 84 -465 minecraft:air
setblock -621 78 -465 minecraft:light_gray_concrete
fill -621 79 -465 -621 83 -465 minecraft:air
fill -627 79 -464 -627 79 -464 minecraft:air
setblock -627 78 -464 minecraft:light_gray_concrete
fill -626 79 -464 -626 79 -464 minecraft:air
setblock -626 78 -464 minecraft:red_sand
fill -625 79 -464 -625 80 -464 minecraft:air
setblock -625 78 -464 minecraft:black_concrete
fill -624 79 -464 -624 81 -464 minecraft:air
setblock -624 78 -464 minecraft:yellow_terracotta
fill -623 79 -464 -623 83 -464 minecraft:air
setblock -623 78 -464 minecraft:red_sand
fill -622 79 -464 -622 84 -464 minecraft:air
setblock -622 78 -464 minecraft:coarse_dirt
fill -621 79 -464 -621 85 -464 minecraft:air
setblock -621 78 -464 minecraft:light_gray_concrete
fill -627 79 -463 -627 82 -463 minecraft:air
setblock -627 78 -463 minecraft:light_gray_concrete
fill -626 79 -463 -626 83 -463 minecraft:air
setblock -626 78 -463 minecraft:black_concrete
fill -625 79 -463 -625 83 -463 minecraft:air
setblock -625 78 -463 minecraft:gray_concrete_powder
fill -624 79 -463 -624 85 -463 minecraft:air
setblock -624 78 -463 minecraft:red_sand
fill -623 79 -463 -623 87 -463 minecraft:air
setblock -623 78 -463 minecraft:black_concrete
fill -622 79 -463 -622 88 -463 minecraft:air
setblock -622 78 -463 minecraft:black_concrete
fill -621 79 -463 -621 89 -463 minecraft:air
setblock -621 78 -463 minecraft:light_gray_concrete
fill -627 79 -462 -627 86 -462 minecraft:air
setblock -627 78 -462 minecraft:light_gray_concrete
fill -626 79 -462 -626 87 -462 minecraft:air
setblock -626 78 -462 minecraft:gray_concrete_powder
fill -625 79 -462 -625 89 -462 minecraft:air
setblock -625 78 -462 minecraft:red_sand
fill -624 79 -462 -624 91 -462 minecraft:air
setblock -624 78 -462 minecraft:black_concrete
fill -623 79 -462 -623 91 -462 minecraft:air
setblock -623 78 -462 minecraft:black_concrete
fill -622 79 -462 -622 91 -462 minecraft:air
setblock -622 78 -462 minecraft:red_sand
fill -621 79 -462 -621 92 -462 minecraft:air
setblock -621 78 -462 minecraft:light_gray_concrete
fill -627 79 -461 -627 88 -461 minecraft:air
setblock -627 78 -461 minecraft:light_gray_concrete
fill -626 79 -461 -626 90 -461 minecraft:air
setblock -626 78 -461 minecraft:red_sand
fill -625 79 -461 -625 92 -461 minecraft:air
setblock -625 78 -461 minecraft:black_concrete
fill -624 79 -461 -624 93 -461 minecraft:air
setblock -624 78 -461 minecraft:black_concrete
fill -623 79 -461 -623 93 -461 minecraft:air
setblock -623 78 -461 minecraft:red_sand
fill -622 79 -461 -622 94 -461 minecraft:air
setblock -622 78 -461 minecraft:black_concrete
fill -621 79 -461 -621 94 -461 minecraft:air
setblock -621 78 -461 minecraft:light_gray_concrete
setblock -619 78 -502 minecraft:light_gray_concrete
setblock -619 82 -502 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 79 -502 minecraft:waxed_weathered_copper
setblock -618 80 -502 minecraft:waxed_weathered_copper_grate
setblock -618 81 -502 minecraft:waxed_weathered_copper
setblock -618 82 -502 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 78 -502 minecraft:light_gray_concrete
setblock -619 78 -501 minecraft:light_gray_concrete
setblock -619 82 -501 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 79 -501 minecraft:waxed_exposed_copper_grate
setblock -618 80 -501 minecraft:waxed_weathered_copper_grate
setblock -618 81 -501 minecraft:waxed_weathered_copper
setblock -618 82 -501 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 78 -501 minecraft:light_gray_concrete
setblock -619 78 -500 minecraft:light_gray_concrete
setblock -619 82 -500 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 79 -500 minecraft:waxed_exposed_copper_grate
setblock -618 80 -500 minecraft:waxed_weathered_copper_grate
setblock -618 81 -500 minecraft:waxed_weathered_copper
setblock -618 82 -500 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 78 -500 minecraft:light_gray_concrete
setblock -619 78 -499 minecraft:light_gray_concrete
setblock -619 82 -499 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 79 -499 minecraft:waxed_weathered_copper
setblock -618 80 -499 minecraft:waxed_weathered_copper_grate
setblock -618 81 -499 minecraft:waxed_weathered_copper
setblock -618 82 -499 minecraft:waxed_weathered_cut_copper_slab[type=bottom]
setblock -618 78 -499 minecraft:light_gray_concrete
fill -619 79 -502 -619 81 -502 minecraft:iron_bars
fill -619 79 -499 -619 81 -499 minecraft:iron_bars
setblock -619 79 -501 minecraft:spruce_stairs[facing=east]
setblock -619 79 -500 minecraft:spruce_stairs[facing=east]
fill -620 79 -503 -620 81 -503 minecraft:iron_bars
setblock -620 82 -503 minecraft:waxed_weathered_copper
summon minecraft:text_display -618.03 80.40 -500.50 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[90f,0f],text:'[{"text": "ROUTE 9\\n", "color": "#F0E68C", "bold": true}, {"text": "FUNK CITY - OLD TOWN\\n", "color": "#D0D0D0"}, {"text": "last bus 6:40", "color": "#A0A0A0"}]',background:1711276032,line_width:140,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]},brightness:{sky:15,block:15}}
setblock -627 78 -461 minecraft:mossy_stone_bricks
setblock -627 79 -461 minecraft:stone_bricks
setblock -627 80 -461 minecraft:stone_bricks
setblock -627 81 -461 minecraft:mossy_stone_bricks
setblock -627 82 -461 minecraft:stone_bricks
setblock -627 83 -461 minecraft:stone_bricks
setblock -627 84 -461 minecraft:mossy_stone_bricks
setblock -626 78 -461 minecraft:black_concrete
setblock -626 79 -461 minecraft:air
setblock -626 80 -461 minecraft:air
setblock -626 81 -461 minecraft:air
setblock -626 82 -461 minecraft:stone_bricks
setblock -626 83 -461 minecraft:mossy_stone_bricks
setblock -626 84 -461 minecraft:stone_bricks
setblock -625 78 -461 minecraft:black_concrete
setblock -625 79 -461 minecraft:air
setblock -625 80 -461 minecraft:air
setblock -625 81 -461 minecraft:air
setblock -625 82 -461 minecraft:air
setblock -625 83 -461 minecraft:stone_bricks
setblock -625 84 -461 minecraft:stone_bricks
setblock -624 78 -461 minecraft:black_concrete
setblock -624 79 -461 minecraft:air
setblock -624 80 -461 minecraft:air
setblock -624 81 -461 minecraft:air
setblock -624 82 -461 minecraft:air
setblock -624 83 -461 minecraft:stone_bricks
setblock -624 84 -461 minecraft:mossy_stone_bricks
setblock -623 78 -461 minecraft:black_concrete
setblock -623 79 -461 minecraft:air
setblock -623 80 -461 minecraft:air
setblock -623 81 -461 minecraft:air
setblock -623 82 -461 minecraft:air
setblock -623 83 -461 minecraft:mossy_stone_bricks
setblock -623 84 -461 minecraft:stone_bricks
setblock -622 78 -461 minecraft:black_concrete
setblock -622 79 -461 minecraft:air
setblock -622 80 -461 minecraft:air
setblock -622 81 -461 minecraft:air
setblock -622 82 -461 minecraft:mossy_stone_bricks
setblock -622 83 -461 minecraft:stone_bricks
setblock -622 84 -461 minecraft:stone_bricks
setblock -621 78 -461 minecraft:mossy_stone_bricks
setblock -621 79 -461 minecraft:stone_bricks
setblock -621 80 -461 minecraft:stone_bricks
setblock -621 81 -461 minecraft:mossy_stone_bricks
setblock -621 82 -461 minecraft:stone_bricks
setblock -621 83 -461 minecraft:stone_bricks
setblock -621 84 -461 minecraft:mossy_stone_bricks
setblock -627 78 -460 minecraft:stone_bricks
setblock -627 79 -460 minecraft:stone_bricks
setblock -627 80 -460 minecraft:stone_bricks
setblock -627 81 -460 minecraft:stone_bricks
setblock -627 82 -460 minecraft:stone_bricks
setblock -627 83 -460 minecraft:stone_bricks
setblock -627 84 -460 minecraft:stone_bricks
setblock -626 79 -460 minecraft:cracked_stone_bricks
setblock -626 80 -460 minecraft:spruce_planks
setblock -626 81 -460 minecraft:cracked_stone_bricks
setblock -626 82 -460 minecraft:stone_bricks
setblock -626 83 -460 minecraft:stone_bricks
setblock -626 84 -460 minecraft:stone_bricks
setblock -625 79 -460 minecraft:spruce_planks
setblock -625 80 -460 minecraft:cracked_stone_bricks
setblock -625 81 -460 minecraft:spruce_planks
setblock -625 82 -460 minecraft:cracked_stone_bricks
setblock -625 83 -460 minecraft:stone_bricks
setblock -625 84 -460 minecraft:stone_bricks
setblock -624 79 -460 minecraft:cracked_stone_bricks
setblock -624 80 -460 minecraft:spruce_planks
setblock -624 81 -460 minecraft:cracked_stone_bricks
setblock -624 82 -460 minecraft:spruce_planks
setblock -624 83 -460 minecraft:stone_bricks
setblock -624 84 -460 minecraft:stone_bricks
setblock -623 79 -460 minecraft:spruce_planks
setblock -623 80 -460 minecraft:cracked_stone_bricks
setblock -623 81 -460 minecraft:spruce_planks
setblock -623 82 -460 minecraft:cracked_stone_bricks
setblock -623 83 -460 minecraft:stone_bricks
setblock -623 84 -460 minecraft:stone_bricks
setblock -622 79 -460 minecraft:cracked_stone_bricks
setblock -622 80 -460 minecraft:spruce_planks
setblock -622 81 -460 minecraft:cracked_stone_bricks
setblock -622 82 -460 minecraft:stone_bricks
setblock -622 83 -460 minecraft:stone_bricks
setblock -622 84 -460 minecraft:stone_bricks
setblock -621 78 -460 minecraft:stone_bricks
setblock -621 79 -460 minecraft:stone_bricks
setblock -621 80 -460 minecraft:stone_bricks
setblock -621 81 -460 minecraft:stone_bricks
setblock -621 82 -460 minecraft:stone_bricks
setblock -621 83 -460 minecraft:stone_bricks
setblock -621 84 -460 minecraft:stone_bricks
setblock -627 78 -459 minecraft:smooth_stone
setblock -627 79 -459 minecraft:smooth_stone
setblock -627 80 -459 minecraft:smooth_stone
setblock -627 81 -459 minecraft:smooth_stone
setblock -627 82 -459 minecraft:smooth_stone
setblock -627 83 -459 minecraft:stone
setblock -627 84 -459 minecraft:stone
setblock -626 78 -459 minecraft:black_concrete
setblock -626 79 -459 minecraft:air
setblock -626 80 -459 minecraft:air
setblock -626 81 -459 minecraft:air
setblock -626 82 -459 minecraft:smooth_stone
setblock -626 83 -459 minecraft:stone
setblock -626 84 -459 minecraft:stone
setblock -625 78 -459 minecraft:gravel
setblock -625 79 -459 minecraft:air
setblock -625 80 -459 minecraft:air
setblock -625 81 -459 minecraft:air
setblock -625 82 -459 minecraft:air
setblock -625 83 -459 minecraft:stone
setblock -625 84 -459 minecraft:stone
setblock -624 78 -459 minecraft:black_concrete
setblock -624 79 -459 minecraft:air
setblock -624 80 -459 minecraft:air
setblock -624 81 -459 minecraft:air
setblock -624 82 -459 minecraft:air
setblock -624 83 -459 minecraft:stone
setblock -624 84 -459 minecraft:stone
setblock -623 78 -459 minecraft:black_concrete
setblock -623 79 -459 minecraft:air
setblock -623 80 -459 minecraft:air
setblock -623 81 -459 minecraft:air
setblock -623 82 -459 minecraft:air
setblock -623 83 -459 minecraft:stone
setblock -623 84 -459 minecraft:stone
setblock -622 78 -459 minecraft:black_concrete
setblock -622 79 -459 minecraft:air
setblock -622 80 -459 minecraft:air
setblock -622 81 -459 minecraft:air
setblock -622 82 -459 minecraft:smooth_stone
setblock -622 83 -459 minecraft:stone
setblock -622 84 -459 minecraft:stone
setblock -621 78 -459 minecraft:smooth_stone
setblock -621 79 -459 minecraft:smooth_stone
setblock -621 80 -459 minecraft:smooth_stone
setblock -621 81 -459 minecraft:smooth_stone
setblock -621 82 -459 minecraft:smooth_stone
setblock -621 83 -459 minecraft:stone
setblock -621 84 -459 minecraft:stone
setblock -627 78 -458 minecraft:smooth_stone
setblock -627 79 -458 minecraft:smooth_stone
setblock -627 80 -458 minecraft:smooth_stone
setblock -627 81 -458 minecraft:smooth_stone
setblock -627 82 -458 minecraft:smooth_stone
setblock -627 83 -458 minecraft:stone
setblock -627 84 -458 minecraft:stone
setblock -626 78 -458 minecraft:gravel
setblock -626 79 -458 minecraft:air
setblock -626 80 -458 minecraft:air
setblock -626 81 -458 minecraft:air
setblock -626 82 -458 minecraft:smooth_stone
setblock -626 83 -458 minecraft:stone
setblock -626 84 -458 minecraft:stone
setblock -625 78 -458 minecraft:black_concrete
setblock -625 79 -458 minecraft:air
setblock -625 80 -458 minecraft:air
setblock -625 81 -458 minecraft:air
setblock -625 82 -458 minecraft:air
setblock -625 83 -458 minecraft:stone
setblock -625 84 -458 minecraft:stone
setblock -624 78 -458 minecraft:black_concrete
setblock -624 79 -458 minecraft:air
setblock -624 80 -458 minecraft:air
setblock -624 81 -458 minecraft:air
setblock -624 82 -458 minecraft:air
setblock -624 83 -458 minecraft:stone
setblock -624 84 -458 minecraft:stone
setblock -623 78 -458 minecraft:black_concrete
setblock -623 79 -458 minecraft:air
setblock -623 80 -458 minecraft:air
setblock -623 81 -458 minecraft:air
setblock -623 82 -458 minecraft:air
setblock -623 83 -458 minecraft:stone
setblock -623 84 -458 minecraft:stone
setblock -622 78 -458 minecraft:black_concrete
setblock -622 79 -458 minecraft:air
setblock -622 80 -458 minecraft:air
setblock -622 81 -458 minecraft:air
setblock -622 82 -458 minecraft:smooth_stone
setblock -622 83 -458 minecraft:stone
setblock -622 84 -458 minecraft:stone
setblock -621 78 -458 minecraft:smooth_stone
setblock -621 79 -458 minecraft:smooth_stone
setblock -621 80 -458 minecraft:smooth_stone
setblock -621 81 -458 minecraft:smooth_stone
setblock -621 82 -458 minecraft:smooth_stone
setblock -621 83 -458 minecraft:stone
setblock -621 84 -458 minecraft:stone
setblock -627 78 -457 minecraft:smooth_stone
setblock -627 79 -457 minecraft:smooth_stone
setblock -627 80 -457 minecraft:smooth_stone
setblock -627 81 -457 minecraft:smooth_stone
setblock -627 82 -457 minecraft:smooth_stone
setblock -627 83 -457 minecraft:stone
setblock -627 84 -457 minecraft:stone
setblock -626 78 -457 minecraft:black_concrete
setblock -626 79 -457 minecraft:air
setblock -626 80 -457 minecraft:air
setblock -626 81 -457 minecraft:air
setblock -626 82 -457 minecraft:smooth_stone
setblock -626 83 -457 minecraft:stone
setblock -626 84 -457 minecraft:stone
setblock -625 78 -457 minecraft:black_concrete
setblock -625 79 -457 minecraft:air
setblock -625 80 -457 minecraft:air
setblock -625 81 -457 minecraft:air
setblock -625 82 -457 minecraft:air
setblock -625 83 -457 minecraft:stone
setblock -625 84 -457 minecraft:stone
setblock -624 78 -457 minecraft:black_concrete
setblock -624 79 -457 minecraft:air
setblock -624 80 -457 minecraft:air
setblock -624 81 -457 minecraft:air
setblock -624 82 -457 minecraft:air
setblock -624 83 -457 minecraft:stone
setblock -624 84 -457 minecraft:stone
setblock -623 78 -457 minecraft:black_concrete
setblock -623 79 -457 minecraft:air
setblock -623 80 -457 minecraft:air
setblock -623 81 -457 minecraft:air
setblock -623 82 -457 minecraft:air
setblock -623 83 -457 minecraft:stone
setblock -623 84 -457 minecraft:stone
setblock -622 78 -457 minecraft:gravel
setblock -622 79 -457 minecraft:air
setblock -622 80 -457 minecraft:air
setblock -622 81 -457 minecraft:air
setblock -622 82 -457 minecraft:smooth_stone
setblock -622 83 -457 minecraft:stone
setblock -622 84 -457 minecraft:stone
setblock -621 78 -457 minecraft:smooth_stone
setblock -621 79 -457 minecraft:smooth_stone
setblock -621 80 -457 minecraft:smooth_stone
setblock -621 81 -457 minecraft:smooth_stone
setblock -621 82 -457 minecraft:smooth_stone
setblock -621 83 -457 minecraft:stone
setblock -621 84 -457 minecraft:stone
setblock -627 78 -456 minecraft:smooth_stone
setblock -627 79 -456 minecraft:smooth_stone
setblock -627 80 -456 minecraft:smooth_stone
setblock -627 81 -456 minecraft:smooth_stone
setblock -627 82 -456 minecraft:smooth_stone
setblock -627 83 -456 minecraft:stone
setblock -627 84 -456 minecraft:stone
setblock -626 78 -456 minecraft:black_concrete
setblock -626 79 -456 minecraft:air
setblock -626 80 -456 minecraft:air
setblock -626 81 -456 minecraft:air
setblock -626 82 -456 minecraft:smooth_stone
setblock -626 83 -456 minecraft:stone
setblock -626 84 -456 minecraft:stone
setblock -625 78 -456 minecraft:black_concrete
setblock -625 79 -456 minecraft:air
setblock -625 80 -456 minecraft:air
setblock -625 81 -456 minecraft:air
setblock -625 82 -456 minecraft:air
setblock -625 83 -456 minecraft:stone
setblock -625 84 -456 minecraft:stone
setblock -624 78 -456 minecraft:black_concrete
setblock -624 79 -456 minecraft:air
setblock -624 80 -456 minecraft:air
setblock -624 81 -456 minecraft:air
setblock -624 82 -456 minecraft:air
setblock -624 83 -456 minecraft:stone
setblock -624 84 -456 minecraft:stone
setblock -623 78 -456 minecraft:gravel
setblock -623 79 -456 minecraft:air
setblock -623 80 -456 minecraft:air
setblock -623 81 -456 minecraft:air
setblock -623 82 -456 minecraft:air
setblock -623 83 -456 minecraft:stone
setblock -623 84 -456 minecraft:stone
setblock -622 78 -456 minecraft:black_concrete
setblock -622 79 -456 minecraft:air
setblock -622 80 -456 minecraft:air
setblock -622 81 -456 minecraft:air
setblock -622 82 -456 minecraft:smooth_stone
setblock -622 83 -456 minecraft:stone
setblock -622 84 -456 minecraft:stone
setblock -621 78 -456 minecraft:smooth_stone
setblock -621 79 -456 minecraft:smooth_stone
setblock -621 80 -456 minecraft:smooth_stone
setblock -621 81 -456 minecraft:smooth_stone
setblock -621 82 -456 minecraft:smooth_stone
setblock -621 83 -456 minecraft:stone
setblock -621 84 -456 minecraft:stone
setblock -627 78 -455 minecraft:smooth_stone
setblock -627 79 -455 minecraft:smooth_stone
setblock -627 80 -455 minecraft:smooth_stone
setblock -627 81 -455 minecraft:smooth_stone
setblock -627 82 -455 minecraft:smooth_stone
setblock -627 83 -455 minecraft:stone
setblock -627 84 -455 minecraft:stone
setblock -626 78 -455 minecraft:black_concrete
setblock -626 79 -455 minecraft:air
setblock -626 80 -455 minecraft:air
setblock -626 81 -455 minecraft:air
setblock -626 82 -455 minecraft:smooth_stone
setblock -626 83 -455 minecraft:stone
setblock -626 84 -455 minecraft:stone
setblock -625 78 -455 minecraft:black_concrete
setblock -625 79 -455 minecraft:air
setblock -625 80 -455 minecraft:air
setblock -625 81 -455 minecraft:air
setblock -625 82 -455 minecraft:air
setblock -625 83 -455 minecraft:stone
setblock -625 84 -455 minecraft:stone
setblock -624 78 -455 minecraft:gravel
setblock -624 79 -455 minecraft:air
setblock -624 80 -455 minecraft:air
setblock -624 81 -455 minecraft:air
setblock -624 82 -455 minecraft:air
setblock -624 83 -455 minecraft:stone
setblock -624 84 -455 minecraft:stone
setblock -623 78 -455 minecraft:black_concrete
setblock -623 79 -455 minecraft:air
setblock -623 80 -455 minecraft:air
setblock -623 81 -455 minecraft:air
setblock -623 82 -455 minecraft:air
setblock -623 83 -455 minecraft:stone
setblock -623 84 -455 minecraft:stone
setblock -622 78 -455 minecraft:black_concrete
setblock -622 79 -455 minecraft:air
setblock -622 80 -455 minecraft:air
setblock -622 81 -455 minecraft:air
setblock -622 82 -455 minecraft:smooth_stone
setblock -622 83 -455 minecraft:stone
setblock -622 84 -455 minecraft:stone
setblock -621 78 -455 minecraft:smooth_stone
setblock -621 79 -455 minecraft:smooth_stone
setblock -621 80 -455 minecraft:smooth_stone
setblock -621 81 -455 minecraft:smooth_stone
setblock -621 82 -455 minecraft:smooth_stone
setblock -621 83 -455 minecraft:stone
setblock -621 84 -455 minecraft:stone
setblock -627 78 -454 minecraft:smooth_stone
setblock -627 79 -454 minecraft:smooth_stone
setblock -627 80 -454 minecraft:smooth_stone
setblock -627 81 -454 minecraft:smooth_stone
setblock -627 82 -454 minecraft:smooth_stone
setblock -627 83 -454 minecraft:stone
setblock -627 84 -454 minecraft:stone
setblock -626 78 -454 minecraft:black_concrete
setblock -626 79 -454 minecraft:air
setblock -626 80 -454 minecraft:air
setblock -626 81 -454 minecraft:air
setblock -626 82 -454 minecraft:smooth_stone
setblock -626 83 -454 minecraft:stone
setblock -626 84 -454 minecraft:stone
setblock -625 78 -454 minecraft:gravel
setblock -625 79 -454 minecraft:air
setblock -625 80 -454 minecraft:air
setblock -625 81 -454 minecraft:air
setblock -625 82 -454 minecraft:air
setblock -625 83 -454 minecraft:stone
setblock -625 84 -454 minecraft:stone
setblock -624 78 -454 minecraft:black_concrete
setblock -624 79 -454 minecraft:air
setblock -624 80 -454 minecraft:air
setblock -624 81 -454 minecraft:air
setblock -624 82 -454 minecraft:air
setblock -624 83 -454 minecraft:stone
setblock -624 84 -454 minecraft:stone
setblock -623 78 -454 minecraft:black_concrete
setblock -623 79 -454 minecraft:air
setblock -623 80 -454 minecraft:air
setblock -623 81 -454 minecraft:air
setblock -623 82 -454 minecraft:air
setblock -623 83 -454 minecraft:stone
setblock -623 84 -454 minecraft:stone
setblock -622 78 -454 minecraft:black_concrete
setblock -622 79 -454 minecraft:air
setblock -622 80 -454 minecraft:air
setblock -622 81 -454 minecraft:air
setblock -622 82 -454 minecraft:smooth_stone
setblock -622 83 -454 minecraft:stone
setblock -622 84 -454 minecraft:stone
setblock -621 78 -454 minecraft:smooth_stone
setblock -621 79 -454 minecraft:smooth_stone
setblock -621 80 -454 minecraft:smooth_stone
setblock -621 81 -454 minecraft:smooth_stone
setblock -621 82 -454 minecraft:smooth_stone
setblock -621 83 -454 minecraft:stone
setblock -621 84 -454 minecraft:stone
setblock -627 78 -453 minecraft:smooth_stone
setblock -627 79 -453 minecraft:smooth_stone
setblock -627 80 -453 minecraft:smooth_stone
setblock -627 81 -453 minecraft:smooth_stone
setblock -627 82 -453 minecraft:smooth_stone
setblock -627 83 -453 minecraft:stone
setblock -627 84 -453 minecraft:stone
setblock -626 78 -453 minecraft:gravel
setblock -626 79 -453 minecraft:air
setblock -626 80 -453 minecraft:air
setblock -626 81 -453 minecraft:air
setblock -626 82 -453 minecraft:smooth_stone
setblock -626 83 -453 minecraft:stone
setblock -626 84 -453 minecraft:stone
setblock -625 78 -453 minecraft:black_concrete
setblock -625 79 -453 minecraft:air
setblock -625 80 -453 minecraft:air
setblock -625 81 -453 minecraft:air
setblock -625 82 -453 minecraft:air
setblock -625 83 -453 minecraft:stone
setblock -625 84 -453 minecraft:stone
setblock -624 78 -453 minecraft:black_concrete
setblock -624 79 -453 minecraft:air
setblock -624 80 -453 minecraft:air
setblock -624 81 -453 minecraft:air
setblock -624 82 -453 minecraft:air
setblock -624 83 -453 minecraft:stone
setblock -624 84 -453 minecraft:stone
setblock -623 78 -453 minecraft:black_concrete
setblock -623 79 -453 minecraft:air
setblock -623 80 -453 minecraft:air
setblock -623 81 -453 minecraft:air
setblock -623 82 -453 minecraft:air
setblock -623 83 -453 minecraft:stone
setblock -623 84 -453 minecraft:stone
setblock -622 78 -453 minecraft:black_concrete
setblock -622 79 -453 minecraft:air
setblock -622 80 -453 minecraft:air
setblock -622 81 -453 minecraft:air
setblock -622 82 -453 minecraft:smooth_stone
setblock -622 83 -453 minecraft:stone
setblock -622 84 -453 minecraft:stone
setblock -621 78 -453 minecraft:smooth_stone
setblock -621 79 -453 minecraft:smooth_stone
setblock -621 80 -453 minecraft:smooth_stone
setblock -621 81 -453 minecraft:smooth_stone
setblock -621 82 -453 minecraft:smooth_stone
setblock -621 83 -453 minecraft:stone
setblock -621 84 -453 minecraft:stone
setblock -627 78 -452 minecraft:smooth_stone
setblock -627 79 -452 minecraft:smooth_stone
setblock -627 80 -452 minecraft:smooth_stone
setblock -627 81 -452 minecraft:smooth_stone
setblock -627 82 -452 minecraft:smooth_stone
setblock -627 83 -452 minecraft:stone
setblock -627 84 -452 minecraft:stone
setblock -626 78 -452 minecraft:black_concrete
setblock -626 79 -452 minecraft:air
setblock -626 80 -452 minecraft:air
setblock -626 81 -452 minecraft:air
setblock -626 82 -452 minecraft:smooth_stone
setblock -626 83 -452 minecraft:stone
setblock -626 84 -452 minecraft:stone
setblock -625 78 -452 minecraft:black_concrete
setblock -625 79 -452 minecraft:air
setblock -625 80 -452 minecraft:air
setblock -625 81 -452 minecraft:air
setblock -625 82 -452 minecraft:air
setblock -625 83 -452 minecraft:stone
setblock -625 84 -452 minecraft:stone
setblock -624 78 -452 minecraft:black_concrete
setblock -624 79 -452 minecraft:air
setblock -624 80 -452 minecraft:air
setblock -624 81 -452 minecraft:air
setblock -624 82 -452 minecraft:air
setblock -624 83 -452 minecraft:stone
setblock -624 84 -452 minecraft:stone
setblock -623 78 -452 minecraft:black_concrete
setblock -623 79 -452 minecraft:air
setblock -623 80 -452 minecraft:air
setblock -623 81 -452 minecraft:air
setblock -623 82 -452 minecraft:air
setblock -623 83 -452 minecraft:stone
setblock -623 84 -452 minecraft:stone
setblock -622 78 -452 minecraft:gravel
setblock -622 79 -452 minecraft:air
setblock -622 80 -452 minecraft:air
setblock -622 81 -452 minecraft:air
setblock -622 82 -452 minecraft:smooth_stone
setblock -622 83 -452 minecraft:stone
setblock -622 84 -452 minecraft:stone
setblock -621 78 -452 minecraft:smooth_stone
setblock -621 79 -452 minecraft:smooth_stone
setblock -621 80 -452 minecraft:smooth_stone
setblock -621 81 -452 minecraft:smooth_stone
setblock -621 82 -452 minecraft:smooth_stone
setblock -621 83 -452 minecraft:stone
setblock -621 84 -452 minecraft:stone
summon minecraft:text_display -623.50 83.60 -461.03 {Tags:["funk_label","wf_sign"],billboard:"fixed",Rotation:[180f,0f],text:'[{"text": "ROUTE 9 TUNNEL\\n", "color": "#F0E68C", "bold": true}, {"text": "CLOSED BY ORDER - DOME WORKS", "color": "#FF9A8A"}]',background:1711276032,line_width:170,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.38f,0.38f,0.38f]},brightness:{sky:15,block:15}}
setblock -625 79 -457 minecraft:rail
summon minecraft:minecart -624.5 79 -456.5 {Tags:["wf_prop"]}
setblock -623 79 -455 minecraft:chest[facing=north]
setblock -622 79 -455 minecraft:barrel[facing=up]
summon minecraft:armor_stand -625.5 79 -452.5 {Tags:["wf_prop"],Invulnerable:1b,NoGravity:1b,ShowArms:1b,Rotation:[180f,0f],ArmorItems:[{},{},{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":{rgb:7031082}}},{id:"minecraft:leather_helmet",count:1,components:{"minecraft:dyed_color":{rgb:3355443}}}]}
setblock -624 79 -451 minecraft:lantern[hanging=false]
