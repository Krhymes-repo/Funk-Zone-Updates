# Centers v2 / Marts v1: the old clinic and mart counters are gone (Nurse Joy and the Cities & Structures cashiers took
# over), so a leftover marker for one of those shops retires itself and its old clerk instead of spawning it again.
execute if data storage funkcity:state {centersV2:1} if function funkcity:spawn/shop_retired run return run function funkcity:spawn/shop_retire with entity @s data
# Each shop marker owns exactly one clerk, tagged fc<id> (ids handed out from 900000 like the roaming Pokemon). The clerk
# is found wherever it has been shoved to (clerks standing in a counter get pushed out when the area loads), pulled back
# to its spot, and never doubled. Before this, a clerk pushed past 2.5 blocks was forgotten and a second one spawned.
execute unless data entity @s data.uid store result entity @s data.uid int 1 run scoreboard players add #petuid funk.uid 1
function funkcity:spawn/shop_k with entity @s data
