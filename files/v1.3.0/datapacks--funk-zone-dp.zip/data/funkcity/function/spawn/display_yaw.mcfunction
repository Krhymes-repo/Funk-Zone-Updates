# a display Pokemon whose marker names a yaw (e.g. the Plaza Corviknight baskets) turns to face it
$execute as @e[type=cobblemon:pokemon,distance=..1.5,tag=funk_disp] at @s run tp @s ~ ~ ~ $(yaw) 0
