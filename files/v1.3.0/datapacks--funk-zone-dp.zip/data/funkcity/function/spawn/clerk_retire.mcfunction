$execute as @e[type=cobblemon:npc,tag=fk$(uid)] run function funkcity:spawn/vanish
kill @s
