$execute as @e[type=cobbledollars:cobble_merchant,tag=fs_$(shop),distance=..8] run function funkcity:spawn/vanish
kill @s
