execute if data entity @s data{shop:"clinic_downtown"} run return 1
execute if data entity @s data{shop:"clinic_groove"} run return 1
execute if data entity @s data{shop:"clinic_garden"} run return 1
execute if data entity @s data{shop:"clinic_poison"} run return 1
execute if data entity @s data{shop:"clinic_rock"} run return 1
execute if data entity @s data{shop:"clinic_harbor"} run return 1
execute if data entity @s data{shop:"clinic_fire"} run return 1
execute if data entity @s data{shop:"clinic_power"} run return 1
execute if data entity @s data{shop:"mart_downtown"} run return 1
execute if data entity @s data{shop:"mart_groove"} run return 1
execute if data entity @s data{shop:"mart_garden"} run return 1
execute if data entity @s data{shop:"mart_poison"} run return 1
execute if data entity @s data{shop:"mart_rock"} run return 1
execute if data entity @s data{shop:"mart_harbor"} run return 1
execute if data entity @s data{shop:"mart_fire"} run return 1
execute if data entity @s data{shop:"mart_power"} run return 1
return 0
