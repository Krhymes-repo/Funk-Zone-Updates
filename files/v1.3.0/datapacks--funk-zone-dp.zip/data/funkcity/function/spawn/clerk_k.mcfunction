$execute store result score #n funk.tmp if entity @e[type=cobblemon:npc,tag=fk$(uid)]
$execute if score #n funk.tmp matches 2.. as @e[type=cobblemon:npc,tag=fk$(uid),sort=furthest,limit=1] run function funkcity:spawn/vanish
$execute as @e[type=cobblemon:npc,tag=fk$(uid)] unless entity @s[distance=..0.4] run tp @s ~ ~ ~ $(yaw) 0
$execute if entity @e[type=cobblemon:npc,tag=fk$(uid)] run return 0
$function funkcity:clerk/$(role) with entity @s data
