# A Cities & Structures NPC behind a counter (Pokemon Centers v2 / Poke Marts v1): Nurse Joy, or a cashier whose fs_<shop>
# tag opens the Funk shop. Each marker owns one NPC, tagged fk<uid>: found, pulled back to its spot, never doubled.
# the Pokemon Centers' side-counter cashiers were dropped (their medicine is sold at the district Poke Mart): one left in an
# already-rebuilt world removes itself and its NPC
execute if data entity @s data.uid if function funkcity:spawn/clinic_shop run return run function funkcity:spawn/clerk_retire with entity @s data
execute unless data entity @s data.uid store result entity @s data.uid int 1 run scoreboard players add #petuid funk.uid 1
function funkcity:spawn/clerk_k with entity @s data
