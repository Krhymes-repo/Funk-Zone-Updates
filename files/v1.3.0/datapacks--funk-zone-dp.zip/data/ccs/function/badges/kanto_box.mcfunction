# Funk Zone: no Kanto badge box - Funk City has its own badge case.
