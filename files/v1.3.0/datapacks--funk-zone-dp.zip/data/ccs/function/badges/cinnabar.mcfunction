# Funk Zone: Kanto gyms out in the Wilds are exhibition matches - the real badges come from the Funk City gym challenge.
cobbledollars give @s 7000
give @s cobblemon:charcoal_stick 1
give @s cobblemon:rare_candy 1
tellraw @s ["",{"text":"[Kanto Exhibition] ","color":"gold"},{"text":"Blaine's badge stays with the Kanto League - your Funk City badges are the ones that count. Take this instead: ","color":"yellow"},{"text":"7,000 CobbleDollars, a Charcoal Stick and a Rare Candy.","color":"white"}]
