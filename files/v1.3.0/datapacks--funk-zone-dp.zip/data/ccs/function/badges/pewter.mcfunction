# Funk Zone: Kanto gyms out in the Wilds are exhibition matches - the real badges come from the Funk City gym challenge.
cobbledollars give @s 4000
give @s cobblemon:hard_stone 1
give @s cobblemon:rare_candy 1
tellraw @s ["",{"text":"[Kanto Exhibition] ","color":"gold"},{"text":"Brock's badge stays with the Kanto League - your Funk City badges are the ones that count. Take this instead: ","color":"yellow"},{"text":"4,000 CobbleDollars, a Hard Stone and a Rare Candy.","color":"white"}]
