# Funk Zone: Kanto gyms out in the Wilds are exhibition matches - the real badges come from the Funk City gym challenge.
cobbledollars give @s 6500
give @s cobblemon:twisted_spoon 1
give @s cobblemon:rare_candy 1
tellraw @s ["",{"text":"[Kanto Exhibition] ","color":"gold"},{"text":"Sabrina's badge stays with the Kanto League - your Funk City badges are the ones that count. Take this instead: ","color":"yellow"},{"text":"6,500 CobbleDollars, a Twisted Spoon and a Rare Candy.","color":"white"}]
