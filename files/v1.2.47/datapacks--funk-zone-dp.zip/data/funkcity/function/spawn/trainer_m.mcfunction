$rctmod trainer summon $(id) ~ ~ ~ {attributes:[{id:"minecraft:generic.movement_speed",base:0.0d},{id:"minecraft:generic.knockback_resistance",base:1.0d}],Tags:["funk_still"],Persistent:1b}
