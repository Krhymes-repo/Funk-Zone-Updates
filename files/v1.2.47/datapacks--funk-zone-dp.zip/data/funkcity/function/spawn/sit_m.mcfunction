$execute unless entity @e[type=minecraft:item_display,tag=fsv$(uid)] run summon minecraft:item_display ~ ~-0.2 ~ {Tags:["funk_npc","fsv$(uid)"],Rotation:[$(yaw)f,0f]}
$rctmod trainer summon $(base)_t$(tier) ~ ~0.3 ~ {attributes:[{id:"minecraft:generic.movement_speed",base:0.0d},{id:"minecraft:generic.knockback_resistance",base:1.0d}],NoAI:1b,Tags:["funk_sit","fs$(uid)","funk_talk","ft_$(td)"],Rotation:[$(yaw)f,0f]}
function funkcity:spawn/sit_fix with entity @s data
