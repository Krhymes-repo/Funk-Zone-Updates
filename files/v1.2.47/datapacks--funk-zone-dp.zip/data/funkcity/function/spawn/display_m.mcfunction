# a display Pokemon (statue-like, no AI). Tagged funk_disp straight away, in the same reach as the check above: before,
# one that landed between 1.2 and 1.5 blocks out kept only funk_pet, the spawn guard took it for a stray, and the
# marker made a new one every few seconds.
$spawnpokemonat ~ ~ ~ $(props) uncatchable=yes
execute as @e[type=cobblemon:pokemon,distance=..1.5,tag=!funk_disp,sort=nearest,limit=1] run data merge entity @s {Unbattleable:1b,NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Tags:["funk_disp","funk_seen"]}
