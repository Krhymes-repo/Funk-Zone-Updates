execute if data entity @s data.yaw run return run function funkcity:spawn/exotic_y with entity @s data
$funkfrontier exotic display $(slot)
