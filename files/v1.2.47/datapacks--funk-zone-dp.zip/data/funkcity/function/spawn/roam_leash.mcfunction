$execute as @e[type=rctmod:trainer,tag=fr$(uid),tag=!fa_away] unless entity @s[distance=..$(r)] run tp @s ~ ~ ~
