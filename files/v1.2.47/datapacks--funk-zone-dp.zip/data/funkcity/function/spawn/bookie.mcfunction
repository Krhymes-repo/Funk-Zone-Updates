execute store result score #n funk.tmp if entity @e[type=minecraft:villager,tag=funk_bookie,distance=..2.5]
execute if score #n funk.tmp matches 2.. run kill @e[type=minecraft:villager,tag=funk_bookie,distance=..2.5,sort=furthest,limit=1]
execute if entity @e[type=minecraft:villager,tag=funk_bookie,distance=..2.5] run return 0
summon minecraft:villager ~ ~ ~ {attributes:[{id:"minecraft:generic.movement_speed",base:0.0d},{id:"minecraft:generic.knockback_resistance",base:1.0d}],Invulnerable:1b,Silent:1b,PersistenceRequired:1b,Tags:["funk_npc","funk_bookie"],VillagerData:{profession:"minecraft:cartographer",level:5,type:"minecraft:swamp"},Offers:{Recipes:[]},CustomName:'{"text":"Bookie","color":"gold"}',CustomNameVisible:1b}
