# Free-roaming Pokemon. Each marker gets its own id (numbered from 900000, past every built-in one) and keeps its
# Pokemon on a 10-block leash like the shop pets - before, any Pokemon wandering 10 blocks off got a second one spawned.
execute unless data entity @s data.uid store result entity @s data.uid int 1 run scoreboard players add #petuid funk.uid 1
execute unless data entity @s data.r run data modify entity @s data.r set value 10
function funkcity:spawn/shoppet with entity @s data
