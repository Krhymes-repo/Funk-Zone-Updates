execute store result score #has funk.tmp run function funkcity:spawn/bz_has with entity @s data
execute if score #has funk.tmp matches 0 run return run function funkcity:spawn/bz_new
execute store result score #t funk.tmp run data get entity @s data.t
scoreboard players add #t funk.tmp 1
execute store result entity @s data.t int 1 run scoreboard players get #t funk.tmp
execute if score #t funk.tmp matches 300.. unless entity @a[distance=..8] run function funkcity:spawn/bz_clear with entity @s data
