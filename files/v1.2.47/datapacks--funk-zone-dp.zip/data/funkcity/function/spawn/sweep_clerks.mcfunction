# retired: Funk Frontier removes stray clerks (SpawnGuard), and each shop marker now tracks its own clerk
