data modify entity @s data.t set value 0
execute store result entity @s data.c int 1 run random value 0..2
execute store result entity @s data.k int 1 run random value 0..1
function funkcity:spawn/bz_m with entity @s data
