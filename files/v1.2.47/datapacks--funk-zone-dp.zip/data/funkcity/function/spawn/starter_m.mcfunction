$execute if data storage funkcity:starters taken.$(key) run return run kill @e[type=cobblemon:pokemon,tag=fp$(uid)]
function funkcity:spawn/shoppet with entity @s data
$execute as @e[type=cobblemon:pokemon,tag=fp$(uid)] run function funkcity:spawn/root
