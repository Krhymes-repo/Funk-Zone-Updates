$execute if entity @e[type=cobblemon:pokemon,tag=fp$(uid)] run return 1
return 0
