# a clerk left over from a shop that has since changed (the Galleria garden shop became TM Records): send it off so the right one comes
$execute as @e[type=cobbledollars:cobble_merchant,tag=fc$(uid),tag=!fs_$(shop)] run function funkcity:spawn/vanish
# adopt this shop's existing clerk if it hasn't got an owner yet (worlds from before the ids)
$execute unless entity @e[type=cobbledollars:cobble_merchant,tag=fc$(uid)] as @e[type=cobbledollars:cobble_merchant,tag=fs_$(shop),tag=!fc_t,distance=..3,sort=nearest,limit=1] run tag @s add fc$(uid)
$tag @e[type=cobbledollars:cobble_merchant,tag=fc$(uid),tag=!fc_t] add fc_t
$execute store result score #n funk.tmp if entity @e[type=cobbledollars:cobble_merchant,tag=fc$(uid)]
$execute if score #n funk.tmp matches 2.. as @e[type=cobbledollars:cobble_merchant,tag=fc$(uid),sort=furthest,limit=1] run function funkcity:spawn/vanish
$execute as @e[type=cobbledollars:cobble_merchant,tag=fc$(uid)] unless entity @s[distance=..0.4] run tp @s ~ ~ ~
$execute if entity @e[type=cobbledollars:cobble_merchant,tag=fc$(uid)] run return 0
$function funkcity:shop/$(shop)
$tag @e[type=cobbledollars:cobble_merchant,tag=fs_$(shop),tag=!fc_t,distance=..0.6,sort=nearest,limit=1] add fc$(uid)
$tag @e[type=cobbledollars:cobble_merchant,tag=fc$(uid),tag=!fc_t] add fc_t
