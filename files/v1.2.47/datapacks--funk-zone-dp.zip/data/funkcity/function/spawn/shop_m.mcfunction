$function funkcity:shop/$(shop)
