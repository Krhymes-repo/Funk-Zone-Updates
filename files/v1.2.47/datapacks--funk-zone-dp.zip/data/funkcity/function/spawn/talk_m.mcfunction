$execute store result score #n funk.tmp if entity @e[type=rctmod:trainer,tag=funk_talk,tag=ft_$(role),distance=..1.2]
$execute if score #n funk.tmp matches 2.. as @e[type=rctmod:trainer,tag=funk_talk,tag=ft_$(role),distance=..1.2,sort=furthest,limit=1] run function funkcity:spawn/vanish
$execute as @e[type=rctmod:trainer,tag=funk_talk,tag=ft_$(role),distance=..1.2,sort=nearest,limit=1] unless entity @s[distance=..0.4] run tp @s ~ ~ ~
$execute if entity @e[type=rctmod:trainer,tag=funk_talk,tag=ft_$(role),distance=..1.2] run return 0
execute if data entity @s data{name:""} run return run function funkcity:spawn/talk_plain with entity @s data
function funkcity:spawn/talk_named with entity @s data
