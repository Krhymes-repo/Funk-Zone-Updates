execute if data entity @s data{fx:"spooky"} run particle minecraft:soul ~ ~1 ~ 9 1.5 9 0.01 10
execute if data entity @s data{fx:"spooky"} run particle minecraft:witch ~ ~1.5 ~ 9 2 9 0 6
execute if data entity @s data{fx:"toxic"} run particle minecraft:witch ~ ~0.6 ~ 10 0.6 10 0 10
execute if data entity @s data{fx:"toxic"} run particle minecraft:dragon_breath ~ ~0.4 ~ 8 0.3 8 0.005 6
execute if data entity @s data{fx:"steam"} run particle minecraft:campfire_cosy_smoke ~ ~0.4 ~ 7 0.2 7 0.015 5
execute if data entity @s data{fx:"steam"} run particle minecraft:lava ~ ~0.5 ~ 7 0.2 7 0 2
execute if data entity @s data{fx:"psychic"} run particle minecraft:portal ~ ~1.5 ~ 8 1.5 8 0.4 25
execute if data entity @s data{fx:"psychic"} run particle minecraft:end_rod ~ ~2 ~ 8 1.5 8 0.01 3
