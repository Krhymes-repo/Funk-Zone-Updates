function funkcity:spawn/rtrainer_m with entity @s data
