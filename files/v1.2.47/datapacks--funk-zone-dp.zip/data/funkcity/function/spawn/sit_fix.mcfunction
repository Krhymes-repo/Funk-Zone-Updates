$execute as @e[type=rctmod:trainer,tag=fs$(uid)] unless predicate funkcity:riding run ride @s mount @e[type=minecraft:item_display,tag=fsv$(uid),limit=1,sort=nearest]
