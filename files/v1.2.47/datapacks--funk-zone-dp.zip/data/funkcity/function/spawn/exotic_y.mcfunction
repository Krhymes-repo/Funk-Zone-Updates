$funkfrontier exotic display $(slot) $(yaw)
