$execute if entity @e[type=rctmod:trainer,tag=fr$(uid)] run return 1
return 0
