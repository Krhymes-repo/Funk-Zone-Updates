$execute if entity @e[type=rctmod:trainer,tag=frt$(uid)] run return 0
$rctmod trainer summon $(id) ~ ~ ~ {attributes:[{id:"minecraft:generic.movement_speed",base:0.0d},{id:"minecraft:generic.knockback_resistance",base:1.0d}],Tags:["funk_route","frt$(uid)"],Persistent:1b}
