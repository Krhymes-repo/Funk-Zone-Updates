$execute if data storage funkcity:starters taken.$(key) run return run kill @e[tag=fsb$(uid)]
$execute as @e[type=minecraft:item_display,tag=fsb$(uid)] at @s run tp @s ~ ~ ~ facing -49.5 ~ 13.5
$execute if entity @e[type=minecraft:item_display,tag=fsb$(uid)] run return 0
$summon minecraft:item_display ~ ~0.02 ~ {item:{id:"$(ball)",count:1},item_display:"ground",Tags:["funk_npc","fsb$(uid)"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
$summon minecraft:interaction ~ ~ ~ {width:0.5f,height:0.4f,response:1b,Tags:["funk_npc","funk_sball","fsk_$(key)","fsb$(uid)"]}
$execute as @e[type=minecraft:item_display,tag=fsb$(uid)] at @s run tp @s ~ ~ ~ facing -49.5 ~ 13.5
