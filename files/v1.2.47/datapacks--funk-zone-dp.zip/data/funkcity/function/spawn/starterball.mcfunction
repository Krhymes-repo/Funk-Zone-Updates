function funkcity:spawn/starterball_m with entity @s data
