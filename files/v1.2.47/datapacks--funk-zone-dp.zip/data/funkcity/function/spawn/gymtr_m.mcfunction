$execute if entity @e[type=rctmod:trainer,tag=$(gt)] run return 0
$rctmod trainer summon $(base)_t$(tier) ~ ~ ~ {attributes:[{id:"minecraft:generic.movement_speed",base:0.0d},{id:"minecraft:generic.knockback_resistance",base:1.0d}],Tags:["funk_gymtr","$(gt)"],Persistent:1b}
