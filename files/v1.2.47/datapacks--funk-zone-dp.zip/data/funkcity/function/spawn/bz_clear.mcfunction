$tp @e[type=rctmod:trainer,tag=fb$(uid)] ~ -100 ~
$kill @e[type=rctmod:trainer,tag=fb$(uid)]
data modify entity @s data.t set value 0
