function funkcity:spawn/starter_m with entity @s data
