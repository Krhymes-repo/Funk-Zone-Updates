$execute as @e[type=cobblemon:pokemon,tag=fp$(uid)] unless entity @s[distance=..$(r)] run tp @s ~ ~ ~
