execute store result score #has funk.tmp run function funkcity:spawn/sit_has with entity @s data
execute if score #has funk.tmp matches 1 run return run function funkcity:spawn/sit_fix with entity @s data
scoreboard players set #cap funk.tmp 0
execute store result score #cap funk.tmp run rctmod player get level_cap @p
scoreboard players set #tier funk.tmp 1
execute if score #cap funk.tmp matches 30.. run scoreboard players set #tier funk.tmp 2
execute if score #cap funk.tmp matches 40.. run scoreboard players set #tier funk.tmp 3
execute if score #cap funk.tmp matches 50.. run scoreboard players set #tier funk.tmp 4
execute if score #cap funk.tmp matches 60.. run scoreboard players set #tier funk.tmp 5
execute if score #cap funk.tmp matches 70.. run scoreboard players set #tier funk.tmp 6
execute store result entity @s data.tier int 1 run scoreboard players get #tier funk.tmp
function funkcity:spawn/sit_m with entity @s data
