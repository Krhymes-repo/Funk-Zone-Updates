execute if entity @e[type=minecraft:interaction,tag=funk_wtp,distance=..1.5] run return 0
summon minecraft:interaction ~ ~ ~ {width:1.4f,height:2.2f,response:1b,Tags:["funk_wtp","funk_npc"]}
summon minecraft:text_display ~ ~2.6 ~ {billboard:"center",alignment:"center",Tags:["funk_npc"],text:'{"text":"Who\'s That Pokemon?\\nRight-click to play!","color":"gold"}',background:1426063360}
