execute store result score #has funk.tmp run function funkcity:spawn/shoppet_has with entity @s data
execute if score #has funk.tmp matches 1 run return run function funkcity:spawn/shoppet_leash with entity @s data
function funkcity:spawn/shoppet_m with entity @s data
