attribute @s minecraft:generic.movement_speed base set 0
attribute @s minecraft:generic.flying_speed base set 0
attribute @s minecraft:generic.knockback_resistance base set 1
data merge entity @s {Motion:[0d,0d,0d]}
