$rctmod trainer summon $(base)_t$(tier) ~ ~ ~ {Tags:["funk_roam","fr$(uid)","$(gt)","funk_talk","ft_$(td)"]}
