$execute if entity @e[type=rctmod:trainer,tag=fs$(uid)] run return 1
return 0
