execute if entity @e[type=rctmod:trainer,distance=..1.5] run return 0
scoreboard players set #cap funk.tmp 0
execute store result score #cap funk.tmp run rctmod player get level_cap @p
scoreboard players set #tier funk.tmp 1
execute if score #cap funk.tmp matches 30.. run scoreboard players set #tier funk.tmp 2
execute if score #cap funk.tmp matches 40.. run scoreboard players set #tier funk.tmp 3
execute if score #cap funk.tmp matches 50.. run scoreboard players set #tier funk.tmp 4
execute if score #cap funk.tmp matches 60.. run scoreboard players set #tier funk.tmp 5
execute if score #cap funk.tmp matches 70.. run scoreboard players set #tier funk.tmp 6
execute store result entity @s data.tier int 1 run scoreboard players get #tier funk.tmp
execute if data entity @s data.gt run return run function funkcity:spawn/gymtr_m with entity @s data
function funkcity:spawn/tiered_m with entity @s data
