execute store result score #n funk.tmp if entity @e[type=rctmod:trainer,distance=..4]
execute if score #n funk.tmp matches 2.. run kill @e[type=rctmod:trainer,distance=..4,sort=furthest,limit=1]
execute store result score #n funk.tmp if entity @e[type=minecraft:text_display,tag=funk_prof_label,distance=..4]
execute if score #n funk.tmp matches 2.. run kill @e[type=minecraft:text_display,tag=funk_prof_label,distance=..4,sort=furthest,limit=1]
execute store result score #n funk.tmp if entity @e[type=minecraft:interaction,tag=funk_prof,distance=..4]
execute if score #n funk.tmp matches 2.. run kill @e[type=minecraft:interaction,tag=funk_prof,distance=..4,sort=furthest,limit=1]
execute unless entity @e[type=rctmod:trainer,distance=..4] run rctmod trainer summon funk_professor ~ ~ ~ {attributes:[{id:"minecraft:generic.movement_speed",base:0.0d},{id:"minecraft:generic.knockback_resistance",base:1.0d}],Tags:["funk_still"],Persistent:1b,Rotation:[0f,0f]}
execute if entity @e[type=minecraft:interaction,tag=funk_prof,distance=..4] run return 0
summon minecraft:interaction ~ ~ ~ {width:1.1f,height:2.1f,response:1b,Tags:["funk_prof","funk_npc"]}
summon minecraft:text_display ~ ~2.4 ~ {billboard:"center",alignment:"center",Tags:["funk_npc","funk_prof_label"],text:'{"text":"Professor Cedar\\nTalk to me to choose your partner!","color":"aqua"}',background:1426063360}
