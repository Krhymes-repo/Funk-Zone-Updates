$execute if entity @e[type=rctmod:trainer,tag=fb$(uid)] run return 1
return 0
