function funkcity:spawn/talk_m with entity @s data
