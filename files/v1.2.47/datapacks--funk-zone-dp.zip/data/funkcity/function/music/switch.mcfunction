stopsound @s ambient funkcity:music.downtown
stopsound @s ambient funkcity:music.groove
stopsound @s ambient funkcity:music.harbor
stopsound @s ambient funkcity:music.garden
stopsound @s ambient funkcity:music.power
stopsound @s ambient funkcity:music.plaza
scoreboard players operation @s funk.mdist = #d funk.tmp
execute if score #d funk.tmp matches 1 run playsound funkcity:music.downtown ambient @s ~ ~ ~ 10000 1 1
execute if score #d funk.tmp matches 2 run playsound funkcity:music.groove ambient @s ~ ~ ~ 10000 1 1
execute if score #d funk.tmp matches 3 run playsound funkcity:music.harbor ambient @s ~ ~ ~ 10000 1 1
execute if score #d funk.tmp matches 4 run playsound funkcity:music.garden ambient @s ~ ~ ~ 10000 1 1
execute if score #d funk.tmp matches 5 run playsound funkcity:music.power ambient @s ~ ~ ~ 10000 1 1
execute if score #d funk.tmp matches 6 run playsound funkcity:music.plaza ambient @s ~ ~ ~ 10000 1 1
execute if score #d funk.tmp matches 1 run scoreboard players set @s funk.mt 117
execute if score #d funk.tmp matches 2 run scoreboard players set @s funk.mt 102
execute if score #d funk.tmp matches 3 run scoreboard players set @s funk.mt 124
execute if score #d funk.tmp matches 4 run scoreboard players set @s funk.mt 129
execute if score #d funk.tmp matches 5 run scoreboard players set @s funk.mt 97
execute if score #d funk.tmp matches 6 run scoreboard players set @s funk.mt 107
