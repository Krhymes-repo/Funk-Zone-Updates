scoreboard players set #d funk.tmp 6
execute if biome ~ ~ ~ funkcity:plaza run scoreboard players set #d funk.tmp 6
execute if biome ~ ~ ~ funkcity:outskirts run scoreboard players set #d funk.tmp 6
execute if biome ~ ~ ~ funkcity:rock run scoreboard players set #d funk.tmp 6
execute if biome ~ ~ ~ funkcity:wild_rock run scoreboard players set #d funk.tmp 6
execute if biome ~ ~ ~ funkcity:harbor run scoreboard players set #d funk.tmp 3
execute if biome ~ ~ ~ funkcity:wild_harbor run scoreboard players set #d funk.tmp 3
execute if biome ~ ~ ~ funkcity:power run scoreboard players set #d funk.tmp 5
execute if biome ~ ~ ~ funkcity:wild_power run scoreboard players set #d funk.tmp 5
execute if biome ~ ~ ~ funkcity:garden run scoreboard players set #d funk.tmp 4
execute if biome ~ ~ ~ funkcity:wild_garden run scoreboard players set #d funk.tmp 4
execute if biome ~ ~ ~ funkcity:poison run scoreboard players set #d funk.tmp 2
execute if biome ~ ~ ~ funkcity:wild_poison run scoreboard players set #d funk.tmp 2
execute if biome ~ ~ ~ funkcity:groove run scoreboard players set #d funk.tmp 2
execute if biome ~ ~ ~ funkcity:wild_groove run scoreboard players set #d funk.tmp 2
execute if biome ~ ~ ~ funkcity:fire run scoreboard players set #d funk.tmp 5
execute if biome ~ ~ ~ funkcity:wild_fire run scoreboard players set #d funk.tmp 5
execute if biome ~ ~ ~ funkcity:downtown run scoreboard players set #d funk.tmp 1
execute if biome ~ ~ ~ funkcity:wild_downtown run scoreboard players set #d funk.tmp 1
execute if biome ~ ~ ~ funkcity:route_1 run scoreboard players set #d funk.tmp 6
execute if biome ~ ~ ~ funkcity:route_2 run scoreboard players set #d funk.tmp 3
execute if biome ~ ~ ~ funkcity:route_3 run scoreboard players set #d funk.tmp 5
execute if biome ~ ~ ~ funkcity:route_4 run scoreboard players set #d funk.tmp 4
execute if biome ~ ~ ~ funkcity:route_5 run scoreboard players set #d funk.tmp 2
execute if biome ~ ~ ~ funkcity:route_6 run scoreboard players set #d funk.tmp 2
execute if biome ~ ~ ~ funkcity:route_7 run scoreboard players set #d funk.tmp 5
execute if biome ~ ~ ~ funkcity:route_8 run scoreboard players set #d funk.tmp 1
execute unless score #d funk.tmp = @s funk.mdist run return run function funkcity:music/switch
scoreboard players remove @s funk.mt 1
execute if score @s funk.mt matches ..0 run function funkcity:music/switch
