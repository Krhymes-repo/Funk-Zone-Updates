$execute as @e[type=minecraft:text_display,tag=fl$(uid),distance=..6,limit=1] run data modify entity @s text set value '{"text":"$(w)","font":"funkcity:led","color":"$(c)"}'
