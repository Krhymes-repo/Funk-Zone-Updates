schedule function funkcity:led/tick 6t replace
execute as @a at @s if dimension funkcity:city run tag @e[type=minecraft:marker,tag=funk_led,distance=..72] add funk_ledgo
execute as @e[type=minecraft:marker,tag=funk_ledgo] at @s run function funkcity:led/step
tag @e[type=minecraft:marker,tag=funk_ledgo] remove funk_ledgo
