execute store result score #i funk.tmp run data get entity @s data.i
scoreboard players add #i funk.tmp 1
execute store result score #L funk.tmp run data get entity @s data.L
execute if score #i funk.tmp >= #L funk.tmp run scoreboard players set #i funk.tmp 0
execute store result entity @s data.i int 1 run scoreboard players get #i funk.tmp
execute store result score #j funk.tmp run data get entity @s data.n
scoreboard players operation #j funk.tmp += #i funk.tmp
execute store result entity @s data.j int 1 run scoreboard players get #j funk.tmp
function funkcity:led/cut with entity @s data
