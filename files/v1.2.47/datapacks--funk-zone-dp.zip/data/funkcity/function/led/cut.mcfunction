$data modify storage funkcity:led w set string entity @s data.src $(i) $(j)
data modify storage funkcity:led uid set from entity @s data.uid
data modify storage funkcity:led c set from entity @s data.c
function funkcity:led/show with storage funkcity:led
