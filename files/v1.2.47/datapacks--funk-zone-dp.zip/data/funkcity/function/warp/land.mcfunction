tp @s ~ ~ ~
tag @s add funk_warped
playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 0.5 1.6
particle minecraft:portal ~ ~1 ~ 0.3 0.6 0.3 0.4 24
