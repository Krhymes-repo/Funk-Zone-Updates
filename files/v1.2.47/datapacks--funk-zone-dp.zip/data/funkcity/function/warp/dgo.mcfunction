tag @p[tag=!funk_warped,distance=..1] add funk_dw
$execute as @a[tag=funk_dw] in $(dim) run tp @s $(x) $(y) $(z) $(yaw) 0
execute as @a[tag=funk_dw] at @s run function funkcity:warp/dland
