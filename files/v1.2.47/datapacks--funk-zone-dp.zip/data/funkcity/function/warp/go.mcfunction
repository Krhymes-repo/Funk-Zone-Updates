$execute as @p[tag=!funk_warped,distance=..1] at @e[type=minecraft:marker,tag=$(dest),limit=1] run function funkcity:warp/land
