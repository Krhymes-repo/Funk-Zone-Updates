$execute as @p[tag=!funk_warped,distance=..1,tag=$(need)] at @e[type=minecraft:marker,tag=$(dest),limit=1] run function funkcity:warp/land
$execute as @p[tag=!funk_warped,distance=..1,tag=!$(need)] run title @s actionbar {"text":"$(msg)","color":"gold"}
