tag @s remove funk_dw
tag @s add funk_warped
tag @s remove funk_sw1
tag @s remove funk_sw2
tag @s remove funk_q1
tag @s remove funk_q2
tag @s remove funk_q3
effect give @s minecraft:blindness 1 0 true
playsound minecraft:block.wooden_door.open player @s ~ ~ ~ 0.8 0.9
