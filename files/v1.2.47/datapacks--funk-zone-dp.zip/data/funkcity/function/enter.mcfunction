tag @s add funk_in
title @s times 10 80 25
title @s subtitle {"text":"Welcome to Funk City!","color":"#7DF9FF","italic":true}
title @s title {"text":"The Funk Zone","color":"#FF4FD8","bold":true}
playsound minecraft:block.note_block.bit master @s ~ ~ ~ 1 1.5
execute if data storage funkcity:state {built:1b} run return 0
execute if data storage funkcity:state {hub:1b} run return 0
tag @s add funk_wait
effect give @s minecraft:slow_falling 90 0 true
effect give @s minecraft:resistance 90 4 true
execute in funkcity:city run tp @s 0.5 150 19.5 180 30
function funkcity:build/start
