scoreboard players remove @a[scores={funk.cd=1..}] funk.cd 1
scoreboard players remove @a[scores={funk.act=1..}] funk.act 1
execute as @a[scores={funk.pick=1..}] run function funkcity:starter/pick
execute as @a at @s if dimension funkcity:city as @e[type=cobblemon:empty_pokeball,tag=!funk_seen,distance=..32] at @s if entity @e[type=cobblemon:pokemon,tag=funk_pet,distance=..2.5] run function funkcity:pet/ball
execute as @a at @s as @e[tag=funk_still,distance=..24] at @s facing entity @p[distance=..24] eyes run tp @s ~ ~ ~ ~ ~
execute as @a[tag=funk_warped] at @s align xyz positioned ~0.5 ~ ~0.5 unless entity @e[type=minecraft:marker,tag=funk_warp,distance=..0.3] unless entity @e[type=minecraft:marker,tag=funk_dwarp,distance=..0.3] unless entity @e[type=minecraft:marker,tag=funk_gate,distance=..0.3] run tag @s remove funk_warped
execute as @a[tag=!funk_warped,gamemode=!spectator] at @s align xyz positioned ~0.5 ~ ~0.5 as @e[type=minecraft:marker,tag=funk_dwarp,distance=..0.3,limit=1] run function funkcity:warp/dgo with entity @s data
execute as @a[tag=!funk_warped,gamemode=!spectator] at @s align xyz positioned ~0.5 ~ ~0.5 as @e[type=minecraft:marker,tag=funk_warp,distance=..0.3,limit=1] run function funkcity:warp/go with entity @s data
execute as @a[tag=!funk_warped,gamemode=!spectator] at @s align xyz positioned ~0.5 ~ ~0.5 as @e[type=minecraft:marker,tag=funk_gate,distance=..0.3,limit=1] run function funkcity:warp/gate with entity @s data
execute as @a at @s if dimension funkcity:city as @e[type=minecraft:item_display,tag=funk_spin,distance=..48] at @s run tp @s ~ ~ ~ ~3 ~
