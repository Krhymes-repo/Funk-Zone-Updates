advancement revoke @s only funkcity:home/sign
funkfrontier home buy
