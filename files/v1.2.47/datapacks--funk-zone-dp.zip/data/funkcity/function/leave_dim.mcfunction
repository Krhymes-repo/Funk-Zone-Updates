tag @s remove funk_in
stopsound @s ambient funkcity:music.downtown
stopsound @s ambient funkcity:music.groove
stopsound @s ambient funkcity:music.harbor
stopsound @s ambient funkcity:music.garden
stopsound @s ambient funkcity:music.power
stopsound @s ambient funkcity:music.plaza
scoreboard players set @s funk.mdist 0
