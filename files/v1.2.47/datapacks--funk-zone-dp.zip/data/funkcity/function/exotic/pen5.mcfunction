advancement revoke @s only funkcity:exotic/pen5
funkfrontier exotic buy 5
