advancement revoke @s only funkcity:exotic/desk
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
funkfrontier exotic
