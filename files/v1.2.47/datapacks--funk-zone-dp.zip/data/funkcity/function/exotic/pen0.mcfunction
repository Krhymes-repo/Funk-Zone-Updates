advancement revoke @s only funkcity:exotic/pen0
funkfrontier exotic buy 0
