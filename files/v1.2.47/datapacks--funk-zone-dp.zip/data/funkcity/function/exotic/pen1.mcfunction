advancement revoke @s only funkcity:exotic/pen1
funkfrontier exotic buy 1
