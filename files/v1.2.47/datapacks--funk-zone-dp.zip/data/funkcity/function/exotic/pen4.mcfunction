advancement revoke @s only funkcity:exotic/pen4
funkfrontier exotic buy 4
