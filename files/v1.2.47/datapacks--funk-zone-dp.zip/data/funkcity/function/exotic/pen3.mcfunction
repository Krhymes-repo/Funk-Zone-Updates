advancement revoke @s only funkcity:exotic/pen3
funkfrontier exotic buy 3
