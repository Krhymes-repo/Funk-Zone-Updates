advancement revoke @s only funkcity:exotic/pen2
funkfrontier exotic buy 2
