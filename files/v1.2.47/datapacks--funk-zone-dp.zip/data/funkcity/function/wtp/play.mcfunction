advancement revoke @s only funkcity:wtp/talk
playsound minecraft:block.note_block.bit master @s ~ ~ ~ 1 1.2
wtp play
