advancement revoke @s only funkcity:ticket/ranger_pichu_s
pokegive pichu shiny=yes level=5
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.3
tellraw @s [{"text":"[Rangers] ","color":"#7CD67C"},{"text":"Your ticket was redeemed! Check your party or PC.","color":"white"}]
