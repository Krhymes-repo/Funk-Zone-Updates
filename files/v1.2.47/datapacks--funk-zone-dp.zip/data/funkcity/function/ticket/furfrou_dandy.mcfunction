advancement revoke @s only funkcity:ticket/furfrou_dandy
pokegive furfrou poodle_trim=dandy
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.3
tellraw @s [{"text":"[Funk City] ","color":"light_purple"},{"text":"Your ticket was redeemed! Check your party or PC.","color":"white"}]
