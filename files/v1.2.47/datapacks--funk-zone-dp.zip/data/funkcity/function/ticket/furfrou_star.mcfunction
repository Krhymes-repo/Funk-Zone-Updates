advancement revoke @s only funkcity:ticket/furfrou_star
pokegive furfrou poodle_trim=star
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.3
tellraw @s [{"text":"[Funk City] ","color":"light_purple"},{"text":"Your ticket was redeemed! Check your party or PC.","color":"white"}]
