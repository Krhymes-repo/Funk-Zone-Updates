$item modify entity @s weapon.mainhand {function:"minecraft:set_components",components:{"cobbreeding:timer":$(t)}}
