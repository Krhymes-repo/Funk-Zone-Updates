advancement revoke @s only funkcity:station/incubator
execute unless data entity @s SelectedItem.components."cobbreeding:timer" run return run tellraw @s [{"text":"[Incubator] ","color":"#FFD84F"},{"text":"Hold a Pokemon Egg in your hand, then place it in the incubator.","color":"white"}]
execute if score @s funk.inc matches 1.. run return run tellraw @s [{"text":"[Incubator] ","color":"#FFD84F"},{"text":"Still warming back up... try again in ","color":"gray"},{"score":{"name":"@s","objective":"funk.inc"},"color":"white"},{"text":" seconds.","color":"gray"}]
execute store result score #t funk.tmp run data get entity @s SelectedItem.components."cobbreeding:timer"
execute if score #t funk.tmp matches ..200 run return run tellraw @s [{"text":"[Incubator] ","color":"#FFD84F"},{"text":"This egg is already about to hatch!","color":"white"}]
scoreboard players set #k funk.tmp 4
scoreboard players operation #t funk.tmp /= #k funk.tmp
execute store result storage funkcity:tmp inc.t int 1 run scoreboard players get #t funk.tmp
function funkcity:station/incubate with storage funkcity:tmp inc
scoreboard players set @s funk.inc 180
scoreboard players set #k funk.tmp 1200
scoreboard players operation #t funk.tmp /= #k funk.tmp
scoreboard players add #t funk.tmp 1
playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 0.8 1.6
particle minecraft:heart ~ ~1.2 ~ 0.4 0.4 0.4 0 8
tellraw @s [{"text":"[Incubator] ","color":"#FFD84F"},{"text":"The egg is cozy and warm! It will hatch in about ","color":"white"},{"score":{"name":"#t","objective":"funk.tmp"},"color":"#FFD84F"},{"text":" minute(s).","color":"white"}]
