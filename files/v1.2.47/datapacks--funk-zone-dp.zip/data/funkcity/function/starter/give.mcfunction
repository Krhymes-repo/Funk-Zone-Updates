$pokegive $(sp) level=10
