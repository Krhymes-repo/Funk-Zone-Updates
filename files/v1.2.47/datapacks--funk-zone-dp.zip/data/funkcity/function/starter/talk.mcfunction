advancement revoke @s only funkcity:starter/talk
funkstarter
