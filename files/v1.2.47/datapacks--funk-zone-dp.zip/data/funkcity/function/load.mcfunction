scoreboard objectives add funk.inc dummy
scoreboard objectives add funk.rx dummy
scoreboard objectives add funk.ry dummy
scoreboard objectives add funk.rz dummy
scoreboard objectives add funk.rd dummy
scoreboard objectives add funk.cd dummy
scoreboard objectives add funk.act dummy
scoreboard objectives add funk.charge dummy
scoreboard objectives add funk.life dummy
scoreboard objectives add funk.tmp dummy
scoreboard objectives add funk.uid dummy
execute unless score #petuid funk.uid matches 900000.. run scoreboard players set #petuid funk.uid 900000
scoreboard objectives add funk.build dummy
scoreboard objectives add funk.mdist dummy
scoreboard objectives add funk.mt dummy
scoreboard objectives add funk.s1 dummy
scoreboard objectives add funk.s2 dummy
scoreboard objectives add funk.s3 dummy
scoreboard objectives add funk.pick trigger
schedule function funkcity:slow 20t replace
schedule function funkcity:led/tick 6t replace
execute if data storage funkcity:state {building:1b} unless data storage funkcity:state {built:1b} run schedule function funkcity:build/step 40t replace
