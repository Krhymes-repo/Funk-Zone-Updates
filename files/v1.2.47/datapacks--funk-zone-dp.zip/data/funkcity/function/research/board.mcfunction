advancement revoke @s only funkcity:research/board
playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1 1
research
