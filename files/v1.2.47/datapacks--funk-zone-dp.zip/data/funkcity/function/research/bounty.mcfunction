advancement revoke @s only funkcity:research/bounty
playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1 0.8
bounties
