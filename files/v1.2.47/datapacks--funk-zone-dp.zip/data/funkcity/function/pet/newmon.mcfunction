tag @s add funk_seen
execute on owner if entity @s[type=minecraft:player] at @s anchored eyes positioned ^ ^ ^ run function funkcity:pet/ray_start
