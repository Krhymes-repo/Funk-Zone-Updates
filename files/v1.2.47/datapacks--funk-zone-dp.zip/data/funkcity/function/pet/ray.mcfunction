execute if entity @e[type=cobblemon:pokemon,tag=funk_pet,distance=..1.3] run return run function funkcity:pet/notnow
scoreboard players add #ray funk.tmp 1
execute if score #ray funk.tmp matches ..28 positioned ^ ^ ^0.5 run function funkcity:pet/ray
