stopbattle @s
function funkcity:pet/notnow
