tag @s add funk_seen
execute on owner if entity @s[type=minecraft:player] run function funkcity:pet/notnow
