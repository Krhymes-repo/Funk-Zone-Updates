scoreboard players set #ray funk.tmp 0
function funkcity:pet/ray
