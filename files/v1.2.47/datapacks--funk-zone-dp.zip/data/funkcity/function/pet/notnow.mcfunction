title @s actionbar [{"text":"\uE6A0 ","color":"white","italic":false},{"text":"There is a time and a place for everything, but not now!","color":"white","italic":true}]
playsound minecraft:block.note_block.bit player @s ~ ~ ~ 0.6 0.8
