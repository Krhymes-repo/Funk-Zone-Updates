execute as @a[distance=..24,sort=nearest,limit=1] run function funkcity:pet/stop
