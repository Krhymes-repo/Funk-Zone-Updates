schedule function funkcity:slow 20t replace
scoreboard players remove @a[scores={funk.inc=1..}] funk.inc 1
execute as @a[tag=!funk_in] at @s if dimension funkcity:city run function funkcity:enter
# once per marker (not once per nearby player), and only once the area around it has finished loading (Funk Frontier sets funk_ready)
execute as @e[type=minecraft:marker,tag=funk_spawn,tag=funk_ready] at @s if entity @a[distance=..40] run function funkcity:spawn/handle
execute as @a at @s if dimension funkcity:city run function funkcity:spawn/sweep_clerks
