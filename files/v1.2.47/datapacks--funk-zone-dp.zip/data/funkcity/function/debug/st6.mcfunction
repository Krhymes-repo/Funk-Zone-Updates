execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #6: The same COBBLEVERSE track through its normal sound event","color":"yellow"}
execute as @a at @s run playsound minecraft:music.game music @s ~ ~ ~ 1 1 1
schedule function funkcity:debug/st7 140t replace
