execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #5: A COBBLEVERSE overworld track copied into the Funk Zone pack","color":"yellow"}
execute as @a at @s run playsound funkcity:test.t3_cv music @s ~ ~ ~ 1 1 1
schedule function funkcity:debug/st6 140t replace
