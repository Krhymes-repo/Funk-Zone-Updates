tellraw @s {"text":"[Sound test] 7 clips, 7 seconds each. Stand still and note which numbers you HEAR.","color":"gold"}
schedule function funkcity:debug/st1 20t replace
