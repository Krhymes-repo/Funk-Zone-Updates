execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #4: Funk City theme, non-streamed copy","color":"yellow"}
execute as @a at @s run playsound funkcity:test.t4_nostream music @s ~ ~ ~ 1 1 1
schedule function funkcity:debug/st5 140t replace
