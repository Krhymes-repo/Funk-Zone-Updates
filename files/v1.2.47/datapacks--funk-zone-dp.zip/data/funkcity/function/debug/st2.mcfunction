execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #2: Funk City theme, MONO copy","color":"yellow"}
execute as @a at @s run playsound funkcity:test.t1_mono music @s ~ ~ ~ 1 1 1
schedule function funkcity:debug/st3 140t replace
