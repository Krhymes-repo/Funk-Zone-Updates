# Updates the Duel Hall in a world where Funk City is already built.
# Run once with cheats/op:  /function funkcity:debug/duel_hall_refresh
# Hall interior (hub placed at -80 63 -80): x 46..67, y 64..69, z -26..-5
execute in funkcity:city positioned 46 64 -26 run kill @e[type=minecraft:text_display,tag=funk_npc,dx=21,dy=5,dz=21]
execute in funkcity:city positioned 46 64 -26 run kill @e[type=minecraft:interaction,tag=funk_switch,dx=21,dy=5,dz=21]
execute in funkcity:city positioned 46 64 -26 run kill @e[type=minecraft:marker,tag=funk_spawn,dx=21,dy=5,dz=21,nbt={data:{shop:"cardshop"}}]
kill @e[type=cobbledollars:cobble_merchant,tag=fs_cardshop]
execute in funkcity:city run place template funkcity:duel_hall_interior 46 64 -26
tellraw @s {"text":"Duel Hall updated: Card Counter removed, duel tables added.","color":"#FF4FD8"}
