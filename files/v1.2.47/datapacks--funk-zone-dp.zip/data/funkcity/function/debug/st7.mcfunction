execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #7: Funk City plaza theme on the Records channel","color":"yellow"}
execute as @a at @s run playsound funkcity:music.plaza record @s ~ ~ ~ 1 1 1
tellraw @a {"text":"[Sound test] Done - tell Claude which numbers you heard.","color":"gold"}
