execute as @a run stopsound @s
