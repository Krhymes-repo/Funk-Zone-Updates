execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #3: Funk City theme, re-encoded stereo copy","color":"yellow"}
execute as @a at @s run playsound funkcity:test.t2_stereo music @s ~ ~ ~ 1 1 1
schedule function funkcity:debug/st4 140t replace
