execute as @a run stopsound @s
tellraw @a {"text":"[Sound test] #1: Funk City plaza theme (current file, music channel)","color":"yellow"}
execute as @a at @s run playsound funkcity:music.plaza music @s ~ ~ ~ 1 1 1
schedule function funkcity:debug/st2 140t replace
