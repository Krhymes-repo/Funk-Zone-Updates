# Poke Centers v1: the Power Plant and Poison districts never got one - their clinic plots were all built over.
# Turns one park in each into a real Poke Center (next to the Power gym; at the south end of Poison).
# power_clinic_power on the park plot at 560,80
execute in funkcity:city run kill @e[type=minecraft:interaction,tag=funk_tour,x=560,y=40,z=80,dx=39,dy=120,dz=39]
execute in funkcity:city run kill @e[type=!minecraft:player,tag=funk_tourlabel,x=560,y=40,z=80,dx=39,dy=120,dz=39]
execute in funkcity:city run fill 560 63 80 599 82 119 minecraft:air
execute in funkcity:city run fill 560 83 80 599 102 119 minecraft:air
execute in funkcity:city run fill 560 103 80 599 122 119 minecraft:air
execute in funkcity:city run fill 560 123 80 599 140 119 minecraft:air
execute in funkcity:city run fill 560 41 80 599 51 119 kantoblocks:mtmoon_ground
execute in funkcity:city run fill 560 52 80 599 62 119 kantoblocks:mtmoon_ground
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:city/power_clinic_power 560 63 80 none
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fillbiome 560 40 80 599 59 119 funkcity:power
execute in funkcity:city run fillbiome 560 60 80 599 79 119 funkcity:power
execute in funkcity:city run fillbiome 560 80 80 599 99 119 funkcity:power
execute in funkcity:city run fillbiome 560 100 80 599 119 119 funkcity:power
execute in funkcity:city run fillbiome 560 120 80 599 139 119 funkcity:power
execute in funkcity:city run fillbiome 560 140 80 599 159 119 funkcity:power
execute in funkcity:city run fillbiome 560 160 80 599 179 119 funkcity:power
execute in funkcity:city run fillbiome 560 180 80 599 199 119 funkcity:power
execute in funkcity:city run fill 560 64 80 599 70 119 minecraft:air replace minecraft:barrier
execute in funkcity:city run fill 595 64 85 599 65 114 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 560 64 85 564 65 114 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 560 64 115 599 65 119 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 560 64 80 599 65 84 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 560 145 80 564 145 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 144 80 569 144 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 570 143 80 573 143 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 142 80 577 142 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 141 80 581 141 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 140 80 585 140 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 139 80 589 139 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 138 80 593 138 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 137 80 596 137 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 136 80 599 136 80 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 81 564 145 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 144 81 568 144 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 143 81 573 143 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 142 81 577 142 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 141 81 581 141 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 140 81 585 140 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 139 81 589 139 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 138 81 592 138 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 81 596 137 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 136 81 599 136 81 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 82 564 145 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 144 82 568 144 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 143 82 573 143 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 142 82 577 142 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 141 82 581 141 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 140 82 585 140 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 139 82 589 139 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 138 82 592 138 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 82 596 137 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 136 82 599 136 82 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 83 564 145 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 144 83 568 144 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 143 83 572 143 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 83 577 142 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 141 83 581 141 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 140 83 585 140 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 139 83 588 139 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 83 592 138 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 83 596 137 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 136 83 599 136 83 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 84 563 145 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 84 568 144 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 143 84 572 143 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 84 576 142 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 84 581 141 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 140 84 584 140 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 84 588 139 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 84 592 138 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 84 596 137 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 136 84 599 136 84 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 85 563 145 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 85 568 144 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 143 85 572 143 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 85 576 142 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 85 580 141 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 140 85 584 140 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 85 588 139 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 85 592 138 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 85 595 137 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 85 599 136 85 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 86 563 145 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 86 568 144 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 143 86 572 143 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 86 576 142 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 86 580 141 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 140 86 584 140 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 86 588 139 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 86 592 138 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 86 595 137 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 86 599 136 86 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 87 563 145 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 87 567 144 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 87 572 143 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 87 576 142 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 87 580 141 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 140 87 584 140 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 87 588 139 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 87 592 138 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 137 87 595 137 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 87 599 136 87 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 88 563 145 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 88 567 144 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 88 572 143 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 88 576 142 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 88 580 141 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 140 88 584 140 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 88 588 139 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 88 591 138 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 88 595 137 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 88 599 136 88 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 89 563 145 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 89 567 144 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 89 572 143 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 142 89 576 142 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 89 580 141 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 140 89 584 140 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 89 588 139 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 138 89 591 138 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 89 595 137 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 89 598 136 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 135 89 599 135 89 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 90 563 145 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 144 90 567 144 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 90 571 143 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 142 90 576 142 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 141 90 580 141 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 140 90 584 140 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 139 90 587 139 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 138 90 591 138 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 90 595 137 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 90 598 136 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 135 90 599 135 90 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 91 562 145 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 144 91 567 144 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 91 571 143 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 142 91 575 142 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 141 91 579 141 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 91 583 140 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 139 91 587 139 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 138 91 591 138 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 91 595 137 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 136 91 598 136 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 135 91 599 135 91 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 92 562 145 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 144 92 567 144 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 92 571 143 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 142 92 575 142 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 141 92 579 141 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 92 583 140 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 139 92 587 139 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 138 92 591 138 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 92 594 137 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 136 92 598 136 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 135 92 599 135 92 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 93 562 145 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 144 93 567 144 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 143 93 571 143 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 142 93 575 142 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 141 93 579 141 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 93 583 140 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 139 93 587 139 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 138 93 591 138 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 93 594 137 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 136 93 598 136 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 135 93 599 135 93 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 94 562 145 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 144 94 566 144 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 143 94 571 143 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 142 94 575 142 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 141 94 579 141 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 94 583 140 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 139 94 587 139 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 138 94 591 138 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 137 94 594 137 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 136 94 598 136 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 135 94 599 135 94 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 95 562 145 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 144 95 566 144 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 143 95 571 143 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 142 95 575 142 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 141 95 579 141 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 95 583 140 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 139 95 587 139 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 138 95 590 138 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 137 95 594 137 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 136 95 597 136 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 135 95 599 135 95 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 96 562 145 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 144 96 566 144 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 143 96 570 143 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 142 96 575 142 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 141 96 579 141 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 96 583 140 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 139 96 586 139 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 138 96 590 138 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 137 96 594 137 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 136 96 597 136 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 135 96 599 135 96 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 97 561 145 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 562 144 97 566 144 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 143 97 570 143 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 142 97 574 142 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 141 97 579 141 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 140 97 582 140 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 139 97 586 139 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 138 97 590 138 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 137 97 594 137 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 136 97 597 136 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 135 97 599 135 97 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 98 561 145 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 562 144 98 566 144 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 143 98 570 143 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 142 98 574 142 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 141 98 578 141 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 579 140 98 582 140 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 139 98 586 139 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 138 98 590 138 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 137 98 593 137 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 136 98 597 136 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 135 98 599 135 98 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 99 561 145 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 562 144 99 566 144 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 143 99 570 143 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 142 99 574 142 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 141 99 578 141 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 579 140 99 582 140 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 139 99 586 139 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 138 99 590 138 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 137 99 593 137 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 136 99 597 136 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 135 99 599 135 99 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 100 561 145 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 562 144 100 565 144 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 566 143 100 570 143 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 142 100 574 142 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 141 100 578 141 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 579 140 100 582 140 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 139 100 586 139 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 138 100 590 138 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 137 100 593 137 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 136 100 597 136 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 135 100 599 135 100 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 101 561 145 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 562 144 101 565 144 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 566 143 101 570 143 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 142 101 574 142 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 141 101 578 141 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 579 140 101 582 140 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 139 101 586 139 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 138 101 589 138 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 137 101 593 137 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 136 101 596 136 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 135 101 599 135 101 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 102 560 145 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 561 144 102 565 144 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 566 143 102 569 143 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 570 142 102 574 142 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 141 102 578 141 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 579 140 102 582 140 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 139 102 585 139 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 138 102 589 138 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 137 102 593 137 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 136 102 596 136 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 135 102 599 135 102 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 103 560 145 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 561 144 103 565 144 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 566 143 103 569 143 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 570 142 103 573 142 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 141 103 577 141 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 140 103 581 140 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 139 103 585 139 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 138 103 589 138 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 137 103 593 137 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 136 103 596 136 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 135 103 599 135 103 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 104 560 145 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 561 144 104 565 144 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 566 143 104 569 143 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 570 142 104 573 142 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 141 104 577 141 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 140 104 581 140 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 139 104 585 139 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 138 104 589 138 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 137 104 592 137 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 136 104 596 136 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 135 104 599 135 104 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 105 560 145 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 561 144 105 564 144 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 143 105 569 143 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 570 142 105 573 142 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 141 105 577 141 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 140 105 581 140 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 139 105 585 139 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 138 105 589 138 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 590 137 105 592 137 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 136 105 596 136 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 135 105 599 135 105 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 106 560 145 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 561 144 106 564 144 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 143 106 569 143 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 570 142 106 573 142 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 141 106 577 141 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 140 106 581 140 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 139 106 585 139 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 138 106 588 138 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 137 106 592 137 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 136 106 596 136 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 597 135 106 599 135 106 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 145 107 560 145 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 561 144 107 564 144 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 143 107 568 143 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 142 107 573 142 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 574 141 107 577 141 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 140 107 581 140 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 139 107 585 139 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 586 138 107 588 138 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 137 107 592 137 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 136 107 595 136 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 135 107 599 135 107 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 108 564 144 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 143 108 568 143 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 142 108 572 142 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 141 108 577 141 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 578 140 108 581 140 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 582 139 108 584 139 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 138 108 588 138 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 137 108 592 137 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 136 108 595 136 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 135 108 599 135 108 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 109 564 144 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 565 143 109 568 143 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 142 109 572 142 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 141 109 576 141 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 140 109 580 140 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 139 109 584 139 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 138 109 588 138 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 137 109 592 137 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 593 136 109 595 136 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 135 109 598 135 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 134 109 599 134 109 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 110 563 144 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 143 110 568 143 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 142 110 572 142 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 141 110 576 141 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 140 110 580 140 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 139 110 584 139 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 138 110 588 138 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 137 110 591 137 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 136 110 595 136 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 135 110 598 135 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 134 110 599 134 110 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 111 563 144 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 143 111 568 143 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 569 142 111 572 142 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 141 111 576 141 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 140 111 580 140 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 139 111 584 139 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 138 111 588 138 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 589 137 111 591 137 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 136 111 595 136 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 596 135 111 598 135 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 134 111 599 134 111 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 112 563 144 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 143 112 567 143 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 142 112 572 142 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 573 141 112 576 141 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 140 112 580 140 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 139 112 584 139 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 585 138 112 587 138 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 137 112 591 137 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 136 112 594 136 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 135 112 598 135 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 134 112 599 134 112 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 113 563 144 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 143 113 567 143 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 142 113 571 142 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 141 113 576 141 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 577 140 113 580 140 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 581 139 113 583 139 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 138 113 587 138 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 137 113 591 137 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 136 113 594 136 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 135 113 598 135 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 134 113 599 134 113 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 114 563 144 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 564 143 114 567 143 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 142 114 571 142 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 141 114 575 141 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 140 114 579 140 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 139 114 583 139 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 138 114 587 138 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 137 114 591 137 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 592 136 114 594 136 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 135 114 597 135 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 134 114 599 134 114 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 115 562 144 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 143 115 567 143 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 142 115 571 142 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 141 115 575 141 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 140 115 579 140 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 139 115 583 139 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 138 115 587 138 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 137 115 590 137 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 136 115 594 136 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 135 115 597 135 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 134 115 599 134 115 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 116 562 144 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 143 116 567 143 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 568 142 116 571 142 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 141 116 575 141 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 140 116 579 140 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 139 116 583 139 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 138 116 587 138 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 588 137 116 590 137 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 136 116 594 136 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 135 116 597 135 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 134 116 599 134 116 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 117 562 144 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 143 117 566 143 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 142 117 571 142 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 572 141 117 575 141 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 140 117 579 140 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 139 117 583 139 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 584 138 117 586 138 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 137 117 590 137 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 136 117 594 136 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 595 135 117 597 135 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 134 117 599 134 117 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 118 562 144 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 143 118 566 143 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 142 118 570 142 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 141 118 575 141 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 576 140 118 579 140 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 580 139 118 582 139 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 138 118 586 138 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 137 118 590 137 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 136 118 593 136 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 135 118 597 135 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 134 118 599 134 118 minecraft:yellow_stained_glass
execute in funkcity:city run fill 560 144 119 562 144 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 563 143 119 566 143 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 567 142 119 570 142 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 571 141 119 574 141 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 575 140 119 578 140 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 579 139 119 582 139 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 583 138 119 586 138 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 587 137 119 590 137 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 591 136 119 593 136 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 594 135 119 597 135 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 598 134 119 599 134 119 minecraft:yellow_stained_glass
execute in funkcity:city run fill 599 64 80 599 65 80 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 81 599 65 81 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 82 599 65 82 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 83 599 65 83 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 84 599 65 84 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 85 599 65 85 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 86 599 65 86 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 87 599 65 87 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 88 599 65 88 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 89 599 65 89 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 90 599 65 90 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 91 599 65 91 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 92 599 65 92 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 93 599 65 93 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 94 599 65 94 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 95 599 65 95 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 96 599 65 96 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 97 599 65 97 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 98 599 65 98 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 99 599 65 99 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 100 599 65 100 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 101 599 65 101 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 102 599 65 102 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 103 599 65 103 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 104 599 65 104 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 105 599 65 105 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 106 599 65 106 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 107 599 65 107 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 108 599 65 108 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 109 599 65 109 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 110 599 65 110 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 111 599 65 111 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 112 599 65 112 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 113 599 65 113 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 114 599 65 114 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 115 599 65 115 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 116 599 65 116 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 117 599 65 117 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 599 64 118 599 65 118 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 560 64 119 599 65 119 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run kill @e[type=minecraft:item,x=552,y=-64,z=72,dx=56,dy=400,dz=56]
execute in funkcity:city run kill @e[type=minecraft:item,x=552,y=-64,z=72,dx=55,dy=400,dz=55]
# poison_clinic_poison on the park plot at 40,560
execute in funkcity:city run kill @e[type=minecraft:interaction,tag=funk_tour,x=40,y=40,z=560,dx=39,dy=120,dz=39]
execute in funkcity:city run kill @e[type=!minecraft:player,tag=funk_tourlabel,x=40,y=40,z=560,dx=39,dy=120,dz=39]
execute in funkcity:city run fill 40 63 560 79 82 599 minecraft:air
execute in funkcity:city run fill 40 83 560 79 102 599 minecraft:air
execute in funkcity:city run fill 40 103 560 79 122 599 minecraft:air
execute in funkcity:city run fill 40 123 560 79 140 599 minecraft:air
execute in funkcity:city run fill 40 41 560 79 51 599 kantoblocks:mtmoon_ground
execute in funkcity:city run fill 40 52 560 79 62 599 kantoblocks:mtmoon_ground
execute in funkcity:city store success score #ok funk.tmp run place template funkcity:city/poison_clinic_poison 40 63 560 none
execute if score #ok funk.tmp matches 0 run return 0
execute in funkcity:city run fillbiome 40 40 560 79 59 599 funkcity:poison
execute in funkcity:city run fillbiome 40 60 560 79 79 599 funkcity:poison
execute in funkcity:city run fillbiome 40 80 560 79 99 599 funkcity:poison
execute in funkcity:city run fillbiome 40 100 560 79 119 599 funkcity:poison
execute in funkcity:city run fillbiome 40 120 560 79 139 599 funkcity:poison
execute in funkcity:city run fillbiome 40 140 560 79 159 599 funkcity:poison
execute in funkcity:city run fillbiome 40 160 560 79 179 599 funkcity:poison
execute in funkcity:city run fillbiome 40 180 560 79 199 599 funkcity:poison
execute in funkcity:city run fill 40 64 560 79 70 599 minecraft:air replace minecraft:barrier
execute in funkcity:city run fill 75 64 565 79 65 594 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 40 64 565 44 65 594 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 40 64 595 79 65 599 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 40 64 560 79 65 564 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 40 146 560 79 146 560 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 146 561 72 146 561 minecraft:purple_stained_glass
execute in funkcity:city run fill 73 145 561 79 145 561 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 146 562 64 146 562 minecraft:purple_stained_glass
execute in funkcity:city run fill 65 145 562 79 145 562 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 146 563 54 146 563 minecraft:purple_stained_glass
execute in funkcity:city run fill 55 145 563 79 145 563 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 146 564 42 146 564 minecraft:purple_stained_glass
execute in funkcity:city run fill 43 145 564 79 145 564 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 145 565 76 145 565 minecraft:purple_stained_glass
execute in funkcity:city run fill 77 144 565 79 144 565 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 145 566 68 145 566 minecraft:purple_stained_glass
execute in funkcity:city run fill 69 144 566 79 144 566 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 145 567 60 145 567 minecraft:purple_stained_glass
execute in funkcity:city run fill 61 144 567 79 144 567 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 145 568 49 145 568 minecraft:purple_stained_glass
execute in funkcity:city run fill 50 144 568 79 144 568 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 144 569 79 144 569 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 144 570 72 144 570 minecraft:purple_stained_glass
execute in funkcity:city run fill 73 143 570 79 143 570 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 144 571 64 144 571 minecraft:purple_stained_glass
execute in funkcity:city run fill 65 143 571 79 143 571 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 144 572 54 144 572 minecraft:purple_stained_glass
execute in funkcity:city run fill 55 143 572 79 143 572 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 144 573 42 144 573 minecraft:purple_stained_glass
execute in funkcity:city run fill 43 143 573 79 143 573 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 143 574 75 143 574 minecraft:purple_stained_glass
execute in funkcity:city run fill 76 142 574 79 142 574 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 143 575 67 143 575 minecraft:purple_stained_glass
execute in funkcity:city run fill 68 142 575 79 142 575 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 143 576 57 143 576 minecraft:purple_stained_glass
execute in funkcity:city run fill 58 142 576 79 142 576 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 143 577 46 143 577 minecraft:purple_stained_glass
execute in funkcity:city run fill 47 142 577 79 142 577 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 142 578 76 142 578 minecraft:purple_stained_glass
execute in funkcity:city run fill 77 141 578 79 141 578 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 142 579 68 142 579 minecraft:purple_stained_glass
execute in funkcity:city run fill 69 141 579 79 141 579 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 142 580 59 142 580 minecraft:purple_stained_glass
execute in funkcity:city run fill 60 141 580 79 141 580 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 142 581 48 142 581 minecraft:purple_stained_glass
execute in funkcity:city run fill 49 141 581 79 141 581 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 141 582 77 141 582 minecraft:purple_stained_glass
execute in funkcity:city run fill 78 140 582 79 140 582 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 141 583 69 141 583 minecraft:purple_stained_glass
execute in funkcity:city run fill 70 140 583 79 140 583 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 141 584 60 141 584 minecraft:purple_stained_glass
execute in funkcity:city run fill 61 140 584 79 140 584 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 141 585 49 141 585 minecraft:purple_stained_glass
execute in funkcity:city run fill 50 140 585 79 140 585 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 140 586 76 140 586 minecraft:purple_stained_glass
execute in funkcity:city run fill 77 139 586 79 139 586 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 140 587 68 140 587 minecraft:purple_stained_glass
execute in funkcity:city run fill 69 139 587 79 139 587 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 140 588 59 140 588 minecraft:purple_stained_glass
execute in funkcity:city run fill 60 139 588 79 139 588 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 140 589 48 140 589 minecraft:purple_stained_glass
execute in funkcity:city run fill 49 139 589 79 139 589 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 139 590 75 139 590 minecraft:purple_stained_glass
execute in funkcity:city run fill 76 138 590 79 138 590 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 139 591 66 139 591 minecraft:purple_stained_glass
execute in funkcity:city run fill 67 138 591 79 138 591 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 139 592 57 139 592 minecraft:purple_stained_glass
execute in funkcity:city run fill 58 138 592 79 138 592 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 139 593 46 139 593 minecraft:purple_stained_glass
execute in funkcity:city run fill 47 138 593 79 138 593 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 138 594 72 138 594 minecraft:purple_stained_glass
execute in funkcity:city run fill 73 137 594 79 137 594 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 138 595 64 138 595 minecraft:purple_stained_glass
execute in funkcity:city run fill 65 137 595 79 137 595 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 138 596 54 138 596 minecraft:purple_stained_glass
execute in funkcity:city run fill 55 137 596 79 137 596 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 138 597 41 138 597 minecraft:purple_stained_glass
execute in funkcity:city run fill 42 137 597 77 137 597 minecraft:purple_stained_glass
execute in funkcity:city run fill 78 136 597 79 136 597 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 137 598 69 137 598 minecraft:purple_stained_glass
execute in funkcity:city run fill 70 136 598 79 136 598 minecraft:purple_stained_glass
execute in funkcity:city run fill 40 137 599 60 137 599 minecraft:purple_stained_glass
execute in funkcity:city run fill 61 136 599 79 136 599 minecraft:purple_stained_glass
execute in funkcity:city run fill 79 64 560 79 65 560 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 561 79 65 561 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 562 79 65 562 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 563 79 65 563 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 564 79 65 564 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 565 79 65 565 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 566 79 65 566 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 567 79 65 567 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 568 79 65 568 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 569 79 65 569 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 570 79 65 570 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 571 79 65 571 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 572 79 65 572 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 573 79 65 573 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 574 79 65 574 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 575 79 65 575 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 576 79 65 576 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 577 79 65 577 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 578 79 65 578 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 579 79 65 579 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 580 79 65 580 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 581 79 65 581 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 582 79 65 582 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 583 79 65 583 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 584 79 65 584 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 585 79 65 585 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 586 79 65 586 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 587 79 65 587 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 588 79 65 588 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 589 79 65 589 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 590 79 65 590 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 591 79 65 591 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 592 79 65 592 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 593 79 65 593 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 594 79 65 594 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 595 79 65 595 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 596 79 65 596 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 597 79 65 597 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 79 64 598 79 65 598 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run fill 40 64 599 79 65 599 minecraft:air replace kantoblocks:power_plant_wall_2
execute in funkcity:city run kill @e[type=minecraft:item,x=32,y=-64,z=552,dx=56,dy=400,dz=56]
execute in funkcity:city run kill @e[type=minecraft:item,x=32,y=-64,z=552,dx=55,dy=400,dz=55]
data modify storage funkcity:state clinics set value 1
