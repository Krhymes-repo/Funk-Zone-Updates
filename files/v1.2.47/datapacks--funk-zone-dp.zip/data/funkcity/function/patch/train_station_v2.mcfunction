# Funk City Line station on the Plaza's south lawn, v2: the floor is level with the lawn (the brick shell used to add a step)
execute in funkcity:city run fill 15 64 35 26 74 49 minecraft:air
execute in funkcity:city run fill 14 63 36 26 63 48 minecraft:grass_block
execute in funkcity:city run fill 17 63 37 25 68 45 minecraft:bricks hollow
execute in funkcity:city run fill 17 63 37 25 63 45 minecraft:polished_andesite
execute in funkcity:city run fill 18 63 38 24 63 44 minecraft:smooth_stone
execute in funkcity:city run fill 17 68 37 25 68 45 minecraft:dark_oak_planks outline
execute in funkcity:city run fill 16 69 36 26 69 46 minecraft:dark_oak_slab
execute in funkcity:city run fill 17 64 40 17 66 42 minecraft:air
execute in funkcity:city run fill 16 67 39 16 67 43 minecraft:red_wool
execute in funkcity:city run fill 18 64 44 24 64 44 minecraft:rail[shape=east_west]
execute in funkcity:city run fill 18 63 44 24 63 44 minecraft:gravel
execute in funkcity:city run fill 18 63 43 24 63 43 minecraft:yellow_concrete
execute in funkcity:city run fill 19 65 37 20 66 37 minecraft:glass_pane[east=true,west=true]
execute in funkcity:city run fill 22 65 37 23 66 37 minecraft:glass_pane[east=true,west=true]
execute in funkcity:city run fill 25 65 39 25 66 39 minecraft:glass_pane[north=true,south=true]
execute in funkcity:city run fill 25 65 43 25 66 43 minecraft:glass_pane[north=true,south=true]
execute in funkcity:city run setblock 21 63 41 minecraft:gold_block
execute in funkcity:city run setblock 21 64 41 minecraft:heavy_weighted_pressure_plate
execute in funkcity:city run setblock 18 67 38 minecraft:lantern[hanging=true]
execute in funkcity:city run setblock 24 67 38 minecraft:lantern[hanging=true]
execute in funkcity:city run setblock 18 67 44 minecraft:lantern[hanging=true]
execute in funkcity:city run setblock 24 67 44 minecraft:lantern[hanging=true]
execute in funkcity:city run setblock 24 64 38 minecraft:spruce_stairs[facing=west]
execute in funkcity:city run setblock 24 64 39 minecraft:spruce_stairs[facing=west]
execute in funkcity:city run fill 14 63 40 16 63 42 minecraft:dirt_path
execute in funkcity:city run kill @e[tag=funk_trainstation]
execute in funkcity:city run summon minecraft:marker 21.5 64 41.5 {Tags:["funk_npc","funk_train","ftrain_wilds","funk_trainstation"]}
execute in funkcity:city run summon minecraft:text_display 16.9 67.4 41.5 {id: "minecraft:text_display", Tags: ["funk_npc", "funk_label", "funk_trainstation"], text: '[{"text": "\\u2501 FUNK CITY LINE \\u2501\\n", "color": "#FF4FD8", "bold": true}, {"text": "To the Homestead Wilds", "color": "#7CFC9A"}]', billboard: "fixed", line_width: 260, background: 1711276032, Rotation: [90.0f, 0.0f], brightness: {sky: 15, block: 15}, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], translation: [0.0f, 0.0f, 0.0f], scale: [0.9f, 0.9f, 0.9f]}}
execute in funkcity:city run summon minecraft:text_display 21.5 66.6 41.5 {id: "minecraft:text_display", Tags: ["funk_npc", "funk_label", "funk_trainstation"], text: '[{"text": "Step on the gold plate\\n", "color": "#FFE08A"}, {"text": "Next stop: the Homestead Commons", "color": "white"}]', billboard: "center", line_width: 260, background: 1711276032, Rotation: [0.0f, 0.0f], brightness: {sky: 15, block: 15}, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], translation: [0.0f, 0.0f, 0.0f], scale: [0.55f, 0.55f, 0.55f]}}
execute in funkcity:city run summon minecraft:text_display 16.9 64.4 38.6 {id: "minecraft:text_display", Tags: ["funk_npc", "funk_label", "funk_trainstation", "funk_trainboard", "ftb_wilds"], text: '[{"text": "Out in the Wilds now:\\n", "color": "#7CFC9A"}, {"text": "...", "color": "gray"}]', billboard: "fixed", line_width: 200, background: 1711276032, Rotation: [90.0f, 0.0f], brightness: {sky: 15, block: 15}, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], translation: [0.0f, 0.0f, 0.0f], scale: [0.5f, 0.5f, 0.5f]}}
data modify storage funkcity:state trainstation set value 2
