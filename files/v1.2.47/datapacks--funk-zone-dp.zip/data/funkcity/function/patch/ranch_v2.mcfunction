# Hollis's Ride Ranch, v2: the barn floor sits on the ground (was one block up) and the paddock is a fence ring (was filled solid)
execute in funkcity:city run fill -29 64 -129 -7 77 -107 minecraft:air
execute in funkcity:city run fill -29 60 -129 -7 62 -107 minecraft:dirt
execute in funkcity:city run fill -29 63 -129 -7 63 -107 minecraft:grass_block
execute in funkcity:city run fill -28 63 -124 -20 68 -112 minecraft:mangrove_planks hollow
execute in funkcity:city run fill -27 63 -123 -21 63 -113 minecraft:spruce_planks
execute in funkcity:city run fill -28 64 -124 -28 68 -124 minecraft:stripped_birch_log
execute in funkcity:city run fill -20 64 -124 -20 68 -124 minecraft:stripped_birch_log
execute in funkcity:city run fill -28 64 -112 -28 68 -112 minecraft:stripped_birch_log
execute in funkcity:city run fill -20 64 -112 -20 68 -112 minecraft:stripped_birch_log
execute in funkcity:city run fill -28 68 -124 -20 68 -124 minecraft:stripped_birch_log[axis=x]
execute in funkcity:city run fill -28 68 -112 -20 68 -112 minecraft:stripped_birch_log[axis=x]
execute in funkcity:city run fill -28 68 -123 -28 68 -113 minecraft:stripped_birch_log[axis=z]
execute in funkcity:city run fill -20 68 -123 -20 68 -113 minecraft:stripped_birch_log[axis=z]
execute in funkcity:city run fill -28 69 -125 -28 69 -111 minecraft:dark_oak_stairs[facing=east]
execute in funkcity:city run fill -20 69 -125 -20 69 -111 minecraft:dark_oak_stairs[facing=west]
execute in funkcity:city run fill -27 69 -124 -21 69 -124 minecraft:mangrove_planks
execute in funkcity:city run fill -27 69 -112 -21 69 -112 minecraft:mangrove_planks
execute in funkcity:city run fill -27 70 -125 -27 70 -111 minecraft:dark_oak_stairs[facing=east]
execute in funkcity:city run fill -21 70 -125 -21 70 -111 minecraft:dark_oak_stairs[facing=west]
execute in funkcity:city run fill -26 70 -124 -22 70 -124 minecraft:mangrove_planks
execute in funkcity:city run fill -26 70 -112 -22 70 -112 minecraft:mangrove_planks
execute in funkcity:city run fill -26 71 -125 -26 71 -111 minecraft:dark_oak_stairs[facing=east]
execute in funkcity:city run fill -22 71 -125 -22 71 -111 minecraft:dark_oak_stairs[facing=west]
execute in funkcity:city run fill -25 71 -124 -23 71 -124 minecraft:mangrove_planks
execute in funkcity:city run fill -25 71 -112 -23 71 -112 minecraft:mangrove_planks
execute in funkcity:city run fill -25 72 -125 -25 72 -111 minecraft:dark_oak_stairs[facing=east]
execute in funkcity:city run fill -23 72 -125 -23 72 -111 minecraft:dark_oak_stairs[facing=west]
execute in funkcity:city run fill -24 72 -124 -24 72 -124 minecraft:mangrove_planks
execute in funkcity:city run fill -24 72 -112 -24 72 -112 minecraft:mangrove_planks
execute in funkcity:city run fill -24 73 -125 -24 73 -111 minecraft:dark_oak_stairs[facing=east]
execute in funkcity:city run fill -24 73 -125 -24 73 -111 minecraft:dark_oak_stairs[facing=west]
execute in funkcity:city run fill -23 73 -125 -24 73 -111 minecraft:dark_oak_slab
execute in funkcity:city run fill -20 64 -120 -20 67 -116 minecraft:air
execute in funkcity:city run fill -20 68 -120 -20 68 -116 minecraft:stripped_birch_log[axis=z]
execute in funkcity:city run setblock -20 69 -118 minecraft:white_concrete
execute in funkcity:city run setblock -27 64 -123 minecraft:hay_block
execute in funkcity:city run setblock -27 64 -122 minecraft:hay_block
execute in funkcity:city run setblock -26 64 -123 minecraft:hay_block
execute in funkcity:city run setblock -27 64 -113 minecraft:hay_block
execute in funkcity:city run setblock -27 64 -114 minecraft:hay_block
execute in funkcity:city run setblock -27 65 -123 minecraft:hay_block
execute in funkcity:city run fill -27 64 -119 -27 64 -117 minecraft:composter
execute in funkcity:city run setblock -24 67 -118 minecraft:lantern[hanging=true]
execute in funkcity:city run fill -18 64 -125 -8 64 -125 minecraft:oak_fence
execute in funkcity:city run fill -18 64 -111 -8 64 -111 minecraft:oak_fence
execute in funkcity:city run fill -18 64 -125 -18 64 -111 minecraft:oak_fence
execute in funkcity:city run fill -8 64 -125 -8 64 -111 minecraft:oak_fence
execute in funkcity:city run fill -18 64 -120 -18 64 -116 minecraft:air
execute in funkcity:city run setblock -8 64 -118 minecraft:oak_fence_gate[facing=east]
execute in funkcity:city run fill -15 64 -112 -13 64 -112 minecraft:cauldron
execute in funkcity:city run fill -15 64 -112 -13 64 -112 minecraft:water_cauldron[level=3]
execute in funkcity:city run setblock -9 64 -124 minecraft:hay_block
execute in funkcity:city run setblock -10 64 -124 minecraft:hay_block
execute in funkcity:city run setblock -18 65 -125 minecraft:lantern
execute in funkcity:city run setblock -8 65 -125 minecraft:lantern
execute in funkcity:city run setblock -18 65 -111 minecraft:lantern
execute in funkcity:city run setblock -8 65 -111 minecraft:lantern
execute in funkcity:city run fill -7 63 -119 -7 63 -117 minecraft:dirt_path
execute in funkcity:city run fill -6 63 -119 -6 63 -117 minecraft:dirt_path
execute in funkcity:city run fill -5 63 -119 -5 63 -117 minecraft:dirt_path
execute in funkcity:city run fill -4 63 -119 -4 63 -117 minecraft:dirt_path
execute in funkcity:city run fill -3 63 -119 -3 63 -117 minecraft:dirt_path
execute in funkcity:city run fill -2 63 -119 -2 63 -117 minecraft:dirt_path
execute in funkcity:city run fill -1 65 -119 -1 65 -117 minecraft:dirt_path
execute in funkcity:city run fill 0 63 -119 0 63 -117 minecraft:dirt_path
execute in funkcity:city run fill 1 63 -119 1 63 -117 minecraft:dirt_path
execute in funkcity:city run fill 2 63 -119 2 63 -117 minecraft:dirt_path
execute in funkcity:city run kill @e[tag=funk_ranch,x=-30,y=61,z=-130,dx=24,dy=20,dz=24]
execute in funkcity:city run summon minecraft:text_display -6.5 66.6 -117.5 {billboard:"vertical",background:-1442840576,line_width:240,Tags:["funk_npc","funk_ranch"],brightness:{sky:15,block:15},text:'[{"text": "★ HOLLIS\'S RIDE RANCH ★\\n", "color": "#FFB347", "bold": true}, {"text": "Skiddo · Rhyhorn · Tauros · Bouffalant · Orthworm", "color": "#FFFFFF"}]',transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
data modify storage funkcity:state ranch set value 2b
