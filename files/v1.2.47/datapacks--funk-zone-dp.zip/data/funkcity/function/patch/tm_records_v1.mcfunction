# The Galleria's Green Thumb garden shop becomes TM Records (DJ Tamsin, 130 TMs sorted by type). Mulch and mint leaves
# moved to the Rainbow Gardens Mart. Runs once per world, in funkcity:city; only marks itself done once the shop's
# marker has been found (entities can come up a moment after their chunk).
execute as @e[type=minecraft:marker,tag=funk_spawn,x=-0.5,y=64,z=-60.5,distance=..1.5] if data entity @s data{shop:"green_thumb"} run data modify entity @s data.shop set value "tm_records"
execute as @e[type=cobbledollars:cobble_merchant,tag=fs_green_thumb] at @s run function funkcity:spawn/vanish
setblock -2 65 -63 minecraft:dark_oak_sign[rotation=4]{is_waxed:1b,front_text:{messages:['{"text": "TM Records"}','{"text": "Move Discs"}','{"text": "Teach any move"}','{"text": "130 TMs"}'],color:"light_blue",has_glowing_text:1b}} replace
execute as @e[type=minecraft:item_display,tag=funk_spin,x=-1.5,y=65.35,z=-63.5,distance=..0.5] run data modify entity @s item set value {id:"tmcraft:tm_thunderbolt",count:1}
execute as @e[type=minecraft:item_display,tag=funk_spin,x=-1.5,y=65.35,z=-57.5,distance=..0.5] run data modify entity @s item set value {id:"tmcraft:tm_earthquake",count:1}
execute if entity @e[type=minecraft:marker,tag=funk_spawn,x=-0.5,y=64,z=-60.5,distance=..1.5,nbt={data:{shop:"tm_records"}}] run data modify storage funkcity:state tmRecords set value 1
