execute if entity @e[type=cobblemon:pokemon,distance=..10] run return 0
function funkcity:spawn/display_m with entity @s data
