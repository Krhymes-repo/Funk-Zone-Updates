schedule function funkcity:slow 20t replace
scoreboard players remove @a[scores={funk.inc=1..}] funk.inc 1
execute as @a[tag=!funk_in] at @s if dimension funkcity:city run function funkcity:enter
execute as @a at @s as @e[type=minecraft:marker,tag=funk_spawn,distance=..40] at @s run function funkcity:spawn/handle
execute as @a at @s if dimension funkcity:city run function funkcity:spawn/sweep_clerks
